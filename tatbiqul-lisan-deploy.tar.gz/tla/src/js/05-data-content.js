/* ============================================================
   CONTENT DATA — tests catalogue, library, dictionary, blog,
   achievements, plans, platform config
   ============================================================ */
window.TLA = window.TLA || {};
TLA.data = TLA.data || {};

(function () {
  "use strict";
  const LEVELS = ["a1", "a2", "b1", "b2", "c1", "c2"];

  /* ---------------- Tests catalogue ---------------- */
  const tests = [];

  tests.push({
    id: "diagnostic", kind: "diagnostic", track: "diagnostic",
    titleUz: "Bepul diagnostik test", titleAr: "الِاخْتِبَارُ التَّشْخِيصِيّ",
    descUz: "Grammatika, leksika, o‘qish va tinglash bo‘yicha 20 ta savol. Natijada taxminiy CEFR darajangiz va kuchsiz ko‘nikmalaringiz ko‘rsatiladi.",
    levels: LEVELS, skills: ["grammar", "vocabulary", "reading", "listening"],
    count: 20, minutes: 20, free: true, gated: true
  });

  // Darajaviy: per level × 6 test types
  const darajaviyTypes = [
    { key: "placement", uz: "Joylashtiruv testi", ar: "اِخْتِبَارُ تَحْدِيدِ الْمُسْتَوَى", skills: ["grammar", "vocabulary", "reading", "listening"], count: 12, minutes: 15 },
    { key: "grammar", uz: "Grammatika testi", ar: "اِخْتِبَارُ الْقَوَاعِد", skills: ["grammar"], count: 8, minutes: 10 },
    { key: "vocabulary", uz: "Leksika testi", ar: "اِخْتِبَارُ الْمُفْرَدَات", skills: ["vocabulary"], count: 8, minutes: 8 },
    { key: "reading", uz: "O‘qish testi", ar: "اِخْتِبَارُ الْقِرَاءَة", skills: ["reading"], count: 6, minutes: 12 },
    { key: "listening", uz: "Tinglash testi", ar: "اِخْتِبَارُ الِاسْتِمَاع", skills: ["listening"], count: 6, minutes: 12 },
    { key: "full", uz: "To‘liq test", ar: "الِاخْتِبَارُ الْكَامِل", skills: ["grammar", "vocabulary", "reading", "listening"], count: 16, minutes: 25 }
  ];

  LEVELS.forEach(function (lv, li) {
    darajaviyTypes.forEach(function (tp) {
      tests.push({
        id: "darajaviy-" + lv + "-" + tp.key,
        kind: tp.key === "full" ? "mock" : "practice",
        track: "darajaviy",
        titleUz: lv.toUpperCase() + " — " + tp.uz,
        titleAr: tp.ar + " " + lv.toUpperCase(),
        descUz: lv.toUpperCase() + " darajasi uchun " + tp.uz.toLowerCase() + ". Savollar bazasidan har safar yangi to‘plam yig‘iladi.",
        levels: [lv], skills: tp.skills, count: tp.count, minutes: tp.minutes,
        free: li < 2 || tp.key === "placement"
      });
    });
  });

  // Multilevel & TANAL Arobiy sections
  const examSections = [
    { key: "reading", uz: "O‘qish", ar: "الْقِرَاءَة", skills: ["reading"], count: 6, minutes: 15 },
    { key: "listening", uz: "Tinglash", ar: "الِاسْتِمَاع", skills: ["listening"], count: 6, minutes: 15 },
    { key: "grammar", uz: "Grammatika", ar: "الْقَوَاعِد", skills: ["grammar"], count: 10, minutes: 12 },
    { key: "vocabulary", uz: "Leksika", ar: "الْمُفْرَدَات", skills: ["vocabulary"], count: 10, minutes: 10 },
    { key: "writing", uz: "Yozish", ar: "الْكِتَابَة", skills: ["writing"], count: 1, minutes: 30, type: "writing" },
    { key: "speaking", uz: "Gapirish", ar: "الْمُحَادَثَة", skills: ["speaking"], count: 1, minutes: 12, type: "speaking" }
  ];

  [
    { track: "multilevel", uz: "Multilevel", ar: "مُلْتِي لِيفِل" },
    { track: "tanal", uz: "TANAL Arobiy", ar: "تَنَال عَرَبِيّ" }
  ].forEach(function (exam) {
    examSections.forEach(function (sec, i) {
      tests.push({
        id: exam.track + "-" + sec.key,
        kind: "practice", track: exam.track, section: sec.key, type: sec.type || "mcq",
        titleUz: exam.uz + " — " + sec.uz, titleAr: sec.ar,
        descUz: exam.uz + " formatidagi " + sec.uz.toLowerCase() + " bo‘limi uchun mashq. Materiallar mustaqil tayyorgarlik uchun ishlab chiqilgan.",
        levels: ["b1", "b2", "c1"], skills: sec.skills, count: sec.count, minutes: sec.minutes,
        free: i < 2
      });
    });
    tests.push({
      id: exam.track + "-full",
      kind: "mock", track: exam.track,
      titleUz: exam.uz + " — to‘liq mock imtihon", titleAr: "اِخْتِبَارٌ تَجْرِيبِيٌّ كَامِل",
      descUz: "Barcha bo‘limlar ketma-ket, vaqt cheklovi bilan. Real imtihon tartibiga yaqinlashtirilgan simulyatsiya.",
      levels: ["b1", "b2", "c1"], skills: ["reading", "listening", "grammar", "vocabulary"],
      count: 24, minutes: 50, free: false, isFull: true
    });
  });

  tests.push({
    id: "daily-challenge", kind: "practice", track: "daily",
    titleUz: "Bugungi chaqiriq", titleAr: "تَحَدِّي الْيَوْم",
    descUz: "Har kuni yangilanadigan qisqa mashq: leksika, grammatika va tinglash.",
    levels: LEVELS, skills: ["vocabulary", "grammar", "listening"], count: 8, minutes: 8, free: true
  });

  TLA.data.tests = tests;
  TLA.data.testById = function (id) { return tests.filter(t => t.id === id)[0] || null; };
  TLA.data.testsByTrack = function (track) { return tests.filter(t => t.track === track); };

  TLA.data.examTracks = [
    { id: "multilevel", uz: "Multilevel", ar: "مُلْتِي لِيفِل", icon: "◈",
      descUz: "Multilevel formatidagi barcha bo‘limlar bo‘yicha mashq va to‘liq mock imtihon." },
    { id: "tanal", uz: "TANAL Arobiy", ar: "تَنَال عَرَبِيّ", icon: "◆",
      descUz: "TANAL Arobiy formatiga yo‘naltirilgan tayyorgarlik materiallari va mock testlar." },
    { id: "darajaviy", uz: "Darajaviy testlar", ar: "اِخْتِبَارَاتُ الْمُسْتَوَى", icon: "❖",
      descUz: "A1 dan C2 gacha har bir daraja uchun alohida test to‘plamlari." }
  ];

  /* ---------------- Library ---------------- */
  TLA.data.library = [
    { id: "lib-text-a1", titleUz: "O‘qish matni: Tanishuv", titleAr: "التَّعَارُف", type: "reading", format: "text",
      level: "a1", skill: "reading", free: true, opens: { kind: "text", id: "t_a1" },
      descUz: "A1 darajasi uchun tarjimasi bilan berilgan qisqa matn." },
    { id: "lib-text-a2", titleUz: "O‘qish matni: Mening o‘quv kunim", titleAr: "يَوْمِي الدِّرَاسِيّ", type: "reading", format: "text",
      level: "a2", skill: "reading", free: true, opens: { kind: "text", id: "t_a2" },
      descUz: "Kundalik tartib mavzusidagi matn va tarjima." },
    { id: "lib-text-b1", titleUz: "O‘qish matni: Sayohat va turizm", titleAr: "السَّفَرُ وَالسِّيَاحَة", type: "reading", format: "text",
      level: "b1", skill: "reading", free: true, opens: { kind: "text", id: "t_b1" },
      descUz: "B1 darajasi uchun sayohat mavzusidagi matn." },
    { id: "lib-text-b2", titleUz: "O‘qish matni: Texnologiya asrida ta’lim", titleAr: "التَّعْلِيمُ فِي عَصْرِ التِّقْنِيَة", type: "reading", format: "text",
      level: "b2", skill: "reading", free: false, opens: { kind: "text", id: "t_b2" },
      descUz: "Munozarali mavzuda akademik uslubdagi matn." },
    { id: "lib-text-c1", titleUz: "O‘qish matni: Atrof-muhit va rivojlanish", titleAr: "الْبِيئَةُ وَالتَّنْمِيَة", type: "reading", format: "text",
      level: "c1", skill: "reading", free: false, opens: { kind: "text", id: "t_c1" },
      descUz: "C1 darajasi uchun dalil-isbotga asoslangan matn." },
    { id: "lib-text-c2", titleUz: "O‘qish matni: Til va o‘zlik", titleAr: "اللُّغَةُ وَالْهُوِيَّة", type: "reading", format: "text",
      level: "c2", skill: "reading", free: false, opens: { kind: "text", id: "t_c2" },
      descUz: "Yuqori daraja uchun nazariy-tahliliy matn." },

    { id: "lib-aud-a1", titleUz: "Tinglash: Universitetda", titleAr: "فِي الْجَامِعَة", type: "audio", format: "audio",
      level: "a1", skill: "listening", free: true, opens: { kind: "script", id: "s_a1" },
      descUz: "Qisqa monolog, matni bilan. Talaffuz mashqi uchun ham mos." },
    { id: "lib-aud-a2", titleUz: "Tinglash: E’lon", titleAr: "إِعْلَانٌ فِي الْمَعْهَد", type: "audio", format: "audio",
      level: "a2", skill: "listening", free: true, opens: { kind: "script", id: "s_a2" },
      descUz: "Rasmiy e’lon uslubi: vaqt, joy va shartlar." },
    { id: "lib-aud-b1", titleUz: "Tinglash: Mehmonxonada", titleAr: "حَجْزٌ فِي الْفُنْدُق", type: "audio", format: "audio",
      level: "b1", skill: "listening", free: false, opens: { kind: "script", id: "s_b1" },
      descUz: "Dialog: xona band qilish, narx va shartlarni so‘rash." },
    { id: "lib-aud-b2", titleUz: "Tinglash: Onlayn ta’lim", titleAr: "مُحَاضَرَةٌ قَصِيرَة", type: "audio", format: "audio",
      level: "b2", skill: "listening", free: false, opens: { kind: "script", id: "s_b2" },
      descUz: "Qisqa ma’ruza — akademik tinglash mashqi." },
    { id: "lib-aud-c1", titleUz: "Tinglash: Yangiliklar", titleAr: "نَشْرَةٌ إِخْبَارِيَّة", type: "audio", format: "audio",
      level: "c1", skill: "listening", free: false, opens: { kind: "script", id: "s_c1" },
      descUz: "Axborot uslubi: raqamlar, tashkilotlar, chaqiriqlar." },

    { id: "lib-gr-a1", titleUz: "Grammatika: Ismli jumla", titleAr: "الْجُمْلَةُ الِاسْمِيَّة", type: "grammar", format: "note",
      level: "a1", skill: "grammar", free: true, opens: { kind: "grammar", id: "g_a1_jumla" },
      descUz: "Mubtado va xabar, i’rob holatlari, misollar." },
    { id: "lib-gr-a2", titleUz: "Grammatika: كان va singillari", titleAr: "كَانَ وَأَخَوَاتُهَا", type: "grammar", format: "note",
      level: "a2", skill: "grammar", free: true, opens: { kind: "grammar", id: "g_a2_kana" },
      descUz: "Ismli jumlaga كان kirganda i’rob qanday o‘zgaradi." },
    { id: "lib-gr-b1", titleUz: "Grammatika: إنّ va singillari", titleAr: "إِنَّ وَأَخَوَاتُهَا", type: "grammar", format: "note",
      level: "b1", skill: "grammar", free: false, opens: { kind: "grammar", id: "g_b1_inna" },
      descUz: "إنّ guruhining ta’siri va كان bilan farqi." },
    { id: "lib-gr-b2", titleUz: "Grammatika: Majhul nisbat", titleAr: "الْمَبْنِيُّ لِلْمَجْهُول", type: "grammar", format: "note",
      level: "b2", skill: "grammar", free: false, opens: { kind: "grammar", id: "g_b2_majhul" },
      descUz: "Mozi va mudori’da majhul yasash qoidalari." },
    { id: "lib-gr-c1", titleUz: "Grammatika: Shart uslubi", titleAr: "أُسْلُوبُ الشَّرْط", type: "grammar", format: "note",
      level: "c1", skill: "grammar", free: false, opens: { kind: "grammar", id: "g_c1_shart" },
      descUz: "Shart edatlari, jazm va javob jumlasi." },

    { id: "lib-voc-500", titleUz: "500 ta eng kerakli arabcha so‘z", titleAr: "٥٠٠ كَلِمَة أَسَاسِيَّة", type: "vocabulary", format: "list",
      level: "a1", skill: "vocabulary", free: true, opens: { kind: "dictionary" },
      descUz: "Lug‘at bo‘limidagi asosiy so‘zlar to‘plami — takrorlash rejasi bilan." },
    { id: "lib-pdf-mult", titleUz: "Multilevel: bo‘limlar bo‘yicha qo‘llanma (PDF)", titleAr: "دَلِيلُ الِاخْتِبَار", type: "exam", format: "pdf",
      level: "b1", skill: "reading", free: false, opens: { kind: "managed" },
      descUz: "Fayl admin panel orqali yuklanadi. Demo rejimda fayl biriktirilmagan." },
    { id: "lib-vid-intro", titleUz: "Video dars: Arab alifbosi", titleAr: "الْحُرُوفُ الْعَرَبِيَّة", type: "video", format: "video",
      level: "a1", skill: "reading", free: true, opens: { kind: "managed" },
      descUz: "Video fayl admin panel orqali biriktiriladi. Demo rejimda ko‘rsatilmaydi." }
  ];

  /* ---------------- Dictionary ---------------- */
  TLA.data.dictionary = [
    { ar: "مَكْتَبَة", tr: "maktaba", uz: "kutubxona", root: "ك ت ب", level: "a1", ex: "أَذْهَبُ إِلَى الْمَكْتَبَةِ كُلَّ يَوْمٍ.", exUz: "Har kuni kutubxonaga boraman.", rel: ["كِتَاب", "كَاتِب", "مَكْتُوب"] },
    { ar: "أُسْرَة", tr: "usra", uz: "oila", root: "أ س ر", level: "a1", ex: "أُسْرَتِي كَبِيرَةٌ.", exUz: "Oilam katta.", rel: ["عَائِلَة", "أَهْل"] },
    { ar: "صَبَاح", tr: "sabāh", uz: "tong, ertalab", root: "ص ب ح", level: "a1", ex: "صَبَاحُ الْخَيْرِ يَا أُسْتَاذُ.", exUz: "Xayrli tong, ustoz.", rel: ["مَسَاء", "صَبَاحًا"] },
    { ar: "سُوق", tr: "sūq", uz: "bozor", root: "س و ق", level: "a1", ex: "اِشْتَرَيْتُ الْفَاكِهَةَ مِنَ السُّوقِ.", exUz: "Bozordan meva sotib oldim.", rel: ["تَسَوُّق", "بَائِع"] },
    { ar: "بَيْت", tr: "bayt", uz: "uy", root: "ب ي ت", level: "a1", ex: "بَيْتُنَا قَرِيبٌ مِنَ الْمَدْرَسَةِ.", exUz: "Uyimiz maktabga yaqin.", rel: ["مَنْزِل", "سَكَن"] },
    { ar: "مُعَلِّم", tr: "muallim", uz: "o‘qituvchi", root: "ع ل م", level: "a1", ex: "الْمُعَلِّمُ يَشْرَحُ الدَّرْسَ.", exUz: "O‘qituvchi darsni tushuntiryapti.", rel: ["عِلْم", "تَعْلِيم", "طَالِب"] },
    { ar: "مُسْتَشْفَى", tr: "mustashfā", uz: "kasalxona", root: "ش ف ي", level: "a2", ex: "الْمُسْتَشْفَى قَرِيبٌ مِنْ هُنَا.", exUz: "Kasalxona bu yerdan yaqin.", rel: ["شِفَاء", "طَبِيب", "صَيْدَلِيَّة"] },
    { ar: "رِسَالَة", tr: "risāla", uz: "xat, xabar", root: "ر س ل", level: "a2", ex: "كَتَبْتُ رِسَالَةً إِلَى صَدِيقِي.", exUz: "Do‘stimga xat yozdim.", rel: ["مُرْسِل", "إِرْسَال"] },
    { ar: "مِفْتَاح", tr: "miftāh", uz: "kalit", root: "ف ت ح", level: "a2", ex: "أَيْنَ مِفْتَاحُ الْبَابِ؟", exUz: "Eshikning kaliti qayerda?", rel: ["فَتَحَ", "مَفْتُوح"] },
    { ar: "حَافِلَة", tr: "hāfila", uz: "avtobus", root: "ح ف ل", level: "a2", ex: "أَرْكَبُ الْحَافِلَةَ صَبَاحًا.", exUz: "Ertalab avtobusga chiqaman.", rel: ["مَحَطَّة", "رُكُوب"] },
    { ar: "بَعِيد", tr: "ba'īd", uz: "uzoq", root: "ب ع د", level: "a2", ex: "الْمَطَارُ بَعِيدٌ عَنِ الْمَدِينَةِ.", exUz: "Aeroport shahardan uzoq.", rel: ["قَرِيب", "مَسَافَة"] },
    { ar: "فُنْدُق", tr: "funduq", uz: "mehmonxona", root: "ف ن د ق", level: "b1", ex: "حَجَزْتُ غُرْفَةً فِي الْفُنْدُقِ.", exUz: "Mehmonxonadan xona band qildim.", rel: ["حَجْز", "غُرْفَة", "نُزُل"] },
    { ar: "تَذْكِرَة", tr: "tadhkira", uz: "chipta", root: "ذ ك ر", level: "b1", ex: "اِشْتَرَيْتُ تَذْكِرَةَ الطَّائِرَةِ.", exUz: "Samolyot chiptasini sotib oldim.", rel: ["حَجْز", "سَفَر"] },
    { ar: "حُرِّيَّة", tr: "hurriya", uz: "erkinlik", root: "ح ر ر", level: "b1", ex: "يَشْعُرُ بِحُرِّيَّةٍ أَكْبَرَ.", exUz: "U o‘zini erkinroq his qiladi.", rel: ["حُرّ", "تَحْرِير"] },
    { ar: "عَادَة", tr: "'āda", uz: "odat", root: "ع و د", level: "b1", ex: "تَخْتَلِفُ عَادَاتُ النَّاسِ.", exUz: "Odamlarning odatlari farq qiladi.", rel: ["تَقْلِيد", "اِعْتِيَاد"] },
    { ar: "تَخْطِيط", tr: "takhtīt", uz: "rejalashtirish", root: "خ ط ط", level: "b1", ex: "التَّخْطِيطُ نِصْفُ النَّجَاحِ.", exUz: "Rejalashtirish — muvaffaqiyatning yarmi.", rel: ["خُطَّة", "مُخَطَّط"] },
    { ar: "اِقْتِصَاد", tr: "iqtisād", uz: "iqtisodiyot", root: "ق ص د", level: "b2", ex: "يَنْمُو الِاقْتِصَادُ بِبُطْءٍ.", exUz: "Iqtisodiyot sekin o‘smoqda.", rel: ["اِقْتِصَادِيّ", "سُوق"] },
    { ar: "بَحْث", tr: "bahth", uz: "tadqiqot", root: "ب ح ث", level: "b2", ex: "نَشَرَ بَحْثًا جَدِيدًا.", exUz: "U yangi tadqiqot chop etdi.", rel: ["بَاحِث", "دِرَاسَة"] },
    { ar: "تَحَدٍّ", tr: "tahaddin", uz: "chaqiriq, sinov", root: "ح د و", level: "b2", ex: "هٰذَا تَحَدٍّ كَبِيرٌ لَنَا.", exUz: "Bu biz uchun katta sinov.", rel: ["تَحَدِّيَات", "صُعُوبَة"] },
    { ar: "إِنْتَاج", tr: "intāj", uz: "ishlab chiqarish", root: "ن ت ج", level: "b2", ex: "زَادَ إِنْتَاجُ الْمَصْنَعِ.", exUz: "Zavod ishlab chiqarishi ortdi.", rel: ["مُنْتَج", "اِسْتِهْلَاك"] },
    { ar: "مُسْتَدَام", tr: "mustadām", uz: "barqaror", root: "د و م", level: "c1", ex: "التَّنْمِيَةُ الْمُسْتَدَامَةُ ضَرُورَةٌ.", exUz: "Barqaror rivojlanish — zarurat.", rel: ["اِسْتِدَامَة", "دَائِم"] },
    { ar: "اِسْتِنْزَاف", tr: "istinzāf", uz: "tugatib yuborish", root: "ن ز ف", level: "c1", ex: "اِسْتِنْزَافُ الْمَوَارِدِ خَطَرٌ.", exUz: "Resurslarni tugatish — xavf.", rel: ["مَوَارِد", "اِسْتِهْلَاك"] },
    { ar: "تَشْرِيع", tr: "tashrī'", uz: "qonunchilik", root: "ش ر ع", level: "c1", ex: "يُنَاقِشُ الْبَرْلَمَانُ التَّشْرِيعَ.", exUz: "Parlament qonunchilikni muhokama qilmoqda.", rel: ["قَانُون", "شَرِيعَة"] },
    { ar: "مُوَازَنَة", tr: "muwāzana", uz: "muvozanat", root: "و ز ن", level: "c1", ex: "لَا بُدَّ مِنْ مُوَازَنَةٍ بَيْنَ الْأَمْرَيْنِ.", exUz: "Ikki narsa o‘rtasida muvozanat kerak.", rel: ["تَوَازُن", "مِيزَان"] },
    { ar: "ذَاكِرَة", tr: "dhākira", uz: "xotira", root: "ذ ك ر", level: "c2", ex: "اللُّغَةُ ذَاكِرَةٌ جَمَاعِيَّةٌ.", exUz: "Til — jamoaviy xotira.", rel: ["تَذَكُّر", "ذِكْرَى"] },
    { ar: "تَذَوُّق", tr: "tadhawwuq", uz: "did bilan idrok etish", root: "ذ و ق", level: "c2", ex: "التَّذَوُّقُ الْأَدَبِيُّ مَهَارَةٌ.", exUz: "Adabiy did — mahorat.", rel: ["ذَوْق", "نَقْد"] },
    { ar: "تَأْوِيل", tr: "ta'wīl", uz: "talqin", root: "أ و ل", level: "c2", ex: "لِكُلِّ نَصٍّ تَأْوِيلَاتٌ.", exUz: "Har bir matnning talqinlari bor.", rel: ["تَفْسِير", "قِرَاءَة"] },
    { ar: "هُوِيَّة", tr: "huwiyya", uz: "o‘zlik, identitet", root: "ه و", level: "c2", ex: "اللُّغَةُ جُزْءٌ مِنَ الْهُوِيَّةِ.", exUz: "Til — o‘zlikning bir qismi.", rel: ["اِنْتِمَاء", "ثَقَافَة"] }
  ];

  /* ---------------- Blog ---------------- */
  TLA.data.blog = [
    {
      slug: "arab-tilini-noldan-boshlash", cat: "Study Tips", minutes: 6, date: "2026-05-18",
      titleUz: "Arab tilini noldan boshlash: birinchi 30 kun uchun reja",
      glyph: "بَدْء",
      excerptUz: "Alifbodan boshlab birinchi jumlagacha — kunlik 30 daqiqada nimalarni bajarish kerak.",
      bodyUz: [
        { h: "Nega ko‘pchilik birinchi oyda to‘xtaydi" },
        { p: "Arab tilini boshlaganlarning katta qismi alifboni yodlashga haddan ortiq vaqt sarflaydi va jonli tilga o‘tishga ulgurmaydi. Natijada harflarni tanigan, lekin bironta jumla tuza olmaydigan holat yuzaga keladi. Buning yechimi oddiy: harf o‘rganish bilan jumla tuzishni birinchi kundanoq birga olib borish." },
        { h: "Birinchi 30 kun uchun taqsimot" },
        { p: "Kunlik 30 daqiqani uchga bo‘ling: 10 daqiqa harf va talaffuz, 10 daqiqa so‘z, 10 daqiqa jumla. Birinchi haftada 8 ta harf va 20 ta so‘z yetarli. Ikkinchi haftadan boshlab har kuni kamida uchta jumlani ovoz chiqarib o‘qing va yozing." },
        { p: "Uchinchi haftada ismli jumlaga o‘ting: الْبَيْتُ كَبِيرٌ, الطَّالِبُ مُجْتَهِدٌ. Bu tuzilma arab tilining eng ko‘p ishlatiladigan asosidir va uni erta o‘zlashtirish keyingi barcha mavzularni yengillashtiradi." },
        { h: "Takrorlash — asosiy vosita" },
        { p: "Yangi so‘zni bir marta ko‘rish yetarli emas. Uni birinchi kuni, keyin 2-kun, 4-kun, 7-kun va 15-kuni takrorlang. Platformadagi «Mening lug‘atim» bo‘limi bu jadvalni avtomatik yuritadi: so‘zni saqlaganingizda takrorlash sanasi o‘zi belgilanadi." },
        { h: "Nimadan qochish kerak" },
        { p: "Bir vaqtning o‘zida uchta darslik bo‘yicha o‘qishdan, faqat video tomosha qilishdan va yozuvsiz o‘rganishdan saqlaning. Qo‘l bilan yozish arab tilida harf shakllarini eslab qolishning eng tez usuli bo‘lib qolmoqda." }
      ]
    },
    {
      slug: "multilevel-tinglash-strategiyasi", cat: "Multilevel", minutes: 7, date: "2026-05-02",
      titleUz: "Multilevel tinglash bo‘limi: ball yo‘qotmaslikning 6 qoidasi",
      glyph: "سَمْع",
      excerptUz: "Audio boshlanishidan oldingi 20 soniya natijangizni belgilaydi. Nima qilish kerak?",
      bodyUz: [
        { h: "1. Savollarni audiodan oldin o‘qing" },
        { p: "Audio boshlanguncha berilgan qisqa vaqtda savollarni ko‘zdan kechiring va har birida qanday ma’lumot so‘ralayotganini belgilang: raqammi, joymi, sababmi. Bu «nimani tinglash kerak» degan savolga oldindan javob beradi." },
        { h: "2. Raqam va ismlarni alohida kuzating" },
        { p: "Arab tilidagi sonlar tinglashda eng ko‘p xato keltiradigan qism. مِائَة وَعِشْرُون, ثَلَاث لَيَالٍ kabi birikmalarni oldindan mashq qiling." },
        { h: "3. Birinchi eshitishda hamma narsani tushunishga urinmang" },
        { p: "Birinchi tinglashda umumiy mavzuni va tuzilmani ushlang, ikkinchisida aniq ma’lumotlarni to‘ldiring. Bitta so‘zga osilib qolish keyingi ikki savolni ham yo‘qotadi." },
        { h: "4. Sinonimlarga tayyor turing" },
        { p: "Savolda سَيَّارَة deyilgan bo‘lsa, audioda مَرْكَبَة yoki بِالسَّيَّارَةِ shaklida kelishi mumkin. Testlar aynan takrorlanish emas, ma’no mosligini tekshiradi." },
        { h: "5. Javobsiz qoldirmang" },
        { p: "Noto‘g‘ri javob uchun ball ayirilmaydigan formatlarda bo‘sh qoldirish — sof yo‘qotish. Variantlarni taqqoslab, ehtimoli yuqori javobni belgilang." },
        { h: "6. Har hafta 3 ta tinglash mashqi" },
        { p: "Kam-kam, lekin muntazam. Platformadagi tinglash testlarini haftada uch marta topshiring va har safar noto‘g‘ri javoblarni matn bilan solishtiring — bu bo‘lim eng tez o‘sadigan ko‘nikma hisoblanadi." }
      ]
    },
    {
      slug: "inna-va-kana-farqi", cat: "Arabic Grammar", minutes: 5, date: "2026-04-21",
      titleUz: "كان va إنّ: bir jumlada i’rob nega teskari o‘zgaradi",
      glyph: "نَحْو",
      excerptUz: "Ikki mavzu ko‘pincha aralashtiriladi. Farqini bir jadvalda tushunib oling.",
      bodyUz: [
        { h: "Asosiy qoida" },
        { p: "Ismli jumlada ega ham, kesim ham marfu’ bo‘ladi: الطَّالِبُ مُجْتَهِدٌ. Ushbu jumlaga كان kirsa, ega marfu’ qoladi, kesim mansubga aylanadi: كَانَ الطَّالِبُ مُجْتَهِدًا." },
        { p: "إنّ kirsa esa buning aksi bo‘ladi: ega mansub, kesim marfu’: إِنَّ الطَّالِبَ مُجْتَهِدٌ. Shu bir jumla ustida ikkala holatni yonma-yon yozib chiqish — eng tez eslab qolish usuli." },
        { h: "Nega bu imtihonda muhim" },
        { p: "Grammatika bo‘limidagi savollarning sezilarli qismi aynan shu ikki guruh ustida quriladi, chunki ular i’robni ko‘rsatadigan eng aniq belgi hisoblanadi. Bitta harakat belgisi javobni butunlay o‘zgartiradi." },
        { h: "Mashq" },
        { p: "Quyidagi jumlani uch shaklda yozing: الْجَوُّ جَمِيلٌ / كَانَ الْجَوُّ جَمِيلًا / إِنَّ الْجَوَّ جَمِيلٌ. So‘ng platformadagi B1 grammatika testini topshiring va xatolaringizni izohlar bilan solishtiring." }
      ]
    },
    {
      slug: "yozish-bolimi-tuzilma", cat: "Writing", minutes: 6, date: "2026-04-09",
      titleUz: "Yozish bo‘limida yuqori ball uchun tuzilma",
      glyph: "كِتَابَة",
      excerptUz: "150 so‘zlik insho ham aniq tuzilmani talab qiladi. Mana ishlaydigan sxema.",
      bodyUz: [
        { h: "To‘rt qismli sxema" },
        { p: "Kirish (1–2 jumla), asosiy fikr (3–4 jumla), qarshi fikr yoki misol (2–3 jumla), xulosa (1–2 jumla). Bu tuzilma har qanday mavzuga mos keladi va tekshiruvchiga matn mantiqini darhol ko‘rsatadi." },
        { h: "Bog‘lovchilarni ishlating" },
        { p: "أَوَّلًا، ثُمَّ، بِالْإِضَافَةِ إِلَى ذٰلِكَ، غَيْرَ أَنَّ، وَفِي الْخِتَامِ — bu iboralar matnni bo‘laklarga ajratadi va uslub darajasini ko‘taradi. Har bir insho uchun kamida to‘rttasini ishlating." },
        { h: "Xatolar ustida ishlash" },
        { p: "Yozganingizni bir kundan keyin o‘qing va faqat uch narsani tekshiring: fe’l zamoni mosmi, i’rob belgilari to‘g‘rimi, jumlalar juda uzun emasmi. Uch marta tekshirilgan bitta insho — tekshirilmagan uchta inshodan foydali." },
        { h: "Baholash haqida" },
        { p: "Platformadagi yozish mashqlari o‘zingizni baholash mezoni bilan beriladi: mazmun, tuzilma, grammatika, leksika. Bu — mustaqil mashq uchun ko‘rsatkich; rasmiy imtihon bahosi emas." }
      ]
    },
    {
      slug: "lugat-yodlash-usuli", cat: "Vocabulary", minutes: 5, date: "2026-03-27",
      titleUz: "So‘z yodlashning ishlaydigan usuli: o‘zak orqali o‘rganish",
      glyph: "جَذْر",
      excerptUz: "Bitta o‘zakdan o‘nlab so‘z chiqadi. Shuni bilsangiz, lug‘at ikki barobar tez o‘sadi.",
      bodyUz: [
        { h: "O‘zak nima beradi" },
        { p: "ك-ت-ب o‘zagidan كَتَبَ (yozdi), كِتَاب (kitob), كَاتِب (yozuvchi), مَكْتَب (ofis), مَكْتَبَة (kutubxona), مَكْتُوب (yozilgan) kabi so‘zlar hosil bo‘ladi. Bitta o‘zakni bilish orqali notanish so‘zning ma’nosini taxmin qilish imkoni paydo bo‘ladi." },
        { h: "Amaliy usul" },
        { p: "Yangi so‘zni yozganda uch ustunli jadval tuzing: o‘zak — so‘z — misol jumla. Haftada o‘nta o‘zak yetarli; bir oyda bu 40 ta o‘zak va yuzdan ortiq so‘z demakdir." },
        { h: "Takrorlash oralig‘i" },
        { p: "So‘zni saqlaganingizdan keyin uni 1, 3, 7, 15 va 30-kunlarda takrorlang. Platforma bu jadvalni avtomatik tuzadi va «takrorlash vaqti kelgan so‘zlar» ro‘yxatini ko‘rsatadi." }
      ]
    },
    {
      slug: "daraja-aniqlash-nima-beradi", cat: "Study Tips", minutes: 4, date: "2026-03-12",
      titleUz: "Darajani aniqlash nega o‘qishni tezlashtiradi",
      glyph: "مُسْتَوَى",
      excerptUz: "Noto‘g‘ri darajadan boshlash — vaqtni yo‘qotishning eng keng tarqalgan sababi.",
      bodyUz: [
        { h: "Ikki xato" },
        { p: "Birinchi xato — o‘zidan pastroq darajadan boshlash: o‘quvchi zerikadi va tashlab yuboradi. Ikkinchisi — yuqoriroq darajadan boshlash: matnlar tushunarsiz bo‘ladi va motivatsiya tez tushadi. Ikkalasi ham bir xil natijaga olib keladi." },
        { h: "Diagnostika nima ko‘rsatadi" },
        { p: "Diagnostik test umumiy ball emas, har bir ko‘nikma bo‘yicha alohida natija beradi. Ko‘pincha grammatika B1, tinglash esa A2 darajasida chiqadi — bu holda butun kursni qaytadan boshlash emas, faqat tinglashni mustahkamlash kerak bo‘ladi." },
        { h: "Keyingi qadam" },
        { p: "Natijadan so‘ng tizim eng kuchsiz ikki ko‘nikma bo‘yicha darslar va mashq testlarini tavsiya qiladi. Har 3–4 haftada diagnostikani takrorlab, o‘sishni raqamlarda ko‘rish mumkin." },
        { h: "Muhim eslatma" },
        { p: "Diagnostika natijasi taxminiy o‘quv ko‘rsatkichidir va rasmiy imtihon bahosi o‘rnini bosmaydi." }
      ]
    }
  ];

  TLA.data.blogBySlug = function (slug) { return TLA.data.blog.filter(b => b.slug === slug)[0] || null; };

  /* ---------------- Achievements ---------------- */
  TLA.data.achievements = [
    { id: "first-lesson", uz: "Birinchi dars", ar: "الدَّرْسُ الْأَوَّل", icon: "◎", cond: { lessons: 1 } },
    { id: "first-test", uz: "Birinchi test", ar: "الِاخْتِبَارُ الْأَوَّل", icon: "◈", cond: { attempts: 1 } },
    { id: "streak-7", uz: "7 kunlik seriya", ar: "٧ أَيَّام", icon: "✦", cond: { streak: 7 } },
    { id: "streak-30", uz: "30 kunlik seriya", ar: "٣٠ يَوْمًا", icon: "✵", cond: { streak: 30 } },
    { id: "q-100", uz: "100 ta savol", ar: "١٠٠ سُؤَال", icon: "❋", cond: { questions: 100 } },
    { id: "reading-master", uz: "O‘qish ustasi", ar: "مَاهِرُ الْقِرَاءَة", icon: "◆", cond: { skill: "reading", score: 85 } },
    { id: "listening-master", uz: "Tinglash ustasi", ar: "مَاهِرُ الِاسْتِمَاع", icon: "◉", cond: { skill: "listening", score: 85 } },
    { id: "grammar-master", uz: "Grammatika ustasi", ar: "مَاهِرُ الْقَوَاعِد", icon: "❖", cond: { skill: "grammar", score: 85 } },
    { id: "mock-champion", uz: "Mock chempioni", ar: "بَطَلُ الِاخْتِبَار", icon: "♛", cond: { mockScore: 90 } },
    { id: "course-done", uz: "Kurs yakunlandi", ar: "إِتْمَامُ الدَّوْرَة", icon: "✷", cond: { courseDone: 1 } }
  ];

  /* ---------------- Plans (prices editable in admin) ---------------- */
  TLA.data.defaultPlans = [
    { id: "free", uz: "Bepul", ar: "مَجَّانِيّ", price: 0, featured: false,
      features: [
        { uz: "Diagnostik test", on: true },
        { uz: "Cheklangan darslar (A1)", on: true },
        { uz: "Haftasiga 3 ta mashq testi", on: true },
        { uz: "Asosiy progress ko‘rsatkichlari", on: true },
        { uz: "To‘liq mock imtihonlar", on: false },
        { uz: "Sertifikat", on: false }
      ] },
    { id: "standard", uz: "Standart", ar: "قِيَاسِيّ", price: 89000, featured: false,
      features: [
        { uz: "Barcha A1–B1 kurslari", on: true },
        { uz: "Cheklanmagan mashq testlari", on: true },
        { uz: "Ko‘nikmalar bo‘yicha tahlil", on: true },
        { uz: "Kutubxonaning bepul qismi", on: true },
        { uz: "To‘liq mock imtihonlar", on: false },
        { uz: "Sertifikat", on: false }
      ] },
    { id: "premium", uz: "Premium", ar: "مُمَيَّز", price: 149000, featured: true,
      features: [
        { uz: "Barcha kurslar (A1–C2)", on: true },
        { uz: "To‘liq mock imtihonlar", on: true },
        { uz: "Kengaytirilgan analitika", on: true },
        { uz: "Yozish va gapirish mashqlari", on: true },
        { uz: "Sertifikat", on: true },
        { uz: "Kutubxonaning to‘liq qismi", on: true }
      ] },
    { id: "all", uz: "All Access", ar: "وُصُولٌ كَامِل", price: 219000, featured: false,
      features: [
        { uz: "Premium tarkibidagi hammasi", on: true },
        { uz: "Multilevel tayyorgarligi", on: true },
        { uz: "TANAL Arobiy tayyorgarligi", on: true },
        { uz: "Darajaviy testlar to‘plami", on: true },
        { uz: "Barcha kutubxona materiallari", on: true },
        { uz: "Ustuvor qo‘llab-quvvatlash", on: true }
      ] }
  ];

  TLA.data.paymentMethods = [
    { id: "click", name: "Click", color: "#0099ff" },
    { id: "payme", name: "Payme", color: "#00c8d7" },
    { id: "uzum", name: "Uzum Bank", color: "#7b3ff2" },
    { id: "visa", name: "Visa", color: "#1a1f71" },
    { id: "mc", name: "Mastercard", color: "#c8102e" }
  ];

  /* ---------------- Platform config ----------------
     Base values below are overridden at build time by site.config.json
     (injected as window.TLA_SITE_CONFIG), so a deployed site shows the
     owner's real contacts to every visitor — not just to the admin who
     typed them into their own browser. */
  const baseConfig = {
    contact: {
      phone: "",           // set in admin panel
      email: "",
      telegram: "",
      address: "",
      workHours: ""
    },
    social: { telegram: "", instagram: "", youtube: "" },
    currency: "so'm",
    certificatePrefix: "TLA",
    verifyBaseUrl: "https://example.org/verify/"
  };

  function deepMerge(base, override) {
    const out = Object.assign({}, base);
    Object.keys(override || {}).forEach(function (key) {
      const value = override[key];
      if (value && typeof value === "object" && !Array.isArray(value)) {
        out[key] = deepMerge(base[key] || {}, value);
      } else if (value !== undefined && value !== "") {
        out[key] = value;
      }
    });
    return out;
  }

  const siteConfig = window.TLA_SITE_CONFIG || {};
  TLA.data.defaultConfig = deepMerge(baseConfig, siteConfig);
  TLA.data.configVersion = siteConfig.version || 0;
  TLA.data.siteUrl = siteConfig.siteUrl || "";

  /* ---------------- Legal documents (templates) ---------------- */
  TLA.data.legal = {
    privacy: {
      titleUz: "Maxfiylik siyosati",
      updated: "2026-05-01",
      sections: [
        { h: "Qanday ma’lumot yig‘amiz", p: "Ro‘yxatdan o‘tishda ism va email; foydalanish jarayonida test natijalari, dars progressi va sozlamalar. Demo rejimda bu ma’lumotlar faqat sizning qurilmangizda saqlanadi va serverga yuborilmaydi." },
        { h: "Nima uchun ishlatamiz", p: "Faqat ta’lim xizmatini ko‘rsatish, natijalarni ko‘rsatish va tavsiyalar berish uchun. Ma’lumotlar reklama maqsadida uchinchi shaxslarga sotilmaydi." },
        { h: "Saqlash muddati", p: "Hisob faol bo‘lgan davrda. Hisobni o‘chirganingizda bog‘liq ma’lumotlar ham o‘chiriladi." },
        { h: "Sizning huquqlaringiz", p: "Ma’lumotlaringizni yuklab olish, tuzatish va o‘chirishni so‘rash huquqiga egasiz. Profil bo‘limida ikkala amal ham mavjud." },
        { h: "Bolalar", p: "18 yoshgacha bo‘lgan foydalanuvchilar platformadan ota-ona yoki qonuniy vakil roziligi bilan foydalanishi kerak." },
        { h: "Eslatma", p: "Ushbu hujjat namuna sifatida berilgan. Ishga tushirishdan oldin yuridik mutaxassis tomonidan ko‘rib chiqilishi va tashkilot rekvizitlari bilan to‘ldirilishi zarur." }
      ]
    },
    terms: {
      titleUz: "Foydalanish shartlari",
      updated: "2026-05-01",
      sections: [
        { h: "Xizmat tavsifi", p: "Platforma arab tili bo‘yicha o‘quv materiallari, mashqlar va test simulyatsiyalarini taqdim etadi." },
        { h: "Hisob", p: "Bitta hisob bitta shaxs uchun. Kirish ma’lumotlarini uchinchi shaxsga bermang." },
        { h: "Kontent huquqi", p: "Platformadagi materiallardan shaxsiy ta’lim maqsadida foydalanish mumkin; qayta nashr etish va tarqatish yozma ruxsatsiz taqiqlanadi." },
        { h: "Kafolatlar chegarasi", p: "Platforma imtihondan muayyan ball yoki natijani kafolatlamaydi va hech bir imtihon tashkilotining rasmiy vakili emas." },
        { h: "O‘zgarishlar", p: "Shartlar yangilanishi mumkin; muhim o‘zgarishlar haqida bildirishnoma yuboriladi." }
      ]
    },
    refund: {
      titleUz: "To‘lovni qaytarish siyosati",
      updated: "2026-05-01",
      sections: [
        { h: "Umumiy qoida", p: "Obuna sotib olingandan keyin 7 kun ichida va kurs materiallarining 20% dan kamrog‘i ochilgan bo‘lsa, to‘liq qaytarish so‘ralishi mumkin." },
        { h: "Qanday so‘raladi", p: "Aloqa bo‘limidagi shakl orqali buyurtma raqami bilan murojaat qilinadi. Ariza 3 ish kuni ichida ko‘rib chiqiladi." },
        { h: "Qaytarilmaydigan holatlar", p: "Sertifikat berilgan, kurs to‘liq yakunlangan yoki muddati tugagan aksiya narxida sotib olingan obunalar." },
        { h: "Muddat", p: "Ijobiy qaror qabul qilinsa, mablag‘ to‘lov tizimiga qarab 3–10 ish kunida qaytariladi." }
      ]
    },
    offer: {
      titleUz: "Ommaviy oferta",
      updated: "2026-05-01",
      sections: [
        { h: "Taraflar", p: "Bir tomondan xizmat ko‘rsatuvchi tashkilot (rekvizitlar admin panel orqali kiritiladi), ikkinchi tomondan platformadan foydalanuvchi." },
        { h: "Shartnoma predmeti", p: "Onlayn ta’lim xizmatlarini tanlangan tarif doirasida taqdim etish." },
        { h: "Aksept", p: "Ro‘yxatdan o‘tish va to‘lovni amalga oshirish oferta shartlarini to‘liq qabul qilish hisoblanadi." },
        { h: "Eslatma", p: "Ushbu matn namuna. Yuridik kuchga ega hujjat tashkilot rekvizitlari va yurist xulosasi bilan rasmiylashtiriladi." }
      ]
    }
  };
})();
