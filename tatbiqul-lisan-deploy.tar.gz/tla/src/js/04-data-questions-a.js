/* ============================================================
   QUESTION BANK — part 1: grammar & vocabulary
   Demo / practice material. Not official examination questions.
   Shape: { id, type, level, skill, topic, diff, promptUz, ar,
            opts, optsAr, ans, expUz, tags }
   ============================================================ */
window.TLA = window.TLA || {};
TLA.data = TLA.data || {};

TLA.data.questions = [
  /* ---------------- GRAMMAR · A1 ---------------- */
  { id: "g-a1-1", type: "mcq", level: "a1", skill: "grammar", topic: "jumla-ismiya", diff: "easy",
    promptUz: "Bo‘sh joyga mos so‘zni tanlang:", ar: "الْبَيْتُ ______ .",
    opts: ["كَبِيرٌ", "كَبِيرًا", "كَبِيرٍ", "الْكَبِيرُ"], optsAr: true, ans: 0,
    expUz: "Ismli jumlada xabar marfu‘ (dammali) va noaniq bo‘ladi: الْبَيْتُ كَبِيرٌ.", tags: ["mubtada", "xabar"] },

  { id: "g-a1-2", type: "mcq", level: "a1", skill: "grammar", topic: "ishora", diff: "easy",
    promptUz: "Mos ishora olmoshini tanlang:", ar: "______ كِتَابٌ جَدِيدٌ.",
    opts: ["هٰذَا", "هٰذِهِ", "أُولٰئِكَ", "هُمْ"], optsAr: true, ans: 0,
    expUz: "كِتَابٌ — muzakkar (erkak) ism, shuning uchun yaqin ishora olmoshi هٰذَا bo‘ladi.", tags: ["ishora"] },

  { id: "g-a1-3", type: "mcq", level: "a1", skill: "grammar", topic: "kopllik", diff: "easy",
    promptUz: "«قَلَمٌ» so‘zining ko‘pligi qaysi?", ar: "قَلَمٌ ← ______",
    opts: ["أَقْلَامٌ", "قَلَمَانِ", "قَلَمُونَ", "قُلُومٌ"], optsAr: true, ans: 0,
    expUz: "قَلَمٌ — jam‘i taksir (singan ko‘plik): أَقْلَامٌ. قَلَمَانِ esa ikkilik (musanna).", tags: ["jam"] },

  { id: "g-a1-4", type: "mcq", level: "a1", skill: "grammar", topic: "muannas", diff: "easy",
    promptUz: "«مُعَلِّمٌ» so‘zining muannas (ayol) shakli:", ar: "مُعَلِّمٌ ← ______",
    opts: ["مُعَلِّمَةٌ", "مُعَلِّمُونَ", "مُعَلِّمَانِ", "تَعْلِيمٌ"], optsAr: true, ans: 0,
    expUz: "Muannas shakli oxiriga ta marbuta (ة) qo‘shish bilan yasaladi: مُعَلِّمَةٌ.", tags: ["muannas"] },

  { id: "g-a1-5", type: "mcq", level: "a1", skill: "grammar", topic: "tarif", diff: "medium",
    promptUz: "Qaysi so‘zda «ال» talaffuzda assimilyatsiya bo‘ladi (harf shamsiya)?", ar: "",
    opts: ["الشَّمْس", "الْقَمَر", "الْبَيْت", "الْكِتَاب"], optsAr: true, ans: 0,
    expUz: "ش — quyosh harfi, shuning uchun «ال» dagi ل talaffuz qilinmay, keyingi harf shaddalanadi: ash-shams.", tags: ["tarif"] },

  /* ---------------- GRAMMAR · A2 ---------------- */
  { id: "g-a2-1", type: "mcq", level: "a2", skill: "grammar", topic: "mudari", diff: "easy",
    promptUz: "Mos fe’l shaklini tanlang:", ar: "أَنَا ______ اللُّغَةَ الْعَرَبِيَّةَ كُلَّ يَوْمٍ.",
    opts: ["أَدْرُسُ", "تَدْرُسُ", "يَدْرُسُ", "نَدْرُسُ"], optsAr: true, ans: 0,
    expUz: "«أَنَا» (men) uchun mudori’ fe’li أ harfi bilan boshlanadi: أَدْرُسُ.", tags: ["mudari"] },

  { id: "g-a2-2", type: "mcq", level: "a2", skill: "grammar", topic: "mozi", diff: "easy",
    promptUz: "Bo‘sh joyni to‘ldiring:", ar: "أَمْسِ ______ إِلَى الْمَكْتَبَةِ.",
    opts: ["ذَهَبْتُ", "أَذْهَبُ", "يَذْهَبُ", "اِذْهَبْ"], optsAr: true, ans: 0,
    expUz: "«أَمْسِ» (kecha) o‘tgan zamonni talab qiladi, so‘zlovchi men: ذَهَبْتُ.", tags: ["mozi"] },

  { id: "g-a2-3", type: "mcq", level: "a2", skill: "grammar", topic: "kana", diff: "medium",
    promptUz: "To‘g‘ri shaklni tanlang:", ar: "كَانَ الطَّقْسُ ______ .",
    opts: ["جَمِيلًا", "جَمِيلٌ", "جَمِيلٍ", "الْجَمِيلُ"], optsAr: true, ans: 0,
    expUz: "كَانَ kesimni (xabarni) mansub qiladi: كَانَ الطَّقْسُ جَمِيلًا.", tags: ["kana"] },

  { id: "g-a2-4", type: "mcq", level: "a2", skill: "grammar", topic: "inkor", diff: "medium",
    promptUz: "Mos shaklni tanlang:", ar: "لَمْ ______ الدَّرْسَ أَمْسِ.",
    opts: ["أَفْهَمْ", "أَفْهَمُ", "فَهِمْتُ", "أَفْهَمَ"], optsAr: true, ans: 0,
    expUz: "«لَمْ» mudori’ni majzum qiladi va ma’noni o‘tgan zamonga o‘tkazadi: لَمْ أَفْهَمْ.", tags: ["lam", "jazm"] },

  { id: "g-a2-5", type: "mcq", level: "a2", skill: "grammar", topic: "kelasi", diff: "easy",
    promptUz: "Kelasi zamonni ifodalovchi shakl:", ar: "______ إِلَى مِصْرَ فِي الصَّيْفِ.",
    opts: ["سَأُسَافِرُ", "سَافَرْتُ", "أُسَافِرُ الْآنَ", "لَمْ أُسَافِرْ"], optsAr: true, ans: 0,
    expUz: "سَـ yoki سَوْفَ mudori’ fe’liga qo‘shilib kelasi zamonni bildiradi: سَأُسَافِرُ.", tags: ["kelasi"] },

  /* ---------------- GRAMMAR · B1 ---------------- */
  { id: "g-b1-1", type: "mcq", level: "b1", skill: "grammar", topic: "inna", diff: "medium",
    promptUz: "To‘g‘ri shaklni tanlang:", ar: "إِنَّ ______ مُجْتَهِدُونَ.",
    opts: ["الطُّلَّابَ", "الطُّلَّابُ", "الطُّلَّابِ", "طُلَّابٌ"], optsAr: true, ans: 0,
    expUz: "إِنَّ egani mansub, kesimni marfu‘ qiladi — كان ning teskarisi: إِنَّ الطُّلَّابَ مُجْتَهِدُونَ.", tags: ["inna"] },

  { id: "g-b1-2", type: "mcq", level: "b1", skill: "grammar", topic: "amr", diff: "medium",
    promptUz: "«تَكْتُبُ» fe’lining buyruq shakli:", ar: "تَكْتُبُ ← ______",
    opts: ["اُكْتُبْ", "كَتَبْتَ", "تَكْتُبَ", "مَكْتُوبٌ"], optsAr: true, ans: 0,
    expUz: "Buyruq mudori’dan yasaladi: harakat harfi tushiriladi va hamzatul-vasl qo‘shiladi — اُكْتُبْ.", tags: ["amr"] },

  { id: "g-b1-3", type: "mcq", level: "b1", skill: "grammar", topic: "izofa", diff: "medium",
    promptUz: "Izofa tarkibini to‘g‘ri tugating:", ar: "هٰذَا كِتَابُ ______ .",
    opts: ["الطَّالِبِ", "الطَّالِبُ", "الطَّالِبَ", "طَالِبٌ"], optsAr: true, ans: 0,
    expUz: "Izofada ikkinchi ism (muzof ilayh) doim majrur bo‘ladi: كِتَابُ الطَّالِبِ.", tags: ["izofa"] },

  { id: "g-b1-4", type: "mcq", level: "b1", skill: "grammar", topic: "mavsul", diff: "medium",
    promptUz: "Mos nisbiy olmoshni tanlang:", ar: "الطَّالِبَةُ ______ نَجَحَتْ فِي الِامْتِحَانِ.",
    opts: ["الَّتِي", "الَّذِي", "الَّذِينَ", "اللَّوَاتِي"], optsAr: true, ans: 0,
    expUz: "الطَّالِبَةُ — muannas mufrad, shuning uchun nisbiy olmosh الَّتِي bo‘ladi.", tags: ["mavsul"] },

  { id: "g-b1-5", type: "mcq", level: "b1", skill: "grammar", topic: "nasb", diff: "hard",
    promptUz: "To‘g‘ri shaklni tanlang:", ar: "يَجِبُ أَنْ ______ الدَّرْسَ جَيِّدًا.",
    opts: ["نَفْهَمَ", "نَفْهَمُ", "نَفْهَمْ", "فَهِمْنَا"], optsAr: true, ans: 0,
    expUz: "«أَنْ» mudori’ni mansub qiladi: أَنْ نَفْهَمَ.", tags: ["nasb", "an"] },

  /* ---------------- GRAMMAR · B2 ---------------- */
  { id: "g-b2-1", type: "mcq", level: "b2", skill: "grammar", topic: "majhul", diff: "medium",
    promptUz: "«كَتَبَ الطَّالِبُ الرِّسَالَةَ» jumlasining majhul shakli:", ar: "",
    opts: ["كُتِبَتِ الرِّسَالَةُ.", "كَتَبَتِ الرِّسَالَةُ.", "كُتِبَ الرِّسَالَةَ.", "يَكْتُبُ الرِّسَالَةُ."], optsAr: true, ans: 0,
    expUz: "Majhulda fail tushiriladi, maf’ul noibu-l-fail bo‘lib marfu‘ bo‘ladi: كُتِبَتِ الرِّسَالَةُ.", tags: ["majhul"] },

  { id: "g-b2-2", type: "mcq", level: "b2", skill: "grammar", topic: "hol", diff: "medium",
    promptUz: "Holni to‘g‘ri shaklda tanlang:", ar: "جَاءَ الطَّالِبُ ______ .",
    opts: ["مُسْرِعًا", "مُسْرِعٌ", "مُسْرِعٍ", "الْمُسْرِعُ"], optsAr: true, ans: 0,
    expUz: "Hol mansub bo‘ladi va harakat holatini bildiradi: جَاءَ الطَّالِبُ مُسْرِعًا.", tags: ["hol"] },

  { id: "g-b2-3", type: "mcq", level: "b2", skill: "grammar", topic: "tamyiz", diff: "hard",
    promptUz: "Tamyizni tanlang:", ar: "اِزْدَادَ الطَّالِبُ ______ .",
    opts: ["عِلْمًا", "عِلْمٌ", "الْعِلْمِ", "عَالِمٌ"], optsAr: true, ans: 0,
    expUz: "Tamyiz mavhum ma’noni aniqlashtiradi va mansub bo‘ladi: اِزْدَادَ الطَّالِبُ عِلْمًا.", tags: ["tamyiz"] },

  { id: "g-b2-4", type: "mcq", level: "b2", skill: "grammar", topic: "ism-fail", diff: "medium",
    promptUz: "«اِسْتَخْدَمَ» fe’lidan ism foil:", ar: "اِسْتَخْدَمَ ← ______",
    opts: ["مُسْتَخْدِمٌ", "مُسْتَخْدَمٌ", "اِسْتِخْدَامٌ", "مَخْدُومٌ"], optsAr: true, ans: 0,
    expUz: "Ko‘p harfli fe’lda ism foil مُـ bilan boshlanadi va oxirgidan oldingi harf kasrali bo‘ladi: مُسْتَخْدِمٌ (foydalanuvchi).", tags: ["ism-fail"] },

  { id: "g-b2-5", type: "mcq", level: "b2", skill: "grammar", topic: "istisno", diff: "hard",
    promptUz: "To‘g‘ri shaklni tanlang:", ar: "حَضَرَ الطُّلَّابُ إِلَّا ______ .",
    opts: ["طَالِبًا", "طَالِبٌ", "طَالِبٍ", "الطَّالِبُ"], optsAr: true, ans: 0,
    expUz: "To‘liq va tasdiq jumlada إِلَّا dan keyingi so‘z (mustasno) mansub bo‘ladi: إِلَّا طَالِبًا.", tags: ["istisno"] },

  /* ---------------- GRAMMAR · C1 ---------------- */
  { id: "g-c1-1", type: "mcq", level: "c1", skill: "grammar", topic: "shart", diff: "hard",
    promptUz: "Shart jumlasini to‘g‘ri tugating:", ar: "إِنْ تَجْتَهِدْ ______ .",
    opts: ["تَنْجَحْ", "تَنْجَحُ", "تَنْجَحَ", "نَجَحْتَ"], optsAr: true, ans: 0,
    expUz: "«إِنْ» shart edati ikki fe’lni ham majzum qiladi: إِنْ تَجْتَهِدْ تَنْجَحْ.", tags: ["shart"] },

  { id: "g-c1-2", type: "mcq", level: "c1", skill: "grammar", topic: "mafool-liajlih", diff: "hard",
    promptUz: "Maf’ul li-ajlihni tanlang:", ar: "قُمْتُ ______ لِلْأُسْتَاذِ.",
    opts: ["احْتِرَامًا", "احْتِرَامٌ", "الِاحْتِرَامِ", "مُحْتَرَمٌ"], optsAr: true, ans: 0,
    expUz: "Harakat sababini bildiruvchi maf’ul li-ajlih mansub bo‘ladi: قُمْتُ احْتِرَامًا لِلْأُسْتَاذِ.", tags: ["mafool"] },

  { id: "g-c1-3", type: "mcq", level: "c1", skill: "grammar", topic: "ism-tafdil", diff: "medium",
    promptUz: "Qiyosiy darajani to‘g‘ri tanlang:", ar: "هٰذَا الْبَحْثُ ______ مِنْ سَابِقِهِ.",
    opts: ["أَدَقُّ", "دَقِيقٌ", "الْأَدَقُّ", "دِقَّةٌ"], optsAr: true, ans: 0,
    expUz: "مِنْ bilan kelgan qiyosda ism tafdil noaniq va marfu‘ shaklda bo‘ladi: أَدَقُّ مِنْ.", tags: ["tafdil"] },

  { id: "g-c1-4", type: "mcq", level: "c1", skill: "grammar", topic: "mafool-mutlaq", diff: "hard",
    promptUz: "Maf’ul mutlaq qaysi jumlada?", ar: "",
    opts: ["شَكَرْتُهُ شُكْرًا جَزِيلًا.", "شَكَرْتُهُ لِكَرَمِهِ.", "شَكَرْتُهُ فِي الصَّبَاحِ.", "شَكَرْتُهُ وَهُوَ مُبْتَسِمٌ."], optsAr: true, ans: 0,
    expUz: "Maf’ul mutlaq fe’l o‘zagidan yasalgan masdar bo‘lib, fe’lni ta’kidlaydi: شُكْرًا جَزِيلًا.", tags: ["mafool-mutlaq"] },

  /* ---------------- GRAMMAR · C2 ---------------- */
  { id: "g-c2-1", type: "mcq", level: "c2", skill: "grammar", topic: "afal-noqisa", diff: "expert",
    promptUz: "To‘g‘ri shaklni tanlang:", ar: "لَا يَزَالُ الْبَحْثُ ______ .",
    opts: ["مُسْتَمِرًّا", "مُسْتَمِرٌّ", "مُسْتَمِرٍّ", "الْمُسْتَمِرُّ"], optsAr: true, ans: 0,
    expUz: "لَا يَزَالُ — كان ning singillaridan; xabarini mansub qiladi: مُسْتَمِرًّا.", tags: ["kana"] },

  { id: "g-c2-2", type: "mcq", level: "c2", skill: "grammar", topic: "balaga", diff: "expert",
    promptUz: "«الْعِلْمُ نُورٌ وَالْجَهْلُ ظَلَامٌ» — bu qaysi badiiy san’at?", ar: "",
    opts: ["الطِّبَاق", "الْجِنَاس", "التَّشْبِيه", "الِاسْتِعَارَة"], optsAr: true, ans: 0,
    expUz: "Tibaq — qarama-qarshi ma’noli so‘zlarni yonma-yon keltirish: نُور ↔ ظَلَام.", tags: ["balaga"] },

  { id: "g-c2-3", type: "mcq", level: "c2", skill: "grammar", topic: "afal-muqoraba", diff: "expert",
    promptUz: "To‘g‘ri davomini tanlang:", ar: "كَادَ الطَّالِبُ ______ .",
    opts: ["يَنْجَحُ", "نَاجِحًا", "أَنْ نَجَحَ", "النَّجَاحُ"], optsAr: true, ans: 0,
    expUz: "كَادَ — af’olul-muqoraba; xabari mudori’ fe’l bo‘lib, odatda «أَنْ»siz keladi: كَادَ يَنْجَحُ.", tags: ["kada"] },

  { id: "g-c2-4", type: "mcq", level: "c2", skill: "grammar", topic: "balaga", diff: "expert",
    promptUz: "«هُوَ بَحْرٌ فِي الْكَرَمِ» — bu qaysi san’at?", ar: "",
    opts: ["الِاسْتِعَارَة التَّصْرِيحِيَّة", "الطِّبَاق", "السَّجْع", "الْكِنَايَة"], optsAr: true, ans: 0,
    expUz: "O‘xshatish vositasi tushirilib, o‘xshatilgan narsa (بحر) to‘g‘ridan-to‘g‘ri qo‘llangan — istiora tasrihiya.", tags: ["balaga"] },

  /* ---------------- VOCABULARY · A1 ---------------- */
  { id: "v-a1-1", type: "mcq", level: "a1", skill: "vocabulary", topic: "joy", diff: "easy",
    promptUz: "«مَكْتَبَة» so‘zining ma’nosi:", ar: "مَكْتَبَة",
    opts: ["Kutubxona", "Oshxona", "Bozor", "Kasalxona"], ans: 0,
    expUz: "مَكْتَبَة — kutubxona yoki kitob do‘koni. O‘zagi ك-ت-ب (yozmoq).", tags: ["joy"] },

  { id: "v-a1-2", type: "mcq", level: "a1", skill: "vocabulary", topic: "oila", diff: "easy",
    promptUz: "«oila» so‘zining arabchasi:", ar: "",
    opts: ["أُسْرَة", "مَدْرَسَة", "مَدِينَة", "غُرْفَة"], optsAr: true, ans: 0,
    expUz: "أُسْرَة (yoki عَائِلَة) — oila.", tags: ["oila"] },

  { id: "v-a1-3", type: "mcq", level: "a1", skill: "vocabulary", topic: "vaqt", diff: "easy",
    promptUz: "«صَبَاح» so‘zining ma’nosi:", ar: "صَبَاح",
    opts: ["Tong", "Kech", "Tun", "Kun"], ans: 0,
    expUz: "صَبَاح — tong, ertalab. Salomlashuv: صَبَاحُ الْخَيْرِ.", tags: ["vaqt"] },

  { id: "v-a1-4", type: "mcq", level: "a1", skill: "vocabulary", topic: "savdo", diff: "easy",
    promptUz: "«bozor» so‘zining arabchasi:", ar: "",
    opts: ["سُوق", "شَارِع", "مَطَار", "جِسْر"], optsAr: true, ans: 0,
    expUz: "سُوق — bozor. شَارِع — ko‘cha, مَطَار — aeroport.", tags: ["savdo"] },

  /* ---------------- VOCABULARY · A2 ---------------- */
  { id: "v-a2-1", type: "mcq", level: "a2", skill: "vocabulary", topic: "soglik", diff: "easy",
    promptUz: "«مُسْتَشْفَى» so‘zining ma’nosi:", ar: "مُسْتَشْفَى",
    opts: ["Kasalxona", "Dorixona", "Maktab", "Mehmonxona"], ans: 0,
    expUz: "مُسْتَشْفَى — kasalxona. Dorixona esa صَيْدَلِيَّة.", tags: ["soglik"] },

  { id: "v-a2-2", type: "mcq", level: "a2", skill: "vocabulary", topic: "aloqa", diff: "easy",
    promptUz: "«xat, maktub» so‘zining arabchasi:", ar: "",
    opts: ["رِسَالَة", "قِصَّة", "جَرِيدَة", "مَجَلَّة"], optsAr: true, ans: 0,
    expUz: "رِسَالَة — xat. جَرِيدَة — gazeta, مَجَلَّة — jurnal.", tags: ["aloqa"] },

  { id: "v-a2-3", type: "mcq", level: "a2", skill: "vocabulary", topic: "uy", diff: "medium",
    promptUz: "«مِفْتَاح» so‘zining ma’nosi:", ar: "مِفْتَاح",
    opts: ["Kalit", "Eshik", "Deraza", "Kalit so‘z"], ans: 0,
    expUz: "مِفْتَاح — kalit; o‘zagi ف-ت-ح (ochmoq).", tags: ["uy"] },

  { id: "v-a2-4", type: "mcq", level: "a2", skill: "vocabulary", topic: "antonim", diff: "medium",
    promptUz: "«قَرِيب» so‘zining zid ma’nolisi:", ar: "قَرِيب ↔ ______",
    opts: ["بَعِيد", "صَغِير", "سَهْل", "قَدِيم"], optsAr: true, ans: 0,
    expUz: "قَرِيب (yaqin) ↔ بَعِيد (uzoq).", tags: ["antonim"] },

  /* ---------------- VOCABULARY · B1 ---------------- */
  { id: "v-b1-1", type: "mcq", level: "b1", skill: "vocabulary", topic: "sayohat", diff: "easy",
    promptUz: "«فُنْدُق» so‘zining ma’nosi:", ar: "فُنْدُق",
    opts: ["Mehmonxona", "Restoran", "Vokzal", "Muzey"], ans: 0,
    expUz: "فُنْدُق — mehmonxona. مَطْعَم — restoran, مَتْحَف — muzey.", tags: ["sayohat"] },

  { id: "v-b1-2", type: "mcq", level: "b1", skill: "vocabulary", topic: "sayohat", diff: "medium",
    promptUz: "«chipta» so‘zining arabchasi:", ar: "",
    opts: ["تَذْكِرَة", "حَقِيبَة", "رِحْلَة", "جَوَاز"], optsAr: true, ans: 0,
    expUz: "تَذْكِرَة — chipta. حَقِيبَة — sumka, رِحْلَة — sayohat, جَوَاز (سَفَر) — pasport.", tags: ["sayohat"] },

  { id: "v-b1-3", type: "mcq", level: "b1", skill: "vocabulary", topic: "mavhum", diff: "medium",
    promptUz: "«حُرِّيَّة» so‘zining ma’nosi:", ar: "حُرِّيَّة",
    opts: ["Erkinlik", "Mas’uliyat", "Adolat", "Do‘stlik"], ans: 0,
    expUz: "حُرِّيَّة — erkinlik. مَسْؤُولِيَّة — mas’uliyat, عَدَالَة — adolat.", tags: ["mavhum"] },

  { id: "v-b1-4", type: "mcq", level: "b1", skill: "vocabulary", topic: "sinonim", diff: "medium",
    promptUz: "«عَادَة» so‘ziga eng yaqin ma’noli so‘z:", ar: "عَادَة ≈ ______",
    opts: ["تَقْلِيد", "حَادِث", "قَرَار", "سَبَب"], optsAr: true, ans: 0,
    expUz: "عَادَة (odat) va تَقْلِيد (an’ana) yaqin ma’noli. حَادِث — hodisa.", tags: ["sinonim"] },

  /* ---------------- VOCABULARY · B2 ---------------- */
  { id: "v-b2-1", type: "mcq", level: "b2", skill: "vocabulary", topic: "iqtisod", diff: "medium",
    promptUz: "«اِقْتِصَاد» so‘zining ma’nosi:", ar: "اِقْتِصَاد",
    opts: ["Iqtisodiyot", "Siyosat", "Ijtimoiy soha", "Sanoat"], ans: 0,
    expUz: "اِقْتِصَاد — iqtisodiyot. سِيَاسَة — siyosat, صِنَاعَة — sanoat.", tags: ["iqtisod"] },

  { id: "v-b2-2", type: "mcq", level: "b2", skill: "vocabulary", topic: "ilm", diff: "medium",
    promptUz: "«tadqiqot» so‘zining arabchasi:", ar: "",
    opts: ["بَحْث", "خَبَر", "رَأْي", "دَلِيل"], optsAr: true, ans: 0,
    expUz: "بَحْث — tadqiqot, izlanish. دَلِيل — dalil, رَأْي — fikr.", tags: ["ilm"] },

  { id: "v-b2-3", type: "mcq", level: "b2", skill: "vocabulary", topic: "mavhum", diff: "hard",
    promptUz: "«تَحَدٍّ» so‘zining ma’nosi:", ar: "تَحَدٍّ",
    opts: ["Chaqiriq, sinov", "Yechim", "Imkoniyat", "Kelishuv"], ans: 0,
    expUz: "تَحَدٍّ (ko‘pligi تَحَدِّيَات) — chaqiriq, jiddiy sinov.", tags: ["mavhum"] },

  { id: "v-b2-4", type: "mcq", level: "b2", skill: "vocabulary", topic: "sinonim", diff: "hard",
    promptUz: "«إِنْتَاج» so‘ziga zid ma’noli so‘z:", ar: "إِنْتَاج ↔ ______",
    opts: ["اِسْتِهْلَاك", "تَصْدِير", "تَطْوِير", "تَوْزِيع"], optsAr: true, ans: 0,
    expUz: "إِنْتَاج (ishlab chiqarish) ↔ اِسْتِهْلَاك (iste’mol).", tags: ["antonim"] },

  /* ---------------- VOCABULARY · C1 ---------------- */
  { id: "v-c1-1", type: "mcq", level: "c1", skill: "vocabulary", topic: "ekologiya", diff: "hard",
    promptUz: "«اِسْتِنْزَاف» so‘zining ma’nosi:", ar: "اِسْتِنْزَاف",
    opts: ["Tugatib yuborish, so‘rib olish", "Qayta tiklash", "Muhofaza qilish", "Taqsimlash"], ans: 0,
    expUz: "اِسْتِنْزَاف الْمَوَارِد — resurslarni tugatib yuborish.", tags: ["ekologiya"] },

  { id: "v-c1-2", type: "mcq", level: "c1", skill: "vocabulary", topic: "ekologiya", diff: "hard",
    promptUz: "«barqaror» so‘zining arabchasi:", ar: "",
    opts: ["مُسْتَدَام", "مُتَغَيِّر", "مُؤَقَّت", "مُحْتَمَل"], optsAr: true, ans: 0,
    expUz: "التَّنْمِيَة الْمُسْتَدَامَة — barqaror rivojlanish. مُؤَقَّت — vaqtinchalik.", tags: ["ekologiya"] },

  { id: "v-c1-3", type: "mcq", level: "c1", skill: "vocabulary", topic: "huquq", diff: "hard",
    promptUz: "«تَشْرِيع» so‘zining ma’nosi:", ar: "تَشْرِيع",
    opts: ["Qonunchilik", "Sud jarayoni", "Shartnoma", "Jazo"], ans: 0,
    expUz: "تَشْرِيع — qonunchilik, qonun chiqarish. قَضَاء — sud, عُقُوبَة — jazo.", tags: ["huquq"] },

  { id: "v-c1-4", type: "mcq", level: "c1", skill: "vocabulary", topic: "sinonim", diff: "expert",
    promptUz: "«مُوَازَنَة» so‘ziga eng yaqin ma’no:", ar: "مُوَازَنَة ≈ ______",
    opts: ["تَعَادُل", "تَفَاوُت", "تَنَاقُض", "تَبَايُن"], optsAr: true, ans: 0,
    expUz: "مُوَازَنَة — muvozanat; تَعَادُل ham tenglashuv ma’nosini beradi. تَنَاقُض — ziddiyat.", tags: ["sinonim"] },

  /* ---------------- VOCABULARY · C2 ---------------- */
  { id: "v-c2-1", type: "mcq", level: "c2", skill: "vocabulary", topic: "til", diff: "expert",
    promptUz: "«ذَاكِرَة جَمَاعِيَّة» iborasining ma’nosi:", ar: "ذَاكِرَة جَمَاعِيَّة",
    opts: ["Jamoaviy xotira", "Umumiy manfaat", "Ijtimoiy adolat", "Milliy g‘oya"], ans: 0,
    expUz: "ذَاكِرَة — xotira, جَمَاعِيَّة — jamoaviy.", tags: ["til"] },

  { id: "v-c2-2", type: "mcq", level: "c2", skill: "vocabulary", topic: "adabiyot", diff: "expert",
    promptUz: "«تَذَوُّق» so‘zining ma’nosi:", ar: "تَذَوُّق",
    opts: ["Did bilan idrok etish", "Tanqid qilish", "Tarjima qilish", "Yodlash"], ans: 0,
    expUz: "تَذَوُّق أَدَبِيّ — adabiy did, matnni his qilib idrok etish.", tags: ["adabiyot"] },

  { id: "v-c2-3", type: "mcq", level: "c2", skill: "vocabulary", topic: "ilm", diff: "expert",
    promptUz: "«اِخْتِزَال» so‘zining ma’nosi:", ar: "اِخْتِزَال",
    opts: ["Qisqartirish, soddalashtirib yuborish", "Kengaytirish", "Takrorlash", "Tasniflash"], ans: 0,
    expUz: "اِخْتِزَال — qisqartirish; ilmiy matnda ko‘pincha «haddan tashqari soddalashtirish» ma’nosida.", tags: ["ilm"] },

  { id: "v-c2-4", type: "mcq", level: "c2", skill: "vocabulary", topic: "adabiyot", diff: "expert",
    promptUz: "«تَحْنِيط اللُّغَة» iborasi nimani anglatadi?", ar: "تَحْنِيط اللُّغَة",
    opts: ["Tilni qotirib, rivojlanishdan to‘xtatish", "Tilni boyitish", "Tilni tarqatish", "Tilni o‘rgatish"], ans: 0,
    expUz: "تَحْنِيط — mumiyolash; ko‘chma ma’noda tilni o‘zgarishdan mahrum qilish.", tags: ["adabiyot"] }
];
