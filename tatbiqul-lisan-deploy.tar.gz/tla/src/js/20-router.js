/* ============================================================
   ROUTER + BOOT
   Hash routing keeps the whole app in a single file with no
   server rewrite rules. Every page exposes render(params),
   optional mounted(params) / unmount() and meta.
   ============================================================ */
window.TLA = window.TLA || {};

TLA.router = (function () {
  "use strict";
  const U = TLA.utils;

  const ROUTES = [
    { re: /^\/?$/, page: "home" },
    { re: /^\/learn$/, page: "learn" },
    { re: /^\/learn\/([^/]+)$/, page: "course", keys: ["id"] },
    { re: /^\/lesson\/([^/]+)$/, page: "lesson", keys: ["id"] },
    { re: /^\/exams$/, page: "exams" },
    { re: /^\/exams\/([^/]+)$/, page: "examTrack", keys: ["track"] },
    { re: /^\/tests$/, page: "tests" },
    { re: /^\/test\/([^/]+)$/, page: "test", keys: ["id"] },
    { re: /^\/result\/([^/]+)$/, page: "result", keys: ["id"] },
    { re: /^\/library$/, page: "library" },
    { re: /^\/dictionary$/, page: "dictionary" },
    { re: /^\/blog$/, page: "blog" },
    { re: /^\/blog\/([^/]+)$/, page: "blogPost", keys: ["slug"] },
    { re: /^\/free$/, page: "free" },
    { re: /^\/pricing$/, page: "pricing" },
    { re: /^\/dashboard$/, page: "dashboard" },
    { re: /^\/progress$/, page: "progress" },
    { re: /^\/certificates$/, page: "certificates" },
    { re: /^\/verify$/, page: "verify" },
    { re: /^\/profile$/, page: "profile" },
    { re: /^\/leaderboard$/, page: "leaderboard" },
    { re: /^\/teachers$/, page: "teachers" },
    { re: /^\/about$/, page: "about" },
    { re: /^\/contact$/, page: "contact" },
    { re: /^\/legal\/([^/]+)$/, page: "legal", keys: ["doc"] }
  ];

  let currentPage = null;
  let currentHash = null;

  function parse(hash) {
    const raw = (hash || location.hash || "#/").replace(/^#/, "");
    const [pathPart, queryPart] = raw.split("?");
    const path = decodeURIComponent(pathPart || "/");
    const query = {};
    (queryPart || "").split("&").filter(Boolean).forEach(function (pair) {
      const [k, v] = pair.split("=");
      if (k) query[decodeURIComponent(k)] = decodeURIComponent(v || "");
    });

    if (path === "/admin") return { page: "admin", params: { query: query } };

    for (let i = 0; i < ROUTES.length; i++) {
      const match = path.match(ROUTES[i].re);
      if (match) {
        const params = { query: query };
        (ROUTES[i].keys || []).forEach(function (key, ki) {
          params[key] = match[ki + 1];
        });
        return { page: ROUTES[i].page, params: params };
      }
    }
    return { page: "notFound", params: { query: query } };
  }

  function applyMeta(page, params) {
    const meta = typeof page.meta === "function" ? page.meta(params) : page.meta;
    if (!meta) return;
    if (meta.title) document.title = meta.title;
    const desc = document.querySelector('meta[name="description"]');
    if (desc && meta.desc !== undefined) desc.setAttribute("content", meta.desc);
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle && meta.title) ogTitle.setAttribute("content", meta.title);
    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc && meta.desc !== undefined) ogDesc.setAttribute("content", meta.desc);
  }

  function render() {
    const route = parse();
    const page = TLA.pages[route.page] || TLA.pages.notFound;
    const host = U.$("#pageHost");
    if (!host) return;

    // let the previous page release timers, audio and listeners
    if (currentPage && currentPage.unmount) {
      try { currentPage.unmount(); } catch (e) { /* keep navigating */ }
    }

    host.setAttribute("aria-busy", "true");
    try {
      host.innerHTML = page.render(route.params);
    } catch (err) {
      host.innerHTML = '<section class="section"><div class="container container-narrow">' +
        '<div class="alert alert-danger"><span class="ico">!</span><span>' +
        TLA.i18n.t("error.generic") + "</span></div>" +
        '<p class="muted mono" style="margin-top:var(--sp-4);font-size:var(--fs-2xs)">' +
        TLA.utils.esc(String(err && err.message ? err.message : err)) + "</p>" +
        '<a class="btn btn-primary" style="margin-top:var(--sp-4)" href="#/">' + TLA.i18n.t("error.goHome") + "</a>" +
        "</div></section>";
    }
    host.removeAttribute("aria-busy");

    currentPage = page;
    applyMeta(page, route.params);

    if (page.mounted) {
      try { page.mounted(route.params); } catch (e) { /* page still renders */ }
    }

    TLA.ui.renderHeader();
    TLA.ui.renderBottomNav();
    TLA.ui.reveal(host);
    TLA.state.track("page_view", { page: route.page });
  }

  function onHashChange() {
    const next = location.hash || "#/";
    if (next === currentHash) return;

    // guard against losing an in-progress exam
    if (TLA.pages.test && TLA.pages.test.isRunning && TLA.pages.test.isRunning() &&
      next.indexOf("#/test/") !== 0 && next.indexOf("#/result/") !== 0) {
      const previous = currentHash;
      TLA.ui.confirmDialog(
        TLA.i18n.t("test.exit"),
        TLA.i18n.t("test.exitConfirm"),
        TLA.i18n.t("test.exit"),
        function () {
          currentHash = next;
          if (TLA.pages.test.unmount) TLA.pages.test.unmount();
          render();
          U.scrollToTop(true);
        },
        true
      );
      // stay where we are until the user confirms
      location.hash = previous || "#/";
      return;
    }

    currentHash = next;
    TLA.ui.closeModal();
    TLA.ui.closeDrawer();
    TLA.ui.closeSearch();
    render();
    U.scrollToTop(true);
  }

  function go(hash) {
    if (location.hash === hash) { render(); return; }
    location.hash = hash;
  }

  function rerender() { render(); }

  function start() {
    window.addEventListener("hashchange", onHashChange);
    if (!location.hash) location.hash = "#/";
    currentHash = location.hash;
    render();
  }

  return { start, go, rerender, parse };
})();

/* ============================================================
   BOOT
   ============================================================ */
(async function boot() {
  "use strict";

  function fatal(message) {
    const host = document.getElementById("pageHost");
    if (host) {
      host.innerHTML = '<section class="section"><div class="container container-narrow">' +
        '<div class="alert alert-danger"><span class="ico">!</span><span>' + message + "</span></div></div></section>";
    }
  }

  try {
    await TLA.state.init();
    TLA.state.hydrateCustomQuestions();
    // Backend session restore (05b-api.js + 06-state.js): if a saved token
    // is present, this resolves before the shell paints so a reload never
    // flashes "guest" before flipping to "logged in". Costs nothing when
    // there is no token (the common case for the static-only deployment —
    // see DEPLOY.md) since restoreSession() returns immediately in that case.
    await TLA.state.restoreSession();

    const settings = TLA.state.settings();
    TLA.i18n.set(settings.lang || "uz");
    TLA.ui.applySettings();
    TLA.ui.renderShell();
    TLA.ui.bindGlobal();
    TLA.ui.bindScroll();
    TLA.audio.refreshVoices();
    TLA.state.touchStreak();

    TLA.router.start();

    // remove the pre-boot splash once the first page is painted
    const splash = document.getElementById("bootSplash");
    if (splash) {
      splash.classList.add("out");
      setTimeout(() => splash.remove(), 420);
    }

    document.documentElement.classList.add("is-ready");
  } catch (err) {
    fatal("Ilovani ishga tushirishda xatolik: " + (err && err.message ? err.message : err));
  }
})();
