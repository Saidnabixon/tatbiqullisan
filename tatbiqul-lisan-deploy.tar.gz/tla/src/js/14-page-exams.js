/* ============================================================
   PAGES — Exams hub, exam tracks, test catalogue
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  function testStats(testId) {
    const list = TLA.state.attemptsFor(testId);
    if (!list.length) return null;
    const scores = list.map(a => a.score);
    return {
      count: list.length,
      best: Math.max.apply(null, scores),
      last: scores[scores.length - 1]
    };
  }

  function testCard(test, opts) {
    const o = opts || {};
    const stats = testStats(test.id);
    const locked = !test.free && !TLA.state.isAuthed();
    return '<article class="card card-hover" data-reveal>' +
      '<div class="row-between" style="margin-bottom:var(--sp-3)">' +
      '<div class="row" style="gap:var(--sp-2)">' +
      (test.levels.length === 1 ? TLA.ui.levelPill(test.levels[0]) : '<span class="badge">' + test.levels.length + " daraja</span>") +
      (test.kind === "mock" ? '<span class="badge badge-gold">MOCK</span>' : "") +
      "</div>" +
      (test.free ? '<span class="badge badge-free">' + t("misc.free") + "</span>"
        : '<span class="badge badge-gold">' + t("misc.premium") + "</span>") +
      "</div>" +
      "<h3 style='font-size:var(--fs-md)'>" + U.esc(test.titleUz) + "</h3>" +
      (o.hideAr ? "" : '<p class="ar" style="color:var(--accent-ink);font-size:1.05rem;margin-top:4px">' + test.titleAr + "</p>") +
      '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-3);line-height:1.55">' + U.esc(test.descUz) + "</p>" +
      '<div class="row row-wrap" style="gap:var(--sp-3);margin-top:var(--sp-4);font-size:var(--fs-2xs);color:var(--ink-3)">' +
      "<span><b>" + test.count + "</b> " + t("test.questions") + "</span>" +
      "<span><b>" + test.minutes + "</b> " + t("test.minutes") + "</span>" +
      "<span>" + test.skills.map(s => t("misc.skill." + s)).join(", ") + "</span></div>" +
      (stats
        ? '<div class="row row-wrap" style="gap:var(--sp-2);margin-top:var(--sp-4)">' +
          '<span class="badge badge-jade">' + t("misc.best") + ": " + stats.best + "%</span>" +
          '<span class="badge">' + t("misc.last") + ": " + stats.last + "%</span>" +
          '<span class="badge badge-outline">' + stats.count + " " + t("misc.attempts") + "</span></div>"
        : "") +
      '<div class="cc-foot" style="margin-top:var(--sp-5);padding-top:var(--sp-4);border-top:1px solid var(--border)">' +
      '<span class="muted" style="font-size:var(--fs-2xs)">' + (locked ? t("misc.locked") : t("misc.demoContent")) + "</span>" +
      '<a class="btn btn-soft btn-sm btn-arrow" href="#/test/' + test.id + '">' + t("test.start") + ' <span class="arw">→</span></a>' +
      "</div></article>";
  }

  /* ================= Exams hub ================= */
  TLA.pages.exams = {
    render: function () {
      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.exams") }],
        eyebrow: t("nav.exams"),
        title: "Imtihonga tayyorgarlik yo‘nalishlari",
        lead: "Har bir yo‘nalish bo‘limlarga ajratilgan: mashq testlari, vaqt cheklovli rejim va to‘liq mock imtihon."
      }) +
        '<section class="section"><div class="container">' +
        '<div class="grid grid-3">' +
        TLA.data.examTracks.map(function (e) {
          const list = TLA.data.testsByTrack(e.id);
          return '<a class="card card-hover card-illum" href="#/exams/' + e.id + '" data-reveal>' +
            '<div class="row-between"><span style="font-size:1.4rem;color:var(--accent)">' + e.icon + "</span>" +
            '<span class="badge">' + list.length + " test</span></div>" +
            '<h3 style="margin-top:var(--sp-4)">' + U.esc(e.uz) + "</h3>" +
            '<p class="ar" style="color:var(--accent-ink);margin-top:4px">' + e.ar + "</p>" +
            '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-3)">' + U.esc(e.descUz) + "</p></a>";
        }).join("") +
        "</div>" +
        '<div style="margin-top:var(--sp-6)">' + TLA.ui.complianceNote(t("exam.disclaimer")) + "</div>" +
        "</div></section>";
    },
    meta: { title: "Imtihonlar — Multilevel, TANAL Arobiy, Darajaviy", desc: "Arab tili imtihonlariga tayyorgarlik bo‘limlari va mock testlar." }
  };

  /* ================= Exam track ================= */
  TLA.pages.examTrack = {
    render: function (params) {
      const track = params.track;
      const meta = TLA.data.examTracks.filter(e => e.id === track)[0];
      if (!meta) return TLA.pages.notFound.render();
      const tests = TLA.data.testsByTrack(track);

      if (track === "darajaviy") {
        const byLevel = U.groupBy(tests, x => x.levels[0]);
        return TLA.ui.pageHead({
          crumbs: [{ label: t("nav.exams"), href: "#/exams" }, { label: meta.uz }],
          eyebrow: "A1 → C2",
          title: "DARAJAVIY TESTLAR",
          lead: meta.descUz
        }) +
          '<section class="section"><div class="container">' +
          TLA.data.levels.map(function (lv) {
            const list = byLevel[lv.id] || [];
            const attemptsAll = list.reduce((n, x) => n + TLA.state.attemptsFor(x.id).length, 0);
            return '<div class="card" style="margin-bottom:var(--sp-5)" data-reveal>' +
              '<div class="row-between row-wrap" style="margin-bottom:var(--sp-4);gap:var(--sp-3)">' +
              '<div class="row" style="gap:var(--sp-4)">' + TLA.ui.levelPill(lv.code) +
              "<div><strong>" + U.esc(lv.uz) + '</strong><br><span class="muted" style="font-size:var(--fs-2xs)">' +
              U.esc(lv.descUz) + "</span></div></div>" +
              '<span class="badge">' + attemptsAll + " " + t("misc.attempts") + "</span></div>" +
              '<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:var(--sp-3)">' +
              list.map(function (x) {
                const s = testStats(x.id);
                return '<a class="res-card" href="#/test/' + x.id + '">' +
                  '<span class="res-ico">' + (x.kind === "mock" ? "★" : "◈") + "</span>" +
                  '<span style="flex:1"><span class="rt">' + U.esc(x.titleUz.replace(lv.code.toUpperCase() + " — ", "")) + "</span>" +
                  '<span class="rs">' + x.count + " " + t("test.questions") + " · " + x.minutes + " " + t("test.minutes") + "</span>" +
                  (s ? '<span class="rm"><span class="badge badge-jade">' + t("misc.best") + ": " + s.best + "%</span></span>" : "") +
                  "</span></a>";
              }).join("") +
              "</div></div>";
          }).join("") +
          '<div>' + TLA.ui.complianceNote(t("exam.disclaimer")) + "</div>" +
          "</div></section>";
      }

      const sections = tests.filter(x => !x.isFull);
      const full = tests.filter(x => x.isFull)[0];

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.exams"), href: "#/exams" }, { label: meta.uz }],
        eyebrow: t("nav.exams"),
        title: meta.uz.toUpperCase(),
        lead: meta.descUz,
        extra: '<p class="ar ar-lg" style="margin-top:var(--sp-3);color:var(--accent-ink)">' + meta.ar + "</p>"
      }) +
        '<section class="section"><div class="container">' +
        '<div class="grid grid-3">' + sections.map(x => testCard(x, { hideAr: false })).join("") + "</div>" +

        (full
          ? '<div class="diag-band" style="margin-top:var(--sp-8)" data-reveal><div class="diag-inner">' +
            "<div><span class='eyebrow' style='color:var(--gold-300)'>" + t("exam.mock") + "</span>" +
            '<h2 style="margin:var(--sp-4) 0;color:var(--ivory)">' + U.esc(full.titleUz) + "</h2>" +
            "<p>" + U.esc(full.descUz) + "</p>" +
            '<div class="row row-wrap" style="gap:var(--sp-3);margin:var(--sp-5) 0">' +
            '<span class="badge badge-gold">' + full.count + " " + t("test.questions") + "</span>" +
            '<span class="badge badge-gold">' + full.minutes + " " + t("test.minutes") + "</span>" +
            '<span class="badge badge-gold">' + t("exam.timed") + "</span></div>" +
            '<a class="btn btn-gold btn-lg" href="#/test/' + full.id + '">' + t("test.start") + "</a></div>" +
            '<div><div class="card card-glass" style="background:rgba(255,255,255,.06);border-color:rgba(231,205,147,.2)">' +
            "<h4 style='color:var(--ivory)'>" + t("test.rules") + "</h4>" +
            '<ul class="stack-sm" style="margin-top:var(--sp-4);color:var(--ink-inverse-2);font-size:var(--fs-sm)">' +
            [1, 2, 3, 4].map(n => '<li class="row row-top" style="gap:var(--sp-3)"><span style="color:var(--gold-300)">◦</span><span>' +
              t("test.rule" + n) + "</span></li>").join("") +
            "</ul></div></div></div></div>"
          : "") +

        '<div class="grid grid-2" style="margin-top:var(--sp-8)">' +
        '<div class="card" data-reveal><h3>' + t("exam.sections") + "</h3>" +
        '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-2)">Har bir bo‘lim alohida mashq qilinadi, so‘ng to‘liq imtihon simulyatsiyasida birlashtiriladi.</p>' +
        '<div class="row row-wrap" style="gap:var(--sp-2);margin-top:var(--sp-4)">' +
        sections.map(x => '<a class="chip" href="#/test/' + x.id + '">' + U.esc(x.titleUz.split("— ")[1] || x.titleUz) + "</a>").join("") +
        "</div></div>" +
        '<div class="card" data-reveal><h3>Tayyorgarlik tartibi</h3>' +
        '<div class="timeline" style="margin-top:var(--sp-4)">' +
        [
          { h: "Diagnostika", p: "Boshlang‘ich darajani aniqlang." },
          { h: "Bo‘limlar bo‘yicha mashq", p: "Eng past ball olgan bo‘limdan boshlang." },
          { h: "Vaqt cheklovli rejim", p: "Tezlikni imtihon shartlariga moslashtiring." },
          { h: "To‘liq mock", p: "Har 2 haftada bir marta to‘liq simulyatsiya." }
        ].map(s => '<div class="timeline-item"><strong>' + s.h + '</strong><p class="muted" style="font-size:var(--fs-sm)">' + s.p + "</p></div>").join("") +
        "</div></div></div>" +

        '<div style="margin-top:var(--sp-6)">' + TLA.ui.complianceNote(t("exam.disclaimer")) + "</div>" +
        "</div></section>";
    },
    meta: function (params) {
      const m = TLA.data.examTracks.filter(e => e.id === params.track)[0];
      return m ? { title: m.uz + " tayyorgarlik — Tatbiqul Lisan Academy", desc: m.descUz } : null;
    }
  };

  /* ================= Test catalogue ================= */
  TLA.pages.tests = {
    render: function (params) {
      const skillFilter = params.query.skill || "";
      const kindFilter = params.query.kind || "";
      const levelFilter = params.query.level || "";

      let list = TLA.data.tests.filter(function (x) {
        if (skillFilter && x.skills.indexOf(skillFilter) === -1) return false;
        if (kindFilter && x.kind !== kindFilter) return false;
        if (levelFilter && x.levels.indexOf(levelFilter) === -1) return false;
        return true;
      });

      const chip = (label, key, value) => {
        const active = params.query[key] === value;
        const q = Object.assign({}, params.query);
        if (active) delete q[key]; else q[key] = value;
        const qs = Object.keys(q).filter(k => q[k]).map(k => k + "=" + encodeURIComponent(q[k])).join("&");
        return '<a class="chip' + (active ? " is-active" : "") + '" href="#/tests' + (qs ? "?" + qs : "") + '">' + U.esc(label) + "</a>";
      };

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.mock") }],
        eyebrow: t("nav.mock"),
        title: "Test va mock imtihonlar",
        lead: "Savollar har safar bazadan yangidan yig‘iladi — bir xil testni qayta topshirsangiz ham to‘plam takrorlanmaydi."
      }) +
        '<section class="section"><div class="container">' +
        '<div class="card card-dark" data-reveal style="margin-bottom:var(--sp-6)">' +
        '<div class="row-between row-wrap" style="gap:var(--sp-4)">' +
        '<div><h3 style="color:var(--ivory)">' + t("action.checkLevel") + "</h3>" +
        '<p class="muted" style="margin-top:var(--sp-2);max-width:52ch">' + t("diag.sub") + "</p></div>" +
        '<a class="btn btn-gold" href="#/test/diagnostic">' + t("action.startFree") + "</a></div></div>" +

        '<div class="filter-row" style="margin-bottom:var(--sp-5)">' +
        '<span class="muted" style="font-size:var(--fs-2xs);font-weight:700">' + t("courses.skills") + ":</span>" +
        TLA.data.skills.map(s => chip(t("misc.skill." + s.id), "skill", s.id)).join("") +
        "</div>" +
        '<div class="filter-row" style="margin-bottom:var(--sp-5)">' +
        '<span class="muted" style="font-size:var(--fs-2xs);font-weight:700">' + t("misc.level") + ":</span>" +
        TLA.data.levels.map(l => chip(l.code, "level", l.id)).join("") +
        chip(t("exam.mock"), "kind", "mock") +
        (Object.keys(params.query).length ? '<a class="btn btn-quiet btn-sm" href="#/tests">' + t("action.reset") + "</a>" : "") +
        "</div>" +

        (list.length
          ? '<div class="grid grid-3">' + list.map(x => testCard(x)).join("") + "</div>"
          : TLA.ui.emptyState("◉", t("empty.tests"), t("empty.searchD"),
            '<a class="btn btn-primary" href="#/test/diagnostic">' + t("empty.testsCta") + "</a>")) +
        "</div></section>";
    },
    meta: { title: "Mock testlar va mashqlar — Tatbiqul Lisan Academy", desc: "Arab tili bo‘yicha diagnostika, mashq va mock testlar to‘plami." }
  };

  TLA.pages.testCard = testCard;
})();
