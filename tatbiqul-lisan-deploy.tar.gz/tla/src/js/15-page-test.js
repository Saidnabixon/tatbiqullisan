/* ============================================================
   PAGE — Test runner
   Intro → running → confirm → result. Supports MCQ, reading
   (passage + questions), listening (audio, transcript locked),
   writing and speaking sections.
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  let session = null;
  let ticker = null;
  let player = null;

  function clearSession() {
    if (ticker) { clearInterval(ticker); ticker = null; }
    if (player) { player.destroy(); player = null; }
    TLA.audio.stopAll();
    session = null;
  }

  /* ---------------- Intro ---------------- */
  function introMarkup(test) {
    const stats = TLA.state.attemptsFor(test.id);
    const best = stats.length ? Math.max.apply(null, stats.map(a => a.score)) : null;
    return '<div class="container container-narrow">' +
      '<div class="card card-illum" data-reveal>' +
      '<div class="row-between row-wrap" style="gap:var(--sp-3);margin-bottom:var(--sp-5)">' +
      '<div class="row" style="gap:var(--sp-3)">' +
      (test.levels.length === 1 ? TLA.ui.levelPill(test.levels[0]) : '<span class="badge">' + test.levels.length + " daraja</span>") +
      (test.kind === "mock" ? '<span class="badge badge-gold">MOCK</span>' : "") +
      (test.free ? '<span class="badge badge-free">' + t("misc.free") + "</span>" : '<span class="badge badge-gold">' + t("misc.premium") + "</span>") +
      "</div>" +
      '<span class="badge badge-demo">' + t("misc.demoContent") + "</span></div>" +

      "<h1 style='font-size:var(--fs-3xl)'>" + U.esc(test.titleUz) + "</h1>" +
      '<p class="ar ar-lg" style="color:var(--accent-ink);margin-top:var(--sp-2)">' + test.titleAr + "</p>" +
      '<p class="lead" style="margin-top:var(--sp-4)">' + U.esc(test.descUz) + "</p>" +

      '<div class="grid grid-4" style="gap:var(--sp-3);margin:var(--sp-6) 0">' +
      '<div class="stat-tile"><div class="k">' + t("test.questions") + '</div><div class="v">' + test.count + "</div></div>" +
      '<div class="stat-tile"><div class="k">' + t("test.minutes") + '</div><div class="v">' + test.minutes + "</div></div>" +
      '<div class="stat-tile"><div class="k">' + t("exam.sections") + '</div><div class="v" style="font-size:var(--fs-lg)">' + test.skills.length + "</div></div>" +
      '<div class="stat-tile"><div class="k">' + t("misc.best") + '</div><div class="v">' + (best !== null ? best + "%" : "—") + "</div></div>" +
      "</div>" +

      "<h4>" + t("test.rules") + "</h4>" +
      '<ul class="stack-sm" style="margin-top:var(--sp-3);color:var(--ink-2);font-size:var(--fs-sm)">' +
      [1, 2, 3, 4].map(n => '<li class="row row-top" style="gap:var(--sp-3)"><span style="color:var(--accent)">◦</span><span>' +
        t("test.rule" + n) + "</span></li>").join("") +
      "</ul>" +

      (test.skills.indexOf("listening") !== -1 && TLA.audio.mode() === "demo"
        ? '<div class="alert alert-warn" style="margin-top:var(--sp-5)"><span class="ico">◉</span><span>' +
          "Bu qurilmada arabcha nutq ovozi topilmadi. Tinglash bo‘limi demo rejimda ishlaydi: audio o‘rniga matn ko‘rsatiladi.</span></div>"
        : "") +

      '<div class="row row-wrap" style="margin-top:var(--sp-6);gap:var(--sp-3)">' +
      '<button class="btn btn-primary btn-lg btn-arrow" id="startTest">' + t("test.start") + ' <span class="arw">→</span></button>' +
      '<a class="btn btn-ghost btn-lg" href="#/tests">' + t("action.back") + "</a></div>" +

      (stats.length
        ? '<div style="margin-top:var(--sp-6);padding-top:var(--sp-5);border-top:1px solid var(--border)">' +
          "<h4 style='font-size:var(--fs-md)'>" + t("dash.recent") + "</h4>" +
          '<div class="stack-sm" style="margin-top:var(--sp-3)">' +
          stats.slice(-3).reverse().map(a => '<a class="attempt-row" href="#/result/' + a.id + '">' +
            '<span class="badge ' + (a.score >= 75 ? "badge-jade" : "badge-warn") + '">' + a.score + "%</span>" +
            "<span>" + U.esc(a.titleUz) + "</span>" +
            '<span class="muted" style="font-size:var(--fs-2xs)">' + U.fmtDate(a.at, TLA.i18n.get()) + "</span>" +
            '<span class="arw">→</span></a>').join("") +
          "</div></div>"
        : "") +
      "</div>" +
      TLA.ui.complianceNote(t("exam.disclaimer")) +
      "</div>";
  }

  /* ---------------- Running ---------------- */
  function questionMarkup() {
    const item = session.items[session.index];
    const q = item.q;
    const answered = session.answers[session.index];
    const flagged = session.flags[session.index];

    const options = item.optOrder.map(function (origIdx, pos) {
      const selected = answered === pos;
      return '<button class="opt' + (q.optsAr ? " ar-opt" : "") + (selected ? " is-selected" : "") + '" data-opt="' + pos + '">' +
        '<span class="key">' + String.fromCharCode(65 + pos) + "</span>" +
        '<span class="otext">' + (q.optsAr ? q.opts[origIdx] : U.esc(q.opts[origIdx])) + "</span></button>";
    }).join("");

    const body = '<div class="card q-card">' +
      '<div class="row-between" style="margin-bottom:var(--sp-2)">' +
      '<span class="q-index">' + t("test.question") + " " + (session.index + 1) + " / " + session.items.length +
      " · " + t("misc.skill." + q.skill) + " · " + TLA.ui.levelPill(q.level) + "</span>" +
      '<button class="chip' + (flagged ? " is-active" : "") + '" id="flagBtn" aria-pressed="' + !!flagged + '">⚑ ' +
      (flagged ? t("test.flagged") : t("test.flag")) + "</button></div>" +
      (q.promptUz ? '<p class="q-text">' + U.esc(q.promptUz) + "</p>" : "") +
      (q.ar ? '<p class="q-text ar">' + q.ar + "</p>" : "") +
      options +
      "</div>";

    if (q.skill === "reading" && q.textId) {
      const text = TLA.data.texts[q.textId];
      return '<div class="reading-split">' +
        '<div class="passage"><div class="reader-tools">' +
        '<span class="muted" style="font-size:var(--fs-2xs)">' + t("test.fontSize") + "</span>" +
        '<button class="chip" data-font="0.95">A−</button><button class="chip" data-font="1.15">A</button><button class="chip" data-font="1.35">A+</button>' +
        "</div>" +
        '<h3 class="ptitle">' + text.titleAr + "</h3>" +
        '<div class="ptext" id="passageText">' + text.body + "</div></div>" +
        "<div>" + body + "</div></div>";
    }

    if (q.skill === "listening" && q.scriptId) {
      const script = TLA.data.scripts[q.scriptId];
      const demo = TLA.audio.mode() === "demo";
      return "<div>" +
        '<div class="q-audio card" style="margin-bottom:var(--sp-4)">' +
        '<div class="row-between" style="margin-bottom:var(--sp-3)"><strong>' + U.esc(script.titleUz) + "</strong>" +
        '<span class="badge badge-outline">' + t("test.audioOnce") + "</span></div>" +
        TLA.widgets.audioPlayerMarkup("testAudio", { allowTranscript: false }) +
        (demo
          ? '<div class="alert alert-warn" style="margin-top:var(--sp-3)"><span class="ico">◉</span><span>' +
            "Demo rejim: ovoz mavjud emas, shuning uchun matn ko‘rsatilmoqda.</span></div>" +
            '<p class="ar" style="margin-top:var(--sp-3)">' + script.body + "</p>"
          : '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-3)">' + t("test.transcriptHidden") + "</p>") +
        "</div>" + body + "</div>";
    }

    return body;
  }

  function paletteMarkup() {
    return '<div class="card q-nav-panel" data-reveal>' +
      '<div class="row-between" style="margin-bottom:var(--sp-3)"><strong style="font-size:var(--fs-sm)">' +
      t("test.question") + "</strong>" +
      '<span class="mono" style="font-size:var(--fs-2xs)">' +
      session.answers.filter(a => a !== null).length + "/" + session.items.length + "</span></div>" +
      '<div class="q-palette" id="palette">' +
      session.items.map(function (_, i) {
        const cls = [
          session.answers[i] !== null ? "answered" : "",
          session.flags[i] ? "flagged" : "",
          i === session.index ? "current" : ""
        ].join(" ");
        return '<button class="q-dot ' + cls + '" data-goto="' + i + '" aria-label="' + t("test.question") + " " + (i + 1) + '">' + (i + 1) + "</button>";
      }).join("") +
      "</div>" +
      '<div class="legend" style="margin-top:var(--sp-4)">' +
      '<span><i style="background:var(--brand-soft);border:1px solid var(--navy-400)"></i>' + t("test.answered") + "</span>" +
      '<span><i style="background:var(--surface);border:1px solid var(--border)"></i>' + t("test.unanswered") + "</span>" +
      '<span><i style="background:var(--warn)"></i>' + t("test.flagged") + "</span>" +
      "</div>" +
      '<button class="btn btn-primary btn-block" id="finishBtn" style="margin-top:var(--sp-5)">' + t("test.finish") + "</button>" +
      '<button class="btn btn-quiet btn-block" id="exitBtn" style="margin-top:var(--sp-2)">' + t("test.exit") + "</button>" +
      "</div>";
  }

  function runningMarkup() {
    return '<div class="test-bar"><div class="container">' +
      '<div class="row-between">' +
      '<div class="row" style="gap:var(--sp-3);min-width:0">' +
      '<span class="badge badge-navy nowrap">' + U.esc(session.test.titleUz) + "</span>" +
      '<span class="muted nowrap" style="font-size:var(--fs-2xs)">' + (session.index + 1) + " / " + session.items.length + "</span>" +
      "</div>" +
      '<div class="row" style="gap:var(--sp-3)">' +
      '<span class="timer" id="timer">' + U.fmtTime(session.left) + "</span>" +
      "</div></div>" +
      '<div class="progress sm" style="margin-top:var(--sp-2)"><span id="testProgress" style="width:' +
      U.pct(session.index + 1, session.items.length) + '%"></span></div>' +
      "</div></div>" +
      '<div class="container" style="padding-top:var(--sp-6);padding-bottom:var(--sp-9)">' +
      '<div class="test-shell">' +
      '<div id="questionHost">' + questionMarkup() + "</div>" +
      "<div>" + paletteMarkup() + "</div>" +
      "</div>" +
      '<div class="row-between" style="margin-top:var(--sp-6);gap:var(--sp-3)">' +
      '<button class="btn btn-ghost" id="prevBtn"' + (session.index === 0 ? " disabled" : "") + ">← " + t("action.prev") + "</button>" +
      '<button class="btn btn-primary btn-arrow" id="nextBtn">' +
      (session.index === session.items.length - 1 ? t("test.finish") : t("action.next")) + ' <span class="arw">→</span></button>' +
      "</div></div>";
  }

  /* ---------------- Section flows (writing / speaking) ---------------- */
  function specialMarkup(test) {
    const level = test.levels[1] || test.levels[0];
    if (test.section === "writing") {
      const task = TLA.data.writingTasks.filter(w => w.level === level)[0] || TLA.data.writingTasks[2];
      return '<div class="container">' + TLA.widgets.writingMarkup(task) + "</div>";
    }
    const task = TLA.data.speakingTasks.filter(s => s.level === level)[0] || TLA.data.speakingTasks[2];
    return '<div class="container">' + TLA.widgets.speakingMarkup(task) + "</div>";
  }

  /* ---------------- Submit ---------------- */
  function finish(auto) {
    const result = TLA.engine.scoreAttempt(session.items, session.answers);
    const level = TLA.engine.estimateLevel(result);
    const detail = session.items.map(function (item, i) {
      return {
        ref: item.ref,
        given: session.answers[i],
        correctPos: item.correctPos,
        ok: session.answers[i] === item.correctPos,
        optOrder: item.optOrder
      };
    });

    const attempt = TLA.state.recordAttempt({
      testId: session.test.id,
      titleUz: session.test.titleUz,
      kind: session.test.kind,
      track: session.test.track,
      score: result.score,
      correct: result.correct,
      total: result.total,
      skillScores: result.skillScores,
      skillLevels: TLA.engine.skillLevels(session.items, result),
      levelAccuracy: result.levelAccuracy,
      level: level,
      seconds: session.spent,
      auto: !!auto,
      detail: detail
    });

    clearSession();
    TLA.router.go("#/result/" + attempt.id);
  }

  function confirmFinish() {
    const unanswered = session.answers.filter(a => a === null).length;
    TLA.ui.confirmDialog(
      t("test.confirmTitle"),
      t("test.confirmBody", { n: unanswered }),
      t("test.confirmYes"),
      function () { finish(false); }
    );
  }

  /* ---------------- Mount running ---------------- */
  function paintQuestion() {
    const host = U.$("#questionHost");
    if (!host) return;
    if (player) { player.destroy(); player = null; }
    host.innerHTML = questionMarkup();

    const q = session.items[session.index].q;
    if (q.skill === "listening" && q.scriptId && TLA.audio.mode() !== "demo") {
      player = TLA.widgets.mountAudioPlayer("testAudio", TLA.data.scripts[q.scriptId], { maxPlays: 2 });
    }

    U.$$("[data-opt]", host).forEach(function (btn) {
      btn.addEventListener("click", function () {
        const pos = Number(btn.dataset.opt);
        session.answers[session.index] = session.answers[session.index] === pos ? null : pos;
        U.$$("[data-opt]", host).forEach(b => b.classList.remove("is-selected"));
        if (session.answers[session.index] !== null) btn.classList.add("is-selected");
        paintPalette();
      });
    });

    const flagBtn = U.$("#flagBtn");
    if (flagBtn) {
      flagBtn.addEventListener("click", function () {
        session.flags[session.index] = !session.flags[session.index];
        flagBtn.classList.toggle("is-active", session.flags[session.index]);
        flagBtn.setAttribute("aria-pressed", String(!!session.flags[session.index]));
        flagBtn.innerHTML = "⚑ " + (session.flags[session.index] ? t("test.flagged") : t("test.flag"));
        paintPalette();
      });
    }

    U.$$("[data-font]", host).forEach(function (btn) {
      btn.addEventListener("click", function () {
        const p = U.$("#passageText");
        if (p) p.style.setProperty("--reader-scale", btn.dataset.font);
      });
    });

    const prevBtn = U.$("#prevBtn");
    const nextBtn = U.$("#nextBtn");
    if (prevBtn) prevBtn.disabled = session.index === 0;
    if (nextBtn) {
      nextBtn.innerHTML = (session.index === session.items.length - 1 ? t("test.finish") : t("action.next")) +
        ' <span class="arw">→</span>';
    }
    const progress = U.$("#testProgress");
    if (progress) progress.style.width = U.pct(session.index + 1, session.items.length) + "%";
  }

  function paintPalette() {
    const palette = U.$("#palette");
    if (!palette) return;
    U.$$(".q-dot", palette).forEach(function (dot, i) {
      dot.classList.toggle("answered", session.answers[i] !== null);
      dot.classList.toggle("flagged", !!session.flags[i]);
      dot.classList.toggle("current", i === session.index);
    });
    const counter = palette.parentElement.querySelector(".mono");
    if (counter) counter.textContent = session.answers.filter(a => a !== null).length + "/" + session.items.length;
  }

  function goTo(index) {
    session.index = U.clamp(index, 0, session.items.length - 1);
    paintQuestion();
    paintPalette();
    U.scrollToTop();
  }

  function startTicker() {
    clearInterval(ticker);
    ticker = setInterval(function () {
      if (!session) return clearInterval(ticker);
      session.left--;
      session.spent++;
      const el = U.$("#timer");
      if (el) {
        el.textContent = U.fmtTime(session.left);
        el.classList.toggle("warn", session.left <= 120 && session.left > 30);
        el.classList.toggle("danger", session.left <= 30);
      }
      if (session.left <= 0) {
        clearInterval(ticker);
        TLA.ui.toast(t("test.timeUp"), "error");
        finish(true);
      }
    }, 1000);
  }

  function bindRunning() {
    const host = U.$("#pageHost");
    host.addEventListener("click", function (ev) {
      const dot = ev.target.closest("[data-goto]");
      if (dot) return goTo(Number(dot.dataset.goto));
      if (ev.target.closest("#prevBtn")) return goTo(session.index - 1);
      if (ev.target.closest("#nextBtn")) {
        if (session.index === session.items.length - 1) return confirmFinish();
        return goTo(session.index + 1);
      }
      if (ev.target.closest("#finishBtn")) return confirmFinish();
      if (ev.target.closest("#exitBtn")) {
        TLA.ui.confirmDialog(t("test.exit"), t("test.exitConfirm"), t("test.exit"), function () {
          clearSession();
          TLA.router.go("#/tests");
        }, true);
      }
    });

    session.keyHandler = function (ev) {
      if (!session) return;
      if (document.querySelector("#modalRoot:not([hidden])")) return;
      const key = ev.key.toLowerCase();
      if (["1", "2", "3", "4", "a", "b", "c", "d"].indexOf(key) !== -1) {
        const map = { "1": 0, "2": 1, "3": 2, "4": 3, a: 0, b: 1, c: 2, d: 3 };
        const btn = U.$$("[data-opt]")[map[key]];
        if (btn) btn.click();
      } else if (ev.key === "ArrowRight") goTo(session.index + (TLA.i18n.isRTL() ? -1 : 1));
      else if (ev.key === "ArrowLeft") goTo(session.index + (TLA.i18n.isRTL() ? 1 : -1));
      else if (key === "f") { const f = U.$("#flagBtn"); if (f) f.click(); }
    };
    document.addEventListener("keydown", session.keyHandler);

    if (session.test.kind === "mock") {
      session.visHandler = function () {
        if (document.hidden && session) {
          session.tabSwitches = (session.tabSwitches || 0) + 1;
          TLA.ui.toast(t("test.tabWarning"), "error");
        }
      };
      document.addEventListener("visibilitychange", session.visHandler);
    }
  }

  /* ---------------- Page object ---------------- */
  TLA.pages.test = {
    render: function (params) {
      const test = TLA.data.testById(params.id);
      if (!test) return TLA.pages.notFound.render();
      if (session && session.test.id !== test.id) clearSession();
      if (session && session.running) return runningMarkup();
      if (test.type === "writing" || test.type === "speaking") {
        return TLA.ui.pageHead({
          crumbs: [{ label: t("nav.mock"), href: "#/tests" }, { label: test.titleUz }],
          eyebrow: test.track ? test.track.toUpperCase() : "",
          title: test.titleUz,
          lead: test.descUz
        }) + '<section class="section">' + specialMarkup(test) + "</section>";
      }
      return '<section class="section">' + introMarkup(test) + "</section>";
    },

    mounted: function (params) {
      const test = TLA.data.testById(params.id);
      if (!test) return;

      if (test.type === "writing") {
        const level = test.levels[1] || test.levels[0];
        const task = TLA.data.writingTasks.filter(w => w.level === level)[0] || TLA.data.writingTasks[2];
        TLA.widgets.mountWriting(task);
        return;
      }
      if (test.type === "speaking") {
        const level = test.levels[1] || test.levels[0];
        const task = TLA.data.speakingTasks.filter(s => s.level === level)[0] || TLA.data.speakingTasks[2];
        TLA.widgets.mountSpeaking(task);
        return;
      }

      if (session && session.running) {
        bindRunning();
        paintQuestion();
        paintPalette();
        startTicker();
        return;
      }

      const startBtn = U.$("#startTest");
      if (!startBtn) return;
      startBtn.addEventListener("click", function () {
        const items = test.id === "diagnostic"
          ? TLA.engine.buildDiagnostic("d-" + Date.now())
          : TLA.engine.buildTest(test, test.id + "-" + Date.now());

        if (!items.length) {
          TLA.ui.toast("Bu test uchun savollar topilmadi.", "error");
          return;
        }
        session = {
          test: test,
          items: items,
          answers: new Array(items.length).fill(null),
          flags: new Array(items.length).fill(false),
          index: 0,
          left: test.minutes * 60,
          spent: 0,
          running: true
        };
        TLA.state.track("test_started", { test: test.id });
        TLA.router.rerender();
      });
    },

    unmount: function () {
      if (session && session.keyHandler) document.removeEventListener("keydown", session.keyHandler);
      if (session && session.visHandler) document.removeEventListener("visibilitychange", session.visHandler);
      if (session && !session.running) clearSession();
      if (player) { player.destroy(); player = null; }
      TLA.audio.stopAll();
    },

    isRunning: function () { return !!(session && session.running); },

    meta: function (params) {
      const test = TLA.data.testById(params.id);
      return test ? { title: test.titleUz + " — Tatbiqul Lisan Academy", desc: test.descUz } : null;
    }
  };
})();
