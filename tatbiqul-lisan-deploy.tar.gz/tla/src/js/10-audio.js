/* ============================================================
   AUDIO — listening playback
   Uses the device speech engine for Arabic when a voice exists.
   When it does not, the player runs in a clearly labelled demo
   mode and the transcript becomes available so the exercise
   stays usable instead of silently failing.
   In production these calls are replaced by real audio files
   served from object storage (see services layer in README).
   ============================================================ */
window.TLA = window.TLA || {};

TLA.audio = (function () {
  "use strict";

  let voices = [];
  let arabicVoice = null;
  let current = null;

  function refreshVoices() {
    if (!("speechSynthesis" in window)) return;
    try {
      voices = window.speechSynthesis.getVoices() || [];
      arabicVoice = voices.filter(v => (v.lang || "").toLowerCase().indexOf("ar") === 0)[0] || null;
    } catch (e) {
      voices = [];
      arabicVoice = null;
    }
  }

  if ("speechSynthesis" in window) {
    refreshVoices();
    try { window.speechSynthesis.onvoiceschanged = refreshVoices; } catch (e) { /* ignore */ }
  }

  function hasArabicVoice() { return !!arabicVoice; }
  function mode() { return arabicVoice ? "speech" : "demo"; }

  /**
   * Creates a playback controller for one script.
   * Callbacks: onTick(progress 0..1, elapsedSeconds), onEnd(), onState(state)
   */
  function createPlayer(options) {
    const opts = options || {};
    const totalSeconds = Math.max(4, opts.seconds || 30);
    let rate = 1;
    let elapsed = 0;
    let timer = null;
    let state = "idle";
    let plays = 0;

    function emitState(next) {
      state = next;
      if (opts.onState) opts.onState(next);
    }

    function tick() {
      elapsed += 0.2 * rate;
      const progress = Math.min(1, elapsed / totalSeconds);
      if (opts.onTick) opts.onTick(progress, Math.min(totalSeconds, elapsed));
      if (progress >= 1) stop(true);
    }

    function startTimer() {
      clearInterval(timer);
      timer = setInterval(tick, 200);
    }

    function speak() {
      if (!("speechSynthesis" in window) || !arabicVoice || !opts.text) return false;
      try {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(opts.text);
        utter.voice = arabicVoice;
        utter.lang = arabicVoice.lang || "ar-SA";
        utter.rate = rate;
        utter.onend = function () { stop(true); };
        utter.onerror = function () { stop(true); };
        window.speechSynthesis.speak(utter);
        return true;
      } catch (e) {
        return false;
      }
    }

    function play() {
      if (state === "playing") return;
      if (opts.maxPlays && plays >= opts.maxPlays && elapsed === 0) {
        if (opts.onLimit) opts.onLimit();
        return;
      }
      if (elapsed === 0 || elapsed >= totalSeconds) {
        elapsed = 0;
        plays++;
        speak();
      } else if ("speechSynthesis" in window && arabicVoice) {
        try { window.speechSynthesis.resume(); } catch (e) { /* ignore */ }
      }
      startTimer();
      emitState("playing");
    }

    function pause() {
      clearInterval(timer);
      if ("speechSynthesis" in window && arabicVoice) {
        try { window.speechSynthesis.pause(); } catch (e) { /* ignore */ }
      }
      emitState("paused");
    }

    function stop(finished) {
      clearInterval(timer);
      timer = null;
      if ("speechSynthesis" in window) {
        try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
      }
      if (finished) {
        elapsed = totalSeconds;
        if (opts.onTick) opts.onTick(1, totalSeconds);
        if (opts.onEnd) opts.onEnd();
      } else {
        elapsed = 0;
        if (opts.onTick) opts.onTick(0, 0);
      }
      emitState("idle");
    }

    function toggle() { state === "playing" ? pause() : play(); }

    function setRate(value) {
      rate = value;
      if (state === "playing") { stop(false); play(); }
    }

    function seek(fraction) {
      elapsed = totalSeconds * Math.max(0, Math.min(1, fraction));
      if (opts.onTick) opts.onTick(elapsed / totalSeconds, elapsed);
    }

    function destroy() { stop(false); }

    return {
      play, pause, stop, toggle, setRate, seek, destroy,
      get state() { return state; },
      get plays() { return plays; },
      get total() { return totalSeconds; },
      get rate() { return rate; }
    };
  }

  /** One-shot pronunciation for a single word or sentence. */
  function speakOnce(text) {
    if (!("speechSynthesis" in window)) return false;
    refreshVoices();
    if (!arabicVoice) return false;
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.voice = arabicVoice;
      utter.lang = arabicVoice.lang || "ar-SA";
      utter.rate = 0.85;
      window.speechSynthesis.speak(utter);
      return true;
    } catch (e) {
      return false;
    }
  }

  function stopAll() {
    if (current) { current.destroy(); current = null; }
    if ("speechSynthesis" in window) {
      try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    }
  }

  return { hasArabicVoice, mode, createPlayer, speakOnce, stopAll, refreshVoices };
})();
