/* ============================================================
   PAGES — Learn (levels, course, lesson) + shared widgets
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};
TLA.widgets = TLA.widgets || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  /* ================= Shared widgets ================= */

  /** Audio player markup + controller. `mode` demo when no Arabic voice. */
  TLA.widgets.audioPlayerMarkup = function (id, opts) {
    const o = opts || {};
    const demo = TLA.audio.mode() === "demo";
    return '<div class="audio-player" id="' + id + '">' +
      '<div class="ap-row">' +
      '<button class="ap-play" data-ap="toggle" aria-label="' + U.attr(t("lesson.listen")) + '">▶</button>' +
      '<div class="wave" aria-hidden="true">' + new Array(18).fill('<i></i>').join("") + "</div>" +
      '<span class="ap-time" data-ap="time">00:00</span>' +
      "</div>" +
      '<div class="ap-track" data-ap="track" role="slider" tabindex="0" aria-label="progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">' +
      '<span class="ap-fill" data-ap="fill"></span></div>' +
      '<div class="ap-ctrls">' +
      '<button class="ap-btn" data-ap="rate" data-value="0.75">0.75×</button>' +
      '<button class="ap-btn" data-ap="rate" data-value="1" aria-pressed="true">1×</button>' +
      '<button class="ap-btn" data-ap="rate" data-value="1.25">1.25×</button>' +
      '<button class="ap-btn" data-ap="restart">↺</button>' +
      (o.allowTranscript ? '<button class="ap-btn" data-ap="transcript">' + t("test.showTranscript") + "</button>" : "") +
      '<span class="spacer"></span>' +
      '<span class="ap-note">' + (demo ? "Demo audio (qurilmada arabcha ovoz yo‘q)" : "Nutq sintezi · arabcha") + "</span>" +
      "</div>" +
      (o.allowTranscript ? '<div class="ap-transcript ar" data-ap="transcript-body" hidden style="margin-top:var(--sp-3);padding-top:var(--sp-3);border-top:1px solid rgba(231,205,147,.2)"></div>' : "") +
      "</div>";
  };

  TLA.widgets.mountAudioPlayer = function (id, script, opts) {
    const o = opts || {};
    const root = document.getElementById(id);
    if (!root || !script) return null;
    const fill = root.querySelector('[data-ap="fill"]');
    const time = root.querySelector('[data-ap="time"]');
    const playBtn = root.querySelector('[data-ap="toggle"]');
    const wave = root.querySelector(".wave");
    const track = root.querySelector('[data-ap="track"]');
    const transcriptBody = root.querySelector('[data-ap="transcript-body"]');

    const player = TLA.audio.createPlayer({
      text: script.body,
      seconds: script.seconds,
      maxPlays: o.maxPlays,
      onTick: function (progress, elapsed) {
        fill.style.width = (progress * 100).toFixed(1) + "%";
        time.textContent = U.fmtTime(elapsed);
        track.setAttribute("aria-valuenow", Math.round(progress * 100));
      },
      onState: function (state) {
        playBtn.textContent = state === "playing" ? "❚❚" : "▶";
        wave.classList.toggle("playing", state === "playing");
      },
      onEnd: function () { if (o.onEnd) o.onEnd(); },
      onLimit: function () { TLA.ui.toast(t("test.audioOnce"), "info"); }
    });

    root.addEventListener("click", function (ev) {
      const btn = ev.target.closest("[data-ap]");
      if (!btn) return;
      const kind = btn.dataset.ap;
      if (kind === "toggle") player.toggle();
      else if (kind === "restart") { player.stop(false); player.play(); }
      else if (kind === "rate") {
        root.querySelectorAll('[data-ap="rate"]').forEach(b => b.setAttribute("aria-pressed", "false"));
        btn.setAttribute("aria-pressed", "true");
        player.setRate(Number(btn.dataset.value));
      } else if (kind === "transcript") {
        const open = transcriptBody.hidden;
        transcriptBody.hidden = !open;
        if (open) transcriptBody.textContent = script.body;
        btn.textContent = open ? t("test.hideTranscript") : t("test.showTranscript");
      } else if (kind === "track") {
        const rect = track.getBoundingClientRect();
        const ratio = TLA.i18n.isRTL()
          ? (rect.right - ev.clientX) / rect.width
          : (ev.clientX - rect.left) / rect.width;
        player.seek(ratio);
      }
    });

    return player;
  };

  /** Vocabulary card with pronunciation + save-to-list. */
  TLA.widgets.vocabCard = function (entry) {
    const saved = TLA.state.hasWord(entry.ar);
    return '<article class="vocab-card">' +
      '<div class="row-between"><span class="word">' + entry.ar + "</span>" +
      TLA.ui.levelPill(entry.level) + "</div>" +
      '<span class="translit">' + U.esc(entry.tr) + " · " + t("dict.root") + ": " + U.esc(entry.root) + "</span>" +
      '<span class="mean">' + U.esc(entry.uz) + "</span>" +
      '<p class="ex">' + entry.ex + "</p>" +
      '<p class="muted" style="font-size:var(--fs-2xs)">' + U.esc(entry.exUz) + "</p>" +
      '<div class="vc-actions">' +
      '<button class="btn btn-quiet btn-sm" data-action="speak" data-text="' + U.attr(entry.ar) + '">◉ ' + t("lesson.listen") + "</button>" +
      '<button class="chip' + (saved ? " is-active" : "") + '" data-action="save-word" data-word="' + U.attr(entry.ar) + '"' +
      ' aria-pressed="' + saved + '">✦ ' + (saved ? t("lesson.added") : t("lesson.addWord")) + "</button>" +
      "</div></article>";
  };

  /** Writing task with live counter, draft saving and a self-check rubric. */
  TLA.widgets.writingMarkup = function (task) {
    const rubric = [
      { id: "content", uz: "Mazmun va mavzuga muvofiqlik" },
      { id: "structure", uz: "Tuzilma va bog‘lovchilar" },
      { id: "grammar", uz: "Grammatik aniqlik" },
      { id: "vocab", uz: "Leksik boylik" }
    ];
    return '<div class="stack-lg">' +
      '<div class="card">' +
      '<div class="row-between" style="margin-bottom:var(--sp-3)">' +
      '<span class="eyebrow">' + t("lesson.tabs.writing") + "</span>" +
      '<span class="badge">' + task.minWords + "–" + task.maxWords + " " + t("misc.words") + " · " + task.minutes + " " + t("test.minutes") + "</span></div>" +
      '<p class="ar ar-lg">' + task.promptAr + "</p>" +
      '<p class="muted" style="margin-top:var(--sp-2)">' + U.esc(task.promptUz) + "</p>" +
      '<ul class="row row-wrap" style="margin-top:var(--sp-4);gap:var(--sp-2)">' +
      task.hints.map(h => '<li class="badge badge-outline">' + U.esc(h) + "</li>").join("") + "</ul>" +
      "</div>" +
      '<div class="card writing-area ar-input">' +
      '<textarea class="textarea" id="writingBox" placeholder="اُكْتُبْ هُنَا..." aria-label="' + U.attr(task.promptUz) + '"></textarea>' +
      '<div class="wcount"><span><b id="wCount">0</b> / ' + task.minWords + "–" + task.maxWords + " " + t("misc.words") + "</span>" +
      '<span id="wStatus" class="muted">Qoralama saqlanmagan</span></div>' +
      '<div class="row row-wrap" style="margin-top:var(--sp-4)">' +
      '<button class="btn btn-ghost btn-sm" id="wSave">' + t("action.save") + " (qoralama)</button>" +
      '<button class="btn btn-primary btn-sm" id="wSubmit">' + t("action.submit") + "</button>" +
      "</div></div>" +
      '<div class="card" id="wRubric" hidden>' +
      "<h4>O‘z-o‘zini baholash mezoni</h4>" +
      '<p class="muted" style="font-size:var(--fs-sm);margin-bottom:var(--sp-4)">Har bir mezonni 1–5 ball bilan belgilang. Bu mustaqil mashq uchun ko‘rsatkich — rasmiy imtihon bahosi emas.</p>' +
      '<div class="rubric">' +
      rubric.map(r => '<div class="rubric-item"><span>' + U.esc(r.uz) + '</span><span class="stars" data-rubric="' + r.id + '">' +
        [1, 2, 3, 4, 5].map(n => '<button data-star="' + n + '" aria-label="' + n + '">★</button>').join("") + "</span></div>").join("") +
      "</div>" +
      TLA.ui.complianceNote("Yozma ishlar o‘qituvchi tekshiruviga yuborilishi mumkin. Avtomatik baholash rasmiy imtihon bahosi o‘rnini bosmaydi.") +
      "</div></div>";
  };

  TLA.widgets.mountWriting = function (task, onSubmit) {
    const box = U.$("#writingBox");
    if (!box) return;
    const counter = U.$("#wCount");
    const status = U.$("#wStatus");
    const draftKey = "draft:" + task.id;
    const p = TLA.state.profile();
    p.drafts = p.drafts || {};
    if (p.drafts[draftKey]) box.value = p.drafts[draftKey];

    function count() {
      const words = box.value.trim().split(/\s+/).filter(Boolean).length;
      counter.textContent = words;
      counter.style.color = words >= task.minWords && words <= task.maxWords ? "var(--success)" : "var(--ink-2)";
      return words;
    }
    count();
    box.addEventListener("input", U.debounce(count, 150));

    U.$("#wSave").addEventListener("click", function () {
      p.drafts[draftKey] = box.value;
      TLA.state.addXp(0, "draft");
      status.textContent = "Qoralama saqlandi · " + new Date().toLocaleTimeString();
      TLA.ui.toast(t("action.save"), "success");
    });

    U.$("#wSubmit").addEventListener("click", function () {
      const words = count();
      if (words < Math.max(10, Math.floor(task.minWords * 0.5))) {
        TLA.ui.toast("Matn juda qisqa — kamida " + task.minWords + " so‘z yozing.", "error");
        return;
      }
      p.drafts[draftKey] = box.value;
      U.$("#wRubric").hidden = false;
      U.$("#wRubric").scrollIntoView({ behavior: "smooth", block: "start" });
      TLA.state.addXp(15, "writing");
      TLA.ui.toast(t("misc.xpEarned", { n: 15 }), "xp");
      if (onSubmit) onSubmit(box.value);
    });

    U.delegate(document, "click", "[data-star]", function (ev, btn) {
      const group = btn.closest(".stars");
      const value = Number(btn.dataset.star);
      U.$$("[data-star]", group).forEach(function (b) {
        b.classList.toggle("on", Number(b.dataset.star) <= value);
      });
    });
  };

  /** Speaking practice: preparation timer, recorder (with graceful fallback). */
  TLA.widgets.speakingMarkup = function (task) {
    return '<div class="stack-lg">' +
      '<div class="card"><div class="row-between" style="margin-bottom:var(--sp-3)">' +
      '<span class="eyebrow">' + t("lesson.tabs.speaking") + "</span>" +
      '<span class="badge">' + task.prepSeconds + "s tayyorgarlik · " + task.speakSeconds + "s javob</span></div>" +
      '<p class="ar ar-lg">' + task.promptAr + "</p>" +
      '<p class="muted" style="margin-top:var(--sp-2)">' + U.esc(task.promptUz) + "</p>" +
      '<button class="btn btn-quiet btn-sm" style="margin-top:var(--sp-3)" data-action="speak" data-text="' + U.attr(task.promptAr) + '">◉ ' + t("lesson.listen") + "</button>" +
      "</div>" +
      '<div class="rec-panel">' +
      '<div class="timer" id="spTimer">' + U.fmtTime(task.prepSeconds) + "</div>" +
      '<p class="muted" id="spPhase" style="font-size:var(--fs-sm)">Tayyorgarlik bosqichi — fikringizni tuzing.</p>' +
      '<button class="rec-btn" id="spRec" aria-label="Yozib olish">●</button>' +
      '<div class="row" style="gap:var(--sp-2)">' +
      '<button class="btn btn-ghost btn-sm" id="spPlay" disabled>▶ Tinglash</button>' +
      '<button class="btn btn-ghost btn-sm" id="spAgain" disabled>↺ Qayta yozish</button>' +
      "</div>" +
      '<audio id="spAudio" controls hidden style="width:100%"></audio>' +
      '<p class="muted" id="spNote" style="font-size:var(--fs-2xs);max-width:44ch"></p>' +
      "</div>" +
      '<div class="card"><h4>O‘zini tekshirish ro‘yxati</h4>' +
      '<div class="stack-sm" style="margin-top:var(--sp-3)">' +
      ["Javob savolga to‘g‘ridan-to‘g‘ri javob berdimi?", "Kamida uchta murakkab jumla ishlatildimi?",
        "Bog‘lovchilar (لِأَنَّ، لِذٰلِكَ) qo‘llandimi?", "Talaffuz aniq va tezlik barqarormi?"]
        .map(q => '<label class="check"><input type="checkbox"><span>' + U.esc(q) + "</span></label>").join("") +
      "</div>" +
      TLA.ui.complianceNote("Gapirish mashqi mustaqil tayyorgarlik uchun. Avtomatik baholash rasmiy imtihon bahosi hisoblanmaydi.") +
      "</div></div>";
  };

  TLA.widgets.mountSpeaking = function (task) {
    const timerEl = U.$("#spTimer");
    const phaseEl = U.$("#spPhase");
    const recBtn = U.$("#spRec");
    const playBtn = U.$("#spPlay");
    const againBtn = U.$("#spAgain");
    const audioEl = U.$("#spAudio");
    const noteEl = U.$("#spNote");
    if (!recBtn) return;

    let phase = "prep";
    let left = task.prepSeconds;
    let interval = null;
    let recorder = null;
    let chunks = [];

    function paint() { timerEl.textContent = U.fmtTime(left); }

    function startCountdown(seconds, onDone) {
      clearInterval(interval);
      left = seconds;
      paint();
      interval = setInterval(function () {
        left--;
        paint();
        if (left <= 0) { clearInterval(interval); onDone(); }
      }, 1000);
    }

    startCountdown(task.prepSeconds, function () {
      phaseEl.textContent = "Tayyorgarlik tugadi — yozishni boshlashingiz mumkin.";
    });

    function stopRecording() {
      clearInterval(interval);
      phase = "done";
      recBtn.classList.remove("recording");
      recBtn.textContent = "●";
      phaseEl.textContent = "Yozib olindi. Tinglab ko‘ring va ro‘yxat bo‘yicha o‘zingizni tekshiring.";
      againBtn.disabled = false;
      TLA.state.addXp(10, "speaking");
      if (recorder && recorder.state === "recording") recorder.stop();
    }

    recBtn.addEventListener("click", function () {
      if (phase === "recording") { stopRecording(); return; }
      phase = "recording";
      recBtn.classList.add("recording");
      recBtn.textContent = "■";
      phaseEl.textContent = "Yozilmoqda — savolga javob bering.";
      startCountdown(task.speakSeconds, stopRecording);

      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder) {
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
          chunks = [];
          recorder = new MediaRecorder(stream);
          recorder.ondataavailable = e => chunks.push(e.data);
          recorder.onstop = function () {
            const blob = new Blob(chunks, { type: "audio/webm" });
            audioEl.src = URL.createObjectURL(blob);
            audioEl.hidden = false;
            playBtn.disabled = false;
            stream.getTracks().forEach(tr => tr.stop());
          };
          recorder.start();
        }).catch(function () {
          noteEl.textContent = "Mikrofonga ruxsat berilmadi — mashq taymer rejimida davom etadi. Javobingizni ovoz chiqarib ayting va ro‘yxat bo‘yicha baholang.";
        });
      } else {
        noteEl.textContent = "Bu muhitda yozib olish qo‘llab-quvvatlanmaydi — mashq taymer rejimida davom etadi.";
      }
    });

    playBtn.addEventListener("click", function () { audioEl.play(); });
    againBtn.addEventListener("click", function () {
      phase = "prep";
      audioEl.hidden = true;
      playBtn.disabled = true;
      againBtn.disabled = true;
      phaseEl.textContent = "Tayyorgarlik bosqichi — fikringizni tuzing.";
      startCountdown(task.prepSeconds, function () {
        phaseEl.textContent = "Tayyorgarlik tugadi — yozishni boshlashingiz mumkin.";
      });
    });
  };

  /* ================= Learn index ================= */
  TLA.pages.learn = {
    render: function () {
      const courses = TLA.data.courses;
      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.learn") }],
        eyebrow: "A1 → C2",
        title: t("courses.title"),
        lead: t("courses.sub")
      }) +
        '<section class="section"><div class="container">' +
        '<div class="grid grid-3">' +
        courses.map(function (c, i) {
          const prog = TLA.state.courseProgress(c.id);
          return '<article class="course-card" data-reveal style="--reveal-delay:' + (i * 60) + 'ms">' +
            '<div class="cc-top"><div>' + TLA.ui.levelPill(c.code) +
            '<h3 style="margin-top:var(--sp-3)">' + U.esc(c.titleUz) + "</h3>" +
            '<p class="ar-title">' + c.titleAr + "</p></div>" +
            (c.free ? '<span class="badge badge-free">' + t("misc.free") + "</span>"
              : '<span class="badge badge-gold">' + t("misc.premium") + "</span>") + "</div>" +
            '<p class="desc">' + U.esc(c.descUz) + "</p>" +
            '<div class="facts"><span><b>' + c.lessons + "</b> " + t("courses.lessons") + "</span>" +
            "<span><b>~" + c.hours + "</b> soat</span><span><b>" + U.fmtNumber(c.words) + "</b> so‘z</span></div>" +
            '<div class="skills">' + TLA.ui.skillBadges(c.skills.slice(0, 4)) + "</div>" +
            (prog.pct > 0
              ? '<div class="meter-row"><span class="lbl">' + t("courses.progress") + '</span><span class="val">' + prog.pct +
                '%</span><span class="progress jade"><span style="width:' + prog.pct + '%"></span></span></div>'
              : "") +
            '<div class="cc-foot"><span class="muted" style="font-size:var(--fs-2xs)">' + U.esc(c.subtitleUz) + "</span>" +
            '<a class="btn btn-soft btn-sm btn-arrow" href="#/learn/' + c.id + '">' +
            (prog.pct > 0 ? t("courses.continue") : t("courses.explore")) + ' <span class="arw">→</span></a></div>' +
            "</article>";
        }).join("") +
        "</div>" +
        '<div class="card card-dark" style="margin-top:var(--sp-8)" data-reveal>' +
        '<div class="row-between row-wrap" style="gap:var(--sp-5)">' +
        '<div style="max-width:52ch"><h3 style="color:var(--ivory)">Qaysi darajadan boshlashni bilmayapsizmi?</h3>' +
        '<p class="muted" style="margin-top:var(--sp-2)">20 daqiqalik bepul diagnostika har bir ko‘nikma bo‘yicha alohida natija beradi va mos kursni tavsiya qiladi.</p></div>' +
        '<a class="btn btn-gold" href="#/test/diagnostic">' + t("action.startFree") + "</a></div></div>" +
        "</div></section>";
    },
    meta: { title: "Arab tili kurslari A1–C2 — Tatbiqul Lisan Academy", desc: "CEFR tizimiga moslashtirilgan olti bosqichli arab tili kurslari." }
  };

  /* ================= Course page ================= */
  TLA.pages.course = {
    render: function (params) {
      const course = TLA.data.courseById(params.id);
      if (!course) return TLA.pages.notFound.render();
      const prog = TLA.state.courseProgress(course.id);
      const level = TLA.data.levels.filter(l => l.id === course.level)[0];

      const curriculum = course.modules.map(function (m, mi) {
        const doneCount = m.lessons.filter(l => TLA.state.lessonDone(l.id)).length;
        return '<div class="module">' +
          '<button class="module-head" data-module="' + m.id + '" aria-expanded="' + (mi === 0) + '">' +
          '<span class="midx">' + String(m.no).padStart(2, "0") + "</span>" +
          '<span style="flex:1"><span class="mt">' + U.esc(m.titleUz) + '</span><br><span class="ms ar">' + m.titleAr + "</span></span>" +
          '<span class="badge">' + doneCount + "/" + m.lessons.length + "</span>" +
          '<span class="caret" aria-hidden="true">▾</span></button>' +
          '<div class="module-body" id="' + m.id + '"' + (mi === 0 ? "" : " hidden") + ">" +
          m.lessons.map(function (l) {
            const done = TLA.state.lessonDone(l.id);
            const locked = !l.free && !TLA.state.isAuthed();
            return '<a class="lesson-row ' + (done ? "done" : "") + (locked ? " locked" : "") + '" href="#/lesson/' + l.id + '">' +
              '<span class="ldot">' + (done ? "✓" : l.no) + "</span>" +
              '<span style="flex:1">' + U.esc(l.titleUz) + "</span>" +
              '<span class="badge badge-outline">' + t("misc.skill." + l.skill) + "</span>" +
              '<span class="muted" style="font-size:var(--fs-2xs)">' + l.minutes + " min</span>" +
              (l.free ? '<span class="badge badge-free">' + t("misc.free") + "</span>" : "") +
              "</a>";
          }).join("") +
          "</div></div>";
      }).join("");

      const firstUndone = course.modules.reduce((acc, m) => acc.concat(m.lessons), [])
        .filter(l => !TLA.state.lessonDone(l.id))[0];

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.learn"), href: "#/learn" }, { label: course.titleUz }],
        eyebrow: level.uz + " · CEFR " + course.code,
        title: course.titleUz,
        lead: course.descUz,
        extra: '<div class="row row-wrap" style="margin-top:var(--sp-5);gap:var(--sp-3)">' +
          '<a class="btn btn-primary btn-arrow" href="#/lesson/' + (firstUndone ? firstUndone.id : course.modules[0].lessons[0].id) + '">' +
          (prog.done > 0 ? t("courses.continue") : t("courses.enroll")) + ' <span class="arw">→</span></a>' +
          '<a class="btn btn-ghost" href="#/test/darajaviy-' + course.id + '-placement">' + t("exam.practice") + "</a>" +
          (prog.pct > 0 ? '<span class="badge badge-jade">' + prog.done + "/" + prog.total + " · " + prog.pct + "%</span>" : "") +
          "</div>"
      }) +
        '<section class="section"><div class="container">' +
        '<div class="lesson-layout">' +
        '<div class="stack-lg">' +

        '<div class="card" data-reveal><h3>' + t("courses.forWhom") + "</h3>" +
        '<p class="muted" style="margin-top:var(--sp-3);line-height:1.7">' + U.esc(course.forWhom) + "</p></div>" +

        '<div class="card" data-reveal><h3>' + t("courses.outcomes") + "</h3>" +
        '<ul class="stack-sm" style="margin-top:var(--sp-4)">' +
        course.outcomes.map(o => '<li class="row row-top" style="gap:var(--sp-3)"><span style="color:var(--success)">✓</span><span>' +
          U.esc(o) + "</span></li>").join("") + "</ul></div>" +

        '<div data-reveal><h3 style="margin-bottom:var(--sp-4)">' + t("courses.curriculum") + "</h3>" + curriculum +
        '<div class="module" style="margin-top:var(--sp-3)"><div class="module-head" style="cursor:default">' +
        '<span class="midx" style="background:var(--accent-soft);color:var(--accent-ink)">★</span>' +
        '<span style="flex:1"><span class="mt">' + t("courses.finalTest") + '</span><br><span class="ms">' +
        course.code + " darajasi bo‘yicha to‘liq test</span></span>" +
        '<a class="btn btn-soft btn-sm" href="#/test/darajaviy-' + course.id + '-full">' + t("test.start") + "</a></div></div></div>" +

        '<div class="card" data-reveal><h3>' + t("courses.faq") + "</h3>" +
        '<div style="margin-top:var(--sp-4)">' +
        TLA.data.courseFaq.map(f => '<details class="acc"><summary>' + U.esc(f.q) + '</summary><div class="acc-body">' +
          U.esc(f.a) + "</div></details>").join("") + "</div></div>" +

        "</div>" +

        '<aside class="lesson-side">' +
        '<div class="card"><div class="row-between" style="margin-bottom:var(--sp-4)">' +
        "<strong>" + t("courses.progress") + '</strong><span class="mono">' + prog.pct + "%</span></div>" +
        '<div class="progress jade lg"><span style="width:' + prog.pct + '%"></span></div>' +
        '<div class="grid grid-2" style="gap:var(--sp-3);margin-top:var(--sp-4)">' +
        '<div class="stat-tile"><div class="k">' + t("courses.lessons") + '</div><div class="v">' + prog.total + "</div></div>" +
        '<div class="stat-tile"><div class="k">' + t("courses.duration") + '</div><div class="v">' + course.hours + "<span style='font-size:var(--fs-sm)'>s</span></div></div>" +
        "</div></div>" +

        '<div class="card"><h4>' + t("courses.skills") + "</h4>" +
        '<div class="row row-wrap" style="gap:6px;margin-top:var(--sp-3)">' + TLA.ui.skillBadges(course.skills) + "</div>" +
        '<div class="rule-gold" style="margin:var(--sp-4) 0"></div>' +
        '<h4 style="font-size:var(--fs-md)">' + t("courses.teacher") + "</h4>" +
        '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-2);line-height:1.6">' +
        "O‘qituvchi ma’lumotlari admin panel orqali kiritiladi. Biz o‘ylab topilgan malaka ma’lumotlarini ko‘rsatmaymiz.</p>" +
        '<a class="btn btn-ghost btn-sm btn-block" href="#/teachers" style="margin-top:var(--sp-3)">' + t("nav.teachers") + "</a></div>" +

        '<div class="card card-dark"><h4 style="color:var(--ivory)">' + t("nav.pricing") + "</h4>" +
        '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-2)">Premium tarifda barcha darajalar, mock imtihonlar va sertifikat ochiladi.</p>' +
        '<a class="btn btn-gold btn-block" href="#/pricing" style="margin-top:var(--sp-4)">' + t("pricing.choose") + "</a></div>" +
        "</aside>" +
        "</div></div></section>";
    },
    mounted: function () {
      U.$$("[data-module]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const body = document.getElementById(btn.dataset.module);
          const open = !body.hidden;
          body.hidden = open;
          btn.setAttribute("aria-expanded", String(!open));
        });
      });
    },
    meta: function (params) {
      const c = TLA.data.courseById(params.id);
      return c ? { title: c.titleUz + " — Tatbiqul Lisan Academy", desc: c.descUz } : null;
    }
  };

  /* ================= Lesson page ================= */
  const LESSON_TABS = ["lesson", "vocab", "grammar", "reading", "listening", "speaking", "writing", "practice"];

  TLA.pages.lesson = {
    render: function (params) {
      const found = TLA.data.lessonById(params.id);
      if (!found) return TLA.pages.notFound.render();
      const { course, module, lesson } = found;
      const done = TLA.state.lessonDone(lesson.id);
      const locked = !lesson.free && !TLA.state.isAuthed();

      const all = course.modules.reduce((acc, m) => acc.concat(m.lessons), []);
      const idx = all.findIndex(l => l.id === lesson.id);
      const next = all[idx + 1];
      const prev = all[idx - 1];

      if (locked) {
        return TLA.ui.pageHead({
          crumbs: [{ label: t("nav.learn"), href: "#/learn" }, { label: course.titleUz, href: "#/learn/" + course.id }, { label: lesson.titleUz }],
          title: lesson.titleUz
        }) + '<section class="section"><div class="container container-narrow">' +
          TLA.ui.emptyState("◍", t("misc.locked"), t("auth.needAuth"),
            '<div class="row" style="justify-content:center"><button class="btn btn-primary" data-action="auth-register">' +
            t("result.gateCta") + '</button><button class="btn btn-ghost" data-action="auth-login">' + t("action.login") + "</button></div>") +
          "</div></section>";
      }

      const tabs = '<div class="tabs" role="tablist">' +
        LESSON_TABS.map((k, i) => '<button class="tab" role="tab" data-tab="' + k + '" aria-selected="' + (i === 0) + '">' +
          t("lesson.tabs." + (k === "vocab" ? "vocab" : k)) + "</button>").join("") + "</div>";

      return TLA.ui.pageHead({
        crumbs: [
          { label: t("nav.learn"), href: "#/learn" },
          { label: course.titleUz, href: "#/learn/" + course.id },
          { label: module.titleUz }
        ],
        eyebrow: course.code + " · " + t("courses.module") + " " + module.no,
        title: lesson.titleUz,
        extra: '<p class="ar ar-lg" style="margin-top:var(--sp-2);color:var(--accent-ink)">' + lesson.titleAr + "</p>" +
          '<div class="row row-wrap" style="margin-top:var(--sp-4);gap:var(--sp-3)">' +
          '<span class="badge">' + t("misc.skill." + lesson.skill) + "</span>" +
          '<span class="badge badge-outline">' + lesson.minutes + " " + t("test.minutes") + "</span>" +
          (done ? '<span class="badge badge-jade">✓ ' + t("lesson.completed") + "</span>" : "") +
          '<span class="badge badge-demo">' + t("misc.demoContent") + "</span></div>"
      }) +
        '<section class="section"><div class="container"><div class="lesson-layout">' +
        "<div>" + tabs + '<div id="lessonPanels" style="margin-top:var(--sp-6)"></div>' +
        '<div class="row-between row-wrap" style="margin-top:var(--sp-8);gap:var(--sp-3);padding-top:var(--sp-6);border-top:1px solid var(--border)">' +
        (prev ? '<a class="btn btn-ghost" href="#/lesson/' + prev.id + '">← ' + t("action.prev") + "</a>" : "<span></span>") +
        '<div class="row" style="gap:var(--sp-3)">' +
        '<button class="btn ' + (done ? "btn-ghost" : "btn-success") + '" id="lessonDone"' + (done ? " disabled" : "") + ">" +
        (done ? "✓ " + t("lesson.completed") : t("lesson.complete")) + "</button>" +
        (next ? '<a class="btn btn-primary btn-arrow" href="#/lesson/' + next.id + '">' + t("lesson.next") + ' <span class="arw">→</span></a>' : "") +
        "</div></div></div>" +

        '<aside class="lesson-side">' +
        '<div class="card"><div class="row-between" style="margin-bottom:var(--sp-3)"><strong>' + U.esc(module.titleUz) + "</strong>" +
        '<span class="mono" style="font-size:var(--fs-2xs)">' + (idx + 1) + "/" + all.length + "</span></div>" +
        '<div class="progress"><span style="width:' + U.pct(idx + 1, all.length) + '%"></span></div>' +
        '<div class="stack-sm" style="margin-top:var(--sp-4);max-height:280px;overflow:auto">' +
        module.lessons.map(l => '<a class="lesson-row ' + (TLA.state.lessonDone(l.id) ? "done" : "") + '" href="#/lesson/' + l.id +
          '" style="border:0;border-radius:var(--r-sm);' + (l.id === lesson.id ? "background:var(--brand-soft)" : "") + '">' +
          '<span class="ldot">' + (TLA.state.lessonDone(l.id) ? "✓" : l.no) + "</span><span>" + U.esc(l.titleUz) + "</span></a>").join("") +
        "</div></div>" +
        '<div class="card"><h4 style="font-size:var(--fs-md)">' + t("lesson.test") + "</h4>" +
        '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-2)">Dars yakunida ' + course.code + ' darajasidagi mashq testini topshiring.</p>' +
        '<a class="btn btn-soft btn-block btn-sm" style="margin-top:var(--sp-3)" href="#/test/darajaviy-' + course.id + "-" + (lesson.skill === "reading" || lesson.skill === "listening" || lesson.skill === "grammar" || lesson.skill === "vocabulary" ? lesson.skill : "placement") + '">' +
        t("test.start") + "</a></div>" +
        "</aside></div></div></section>";
    },

    mounted: function (params) {
      const found = TLA.data.lessonById(params.id);
      if (!found) return;
      const { course, lesson } = found;
      const host = U.$("#lessonPanels");
      if (!host) return;

      const text = TLA.data.texts[lesson.textId];
      const grammar = TLA.data.grammar[lesson.grammarId];
      const script = Object.keys(TLA.data.scripts)
        .map(k => TLA.data.scripts[k])
        .filter(s => s.level === course.level)[0] || TLA.data.scripts.s_a1;
      const words = TLA.data.dictionary.filter(d => d.level === course.level).slice(0, 6);
      const writing = TLA.data.writingTasks.filter(w => w.level === course.level)[0];
      const speaking = TLA.data.speakingTasks.filter(s => s.level === course.level)[0];

      let activePlayer = null;

      function renderPanel(key) {
        if (activePlayer) { activePlayer.destroy(); activePlayer = null; }

        if (key === "lesson") {
          host.innerHTML = '<div class="stack-lg">' +
            '<div class="card"><span class="eyebrow">Dars maqsadi</span>' +
            '<h3 style="margin:var(--sp-3) 0">' + U.esc(lesson.titleUz) + "</h3>" +
            '<p class="muted" style="line-height:1.75">Ushbu darsda «' + U.esc(lesson.titleAr) + "» mavzusi bo‘yicha yangi so‘zlar, grammatik qoida, matn va tinglash mashqi beriladi. " +
            "Dars oxirida mashq savollari orqali o‘zlashtirishni tekshirasiz.</p>" +
            '<div class="grid grid-2" style="gap:var(--sp-3);margin-top:var(--sp-5)">' +
            '<div class="stat-tile"><div class="k">Asosiy ko‘nikma</div><div class="v" style="font-size:var(--fs-lg)">' +
            t("misc.skill." + lesson.skill) + "</div></div>" +
            '<div class="stat-tile"><div class="k">Davomiylik</div><div class="v" style="font-size:var(--fs-lg)">' + lesson.minutes + " min</div></div>" +
            "</div></div>" +
            '<div class="ar-block"><p class="ar ar-lg">' + text.body.split(".")[0] + ".</p>" +
            '<div class="translation">' + U.esc(text.uz.split(".")[0]) + ".</div>" +
            '<button class="btn btn-quiet btn-sm" style="margin-top:var(--sp-3)" data-action="speak" data-text="' +
            U.attr(text.body.split(".")[0]) + '">◉ ' + t("lesson.listen") + "</button></div>" +
            '<div class="alert alert-info"><span class="ico">◈</span><span>Har bir bo‘limni ketma-ket bajaring: leksika → grammatika → o‘qish → tinglash → mashq. Bu tartib eslab qolishni sezilarli oshiradi.</span></div>' +
            "</div>";
        } else if (key === "vocab") {
          host.innerHTML = '<div class="stack-lg"><div class="row-between"><h3>' + t("lesson.tabs.vocab") + "</h3>" +
            '<a class="btn btn-quiet btn-sm" href="#/dictionary">' + t("nav.dictionary") + " →</a></div>" +
            '<div class="grid grid-2">' + words.map(TLA.widgets.vocabCard).join("") + "</div>" +
            '<div class="alert alert-success"><span class="ico">✦</span><span>Saqlangan so‘zlar 1, 3, 7, 15 va 30-kunlarda takrorlashga chiqadi.</span></div></div>';
        } else if (key === "grammar") {
          host.innerHTML = '<div class="card"><span class="eyebrow">' + t("lesson.tabs.grammar") + "</span>" +
            '<h3 style="margin:var(--sp-3) 0">' + U.esc(grammar.titleUz) + "</h3>" +
            '<p class="ar ar-lg">' + grammar.titleAr + "</p>" +
            '<p style="margin-top:var(--sp-4);line-height:1.8;color:var(--ink-2)">' + U.esc(grammar.bodyUz) + "</p>" +
            '<div class="stack" style="margin-top:var(--sp-6)">' +
            grammar.examples.map(e => '<div class="ar-block" style="padding:var(--sp-4)"><p class="ar">' + e.ar + "</p>" +
              '<div class="translation">' + U.esc(e.uz) + "</div>" +
              '<button class="btn btn-quiet btn-sm" style="margin-top:var(--sp-2)" data-action="speak" data-text="' +
              U.attr(e.ar) + '">◉</button></div>').join("") +
            "</div></div>";
        } else if (key === "reading") {
          host.innerHTML = '<div class="passage" style="position:static;max-height:none">' +
            '<div class="reader-tools">' +
            '<span class="muted" style="font-size:var(--fs-2xs)">' + t("test.fontSize") + "</span>" +
            '<button class="chip" data-font="0.9">A−</button><button class="chip" data-font="1.1">A</button><button class="chip" data-font="1.3">A+</button>' +
            '<span class="spacer"></span>' +
            '<button class="chip" id="toggleTr">' + t("lesson.translation") + "</button>" +
            '<button class="btn btn-quiet btn-sm" data-action="speak" data-text="' + U.attr(text.body) + '">◉ ' + t("lesson.listen") + "</button>" +
            "</div>" +
            '<h3 class="ptitle">' + text.titleAr + "</h3>" +
            '<div class="ptext" id="readerText">' + text.body + "</div>" +
            '<div id="readerTr" hidden style="margin-top:var(--sp-5);padding-top:var(--sp-4);border-top:1px dashed var(--border-strong);color:var(--ink-2);line-height:1.8">' +
            U.esc(text.uz) + "</div></div>";
        } else if (key === "listening") {
          host.innerHTML = '<div class="stack-lg"><div class="card">' +
            '<div class="row-between" style="margin-bottom:var(--sp-4)"><h3>' + U.esc(script.titleUz) + "</h3>" +
            '<span class="badge">' + script.titleAr + "</span></div>" +
            TLA.widgets.audioPlayerMarkup("lessonAudio", { allowTranscript: true }) +
            '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-4)">Dars rejimida matn ochiq — imtihon rejimida esa tinglash bo‘limi yakunlangunicha yopiq bo‘ladi.</p>' +
            "</div>" +
            '<div class="card"><h4>Tarjima</h4><p class="muted" style="margin-top:var(--sp-3);line-height:1.75">' +
            U.esc(script.uz) + "</p></div></div>";
          activePlayer = TLA.widgets.mountAudioPlayer("lessonAudio", script, { allowTranscript: true });
        } else if (key === "speaking") {
          host.innerHTML = TLA.widgets.speakingMarkup(speaking);
          TLA.widgets.mountSpeaking(speaking);
        } else if (key === "writing") {
          host.innerHTML = TLA.widgets.writingMarkup(writing);
          TLA.widgets.mountWriting(writing);
        } else if (key === "practice") {
          const pool = TLA.data.filterQuestions({ level: course.level }).slice(0, 5);
          host.innerHTML = '<div class="stack-lg"><div class="row-between"><h3>' + t("lesson.tabs.practice") + "</h3>" +
            '<span class="badge">' + pool.length + " " + t("test.questions") + "</span></div>" +
            pool.map(function (q, i) {
              return '<div class="card q-card" data-practice="' + q.id + '">' +
                '<span class="q-index">' + t("test.question") + " " + (i + 1) + "</span>" +
                '<p class="q-text">' + U.esc(q.promptUz) + "</p>" +
                (q.ar ? '<p class="q-text ar">' + q.ar + "</p>" : "") +
                q.opts.map((o, oi) => '<button class="opt' + (q.optsAr ? " ar-opt" : "") + '" data-opt="' + oi + '">' +
                  '<span class="key">' + String.fromCharCode(65 + oi) + '</span><span class="otext">' + (q.optsAr ? o : U.esc(o)) + "</span></button>").join("") +
                '<div class="q-explain" hidden></div></div>';
            }).join("") +
            '<a class="btn btn-primary btn-block" href="#/test/darajaviy-' + course.id + '-placement">' + t("test.start") + "</a></div>";

          U.$$("[data-practice]", host).forEach(function (card) {
            const q = TLA.data.questionById(card.dataset.practice);
            const explain = card.querySelector(".q-explain");
            U.$$(".opt", card).forEach(function (btn) {
              btn.addEventListener("click", function () {
                if (card.dataset.answered) return;
                card.dataset.answered = "1";
                const chosen = Number(btn.dataset.opt);
                U.$$(".opt", card).forEach(function (b, bi) {
                  b.disabled = true;
                  if (bi === q.ans) b.classList.add("is-correct");
                  else if (bi === chosen) b.classList.add("is-wrong");
                });
                explain.hidden = false;
                explain.innerHTML = "<strong>" + (chosen === q.ans ? t("test.correct") : t("test.wrong")) + ".</strong> " + U.esc(q.expUz);
                if (chosen === q.ans) TLA.state.addXp(2, "practice");
              });
            });
          });
        }

        TLA.ui.reveal(host);
      }

      U.$$("[data-tab]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          U.$$("[data-tab]").forEach(b => b.setAttribute("aria-selected", "false"));
          btn.setAttribute("aria-selected", "true");
          renderPanel(btn.dataset.tab);
        });
      });

      host.addEventListener("click", function (ev) {
        const fontBtn = ev.target.closest("[data-font]");
        if (fontBtn) {
          const reader = U.$("#readerText");
          if (reader) reader.style.setProperty("--reader-scale", fontBtn.dataset.font);
          return;
        }
        if (ev.target.id === "toggleTr") {
          const tr = U.$("#readerTr");
          if (tr) tr.hidden = !tr.hidden;
        }
      });

      const doneBtn = U.$("#lessonDone");
      if (doneBtn) {
        doneBtn.addEventListener("click", function () {
          TLA.state.completeLesson(lesson.id, lesson.minutes);
          doneBtn.disabled = true;
          doneBtn.className = "btn btn-ghost";
          doneBtn.textContent = "✓ " + t("lesson.completed");
          TLA.ui.toast(t("misc.xpEarned", { n: 10 }), "xp");
          TLA.ui.renderHeader();
        });
      }

      renderPanel("lesson");
    },

    meta: function (params) {
      const f = TLA.data.lessonById(params.id);
      return f ? { title: f.lesson.titleUz + " — " + f.course.titleUz, desc: f.module.titleUz } : null;
    }
  };
})();
