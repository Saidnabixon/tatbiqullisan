/* ============================================================
   PAGE — Test result
   Full analytics for signed-in users; a partial result plus a
   registration gate for guests (value first, sign-up second).
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  function skillRows(attempt) {
    return Object.keys(attempt.skillScores).map(function (s) {
      const value = attempt.skillScores[s];
      const lvl = (attempt.skillLevels || {})[s];
      const tone = value >= 80 ? "jade" : value >= 60 ? "" : "gold";
      return '<div class="skill-row">' +
        '<span class="sn">' + t("misc.skill." + s) + "</span>" +
        '<span class="progress ' + tone + '"><span style="width:' + value + '%"></span></span>' +
        '<span class="sv">' + value + "%" + (lvl ? " · " + lvl.toUpperCase() : "") + "</span></div>";
    }).join("");
  }

  function reviewMarkup(attempt) {
    return attempt.detail.map(function (d, i) {
      const q = TLA.data.questionById(d.ref);
      if (!q) return "";
      const options = (d.optOrder || q.opts.map((_, oi) => oi)).map(function (origIdx, pos) {
        const isCorrect = pos === d.correctPos;
        const isGiven = pos === d.given;
        const cls = isCorrect ? " is-correct" : (isGiven ? " is-wrong" : "");
        return '<div class="opt' + (q.optsAr ? " ar-opt" : "") + cls + '" style="cursor:default">' +
          '<span class="key">' + String.fromCharCode(65 + pos) + "</span>" +
          '<span class="otext">' + (q.optsAr ? q.opts[origIdx] : U.esc(q.opts[origIdx])) + "</span>" +
          (isGiven ? '<span class="badge badge-outline">' + t("test.yourAnswer") + "</span>" : "") +
          "</div>";
      }).join("");

      return '<details class="acc"><summary>' +
        '<span class="row" style="gap:var(--sp-3);min-width:0">' +
        '<span class="badge ' + (d.ok ? "badge-jade" : "badge-red") + '">' + (i + 1) + "</span>" +
        '<span style="overflow:hidden;text-overflow:ellipsis">' + U.esc(q.promptUz || q.ar) + "</span></span>" +
        "</summary>" +
        '<div class="acc-body">' +
        (q.ar ? '<p class="ar ar-lg" style="margin-bottom:var(--sp-3)">' + q.ar + "</p>" : "") +
        options +
        '<div class="q-explain" style="margin-top:var(--sp-4)"><strong>' + t("test.explanation") + ":</strong> " +
        U.esc(q.expUz) + "</div></div></details>";
    }).join("");
  }

  TLA.pages.result = {
    render: function (params) {
      const attempt = TLA.state.attemptById(params.id);
      if (!attempt) {
        return TLA.ui.pageHead({ title: t("error.notFound"), lead: t("error.notFoundD") }) +
          '<section class="section"><div class="container container-narrow">' +
          TLA.ui.emptyState("◔", t("empty.tests"), t("empty.searchD"),
            '<a class="btn btn-primary" href="#/tests">' + t("nav.tests") + "</a>") + "</div></section>";
      }

      const authed = TLA.state.isAuthed();
      const gated = !authed;
      const series = Object.keys(attempt.skillScores).map(s => ({
        label: t("misc.skill." + s), value: attempt.skillScores[s]
      }));
      const sg = TLA.engine.strengthsAndGaps(attempt.skillScores);
      const recs = TLA.engine.recommend({ skillScores: attempt.skillScores, level: attempt.level });
      const plan = TLA.engine.planSentence(attempt.skillScores, attempt.level);

      const hero = '<div class="score-hero" data-reveal>' +
        '<div class="score-ring">' + TLA.charts.donut(attempt.score, { size: 168 }) +
        '<div class="val"><span>' + attempt.score + "%</span></div></div>" +
        "<div>" +
        '<span class="eyebrow" style="color:var(--gold-300)">' + U.esc(attempt.titleUz) + "</span>" +
        '<h1 style="color:var(--ivory);margin:var(--sp-3) 0">' + t("result.title") + "</h1>" +
        '<div class="row row-wrap" style="gap:var(--sp-5);align-items:center">' +
        '<div class="level-badge"><span class="lv">' + String(attempt.level).toUpperCase() + "</span>" +
        '<span class="lb">' + t("result.estimated") + "</span></div>" +
        '<div class="stack-sm">' +
        '<div><span class="muted" style="font-size:var(--fs-2xs)">' + t("result.correctCount") + '</span><br><strong style="color:var(--ivory);font-size:var(--fs-lg)">' +
        attempt.correct + " / " + attempt.total + "</strong></div>" +
        '<div><span class="muted" style="font-size:var(--fs-2xs)">' + t("result.timeSpent") + '</span><br><strong style="color:var(--ivory);font-size:var(--fs-lg)">' +
        U.fmtTime(attempt.seconds) + "</strong></div>" +
        "</div>" +
        '<div class="stack-sm">' +
        '<div><span class="muted" style="font-size:var(--fs-2xs)">' + t("dash.xp") + '</span><br><strong style="color:var(--gold-300);font-size:var(--fs-lg)">+' +
        attempt.xp + " XP</strong></div>" +
        '<div><span class="muted" style="font-size:var(--fs-2xs)">' + t("misc.date") + '</span><br><strong style="color:var(--ivory);font-size:var(--fs-sm)">' +
        U.fmtDate(attempt.at, TLA.i18n.get()) + "</strong></div>" +
        "</div></div>" +
        (attempt.auto ? '<p class="muted" style="margin-top:var(--sp-4);font-size:var(--fs-2xs)">' + t("test.timeUp") + "</p>" : "") +
        "</div></div>";

      const analysis = '<div class="grid grid-2" style="margin-top:var(--sp-6)">' +
        '<div class="card" data-reveal><h3>' + t("result.breakdown") + "</h3>" +
        '<div style="margin:var(--sp-5) 0">' + TLA.charts.shamsa(series, { aria: t("result.breakdown") }) + "</div>" +
        skillRows(attempt) + "</div>" +
        '<div class="stack-lg">' +
        '<div class="card" data-reveal><h3>' + t("result.strengths") + "</h3>" +
        '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
        (sg.strengths.length
          ? sg.strengths.map(s => '<div class="row" style="gap:var(--sp-3)"><span style="color:var(--success)">✓</span>' +
            "<span>" + t("misc.skill." + s.skill) + ' — <b>' + s.score + "%</b></span></div>").join("")
          : '<p class="muted" style="font-size:var(--fs-sm)">Barcha ko‘nikmalar bo‘yicha ball 70% dan past — asosiy e’tiborni takrorlashga qarating.</p>') +
        "</div>" +
        '<div class="rule-gold" style="margin:var(--sp-5) 0"></div>' +
        "<h3>" + t("result.improve") + "</h3>" +
        '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
        (sg.gaps.length
          ? sg.gaps.map(s => '<div class="row" style="gap:var(--sp-3)"><span style="color:var(--warn)">⚠</span>' +
            "<span>" + t("misc.skill." + s.skill) + " — <b>" + s.score + "%</b></span></div>").join("")
          : '<p class="muted" style="font-size:var(--fs-sm)">Barcha ko‘nikmalar 75% dan yuqori — keyingi darajaga o‘tishingiz mumkin.</p>') +
        "</div></div>" +
        '<div class="card card-dark" data-reveal><h3 style="color:var(--ivory)">Tavsiya etilgan yo‘l</h3>' +
        '<p class="muted" style="margin-top:var(--sp-3);line-height:1.7">' + U.esc(plan) + "</p></div>" +
        "</div></div>";

      const recommendations = '<div class="card" style="margin-top:var(--sp-6)" data-reveal>' +
        '<div class="row-between" style="margin-bottom:var(--sp-4)"><h3>' + t("result.recommended") + "</h3>" +
        '<a class="btn btn-quiet btn-sm" href="#/dashboard">' + t("nav.dashboard") + " →</a></div>" +
        '<div class="rec-list">' +
        recs.map(r => '<a class="rec-item" href="' + r.href + '">' +
          '<span style="flex:1"><strong style="font-size:var(--fs-sm)">' + U.esc(r.titleUz) + "</strong><br>" +
          '<span class="muted" style="font-size:var(--fs-2xs)">' + U.esc(r.metaUz) + "</span></span>" +
          '<span class="arw">→</span></a>').join("") +
        "</div>" +
        '<div class="row row-wrap" style="margin-top:var(--sp-5);gap:var(--sp-3)">' +
        '<a class="btn btn-primary btn-arrow" href="' + (recs[0] ? recs[0].href : "#/learn") + '">' +
        t("result.startPractice") + ' <span class="arw">→</span></a>' +
        '<a class="btn btn-ghost" href="#/test/' + attempt.testId + '">' + t("result.again") + "</a>" +
        "</div></div>";

      const review = '<div class="card" style="margin-top:var(--sp-6)" data-reveal>' +
        '<div class="row-between" style="margin-bottom:var(--sp-4)"><h3>' + t("test.review") + "</h3>" +
        '<span class="badge">' + attempt.correct + "/" + attempt.total + "</span></div>" +
        reviewMarkup(attempt) + "</div>";

      const gate = '<div class="gate-overlay"><div class="card gate-card card-illum">' +
        '<span class="eyebrow">' + t("result.gateTitle") + "</span>" +
        '<h3 style="margin:var(--sp-3) 0">' + t("result.gateTitle") + "</h3>" +
        '<p class="muted" style="font-size:var(--fs-sm)">' + t("result.gateBody") + "</p>" +
        '<div class="stack-sm" style="margin-top:var(--sp-5)">' +
        '<button class="btn btn-primary btn-block btn-lg" data-action="auth-register">' + t("result.gateCta") + "</button>" +
        '<button class="btn btn-ghost btn-block" data-action="auth-login">' + t("action.login") + "</button>" +
        "</div>" +
        '<p class="muted" style="font-size:var(--fs-3xs);margin-top:var(--sp-4)">' + t("auth.demoNote") + "</p>" +
        "</div></div>";

      return '<section class="section"><div class="container">' +
        hero +
        (gated
          ? '<div class="gate-blur" style="margin-top:var(--sp-6)">' +
            '<div class="locked-layer">' + analysis + recommendations + "</div>" + gate + "</div>"
          : analysis + recommendations + review) +
        '<div style="margin-top:var(--sp-6)">' +
        TLA.ui.complianceNote(t("diag.note")) + "</div>" +
        "</div></section>";
    },

    mounted: function () {
      const p = TLA.state.profile();
      if (TLA.state.isAuthed() && p.level) TLA.ui.renderHeader();
    },

    meta: { title: "Test natijasi — Tatbiqul Lisan Academy", desc: "Ko‘nikmalar bo‘yicha batafsil natija va shaxsiy tavsiyalar." }
  };
})();
