/* ============================================================
   UI — shell chrome and shared components
   ============================================================ */
window.TLA = window.TLA || {};

TLA.ui = (function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  let lastFocus = null;

  /* ---------------- Theme, language, motion ---------------- */
  function applySettings() {
    const s = TLA.state.settings();
    document.documentElement.setAttribute("data-theme", s.theme);
    document.documentElement.setAttribute("data-motion", s.motion === "off" ? "off" : "on");
    document.documentElement.style.setProperty("--font-scale", s.fontScale || 1);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", s.theme === "dark" ? "#061321" : "#f7f5f0");
  }

  function toggleTheme() {
    const s = TLA.state.settings();
    TLA.state.setSetting("theme", s.theme === "dark" ? "light" : "dark");
    applySettings();
    renderHeader();
  }

  function setLang(lang) {
    TLA.state.setSetting("lang", lang);
    TLA.i18n.set(lang);
    renderShell();
    if (TLA.router) TLA.router.rerender();
  }

  /* ---------------- Toast ---------------- */
  function toast(message, kind) {
    const wrap = U.$("#toastWrap");
    if (!wrap) return;
    const el = document.createElement("div");
    el.className = "toast toast-" + (kind || "info");
    el.setAttribute("role", "status");
    const icon = kind === "success" ? "✓" : kind === "error" ? "!" : kind === "xp" ? "✦" : "•";
    el.innerHTML = '<span class="ico">' + icon + "</span><span>" + U.esc(message) + "</span>";
    wrap.appendChild(el);
    setTimeout(function () {
      el.classList.add("out");
      setTimeout(() => el.remove(), 260);
    }, 3200);
  }

  /* ---------------- Modal ---------------- */
  function modal(html, opts) {
    const o = opts || {};
    const root = U.$("#modalRoot");
    lastFocus = document.activeElement;
    root.innerHTML =
      '<div class="modal-backdrop" data-action="modal-close"></div>' +
      '<div class="modal ' + (o.wide ? "modal-lg" : "") + '" role="dialog" aria-modal="true" ' +
      (o.label ? 'aria-label="' + U.attr(o.label) + '"' : "") + ">" +
      '<button class="modal-close" data-action="modal-close" aria-label="' + U.attr(t("action.close")) + '">✕</button>' +
      html + "</div>";
    root.hidden = false;
    document.body.classList.add("is-locked");
    const focusable = root.querySelector("input, select, textarea, button:not(.modal-close), a[href]");
    if (focusable) setTimeout(() => focusable.focus(), 60);
    return root;
  }

  function closeModal() {
    const root = U.$("#modalRoot");
    if (!root || root.hidden) return;
    root.hidden = true;
    root.innerHTML = "";
    document.body.classList.remove("is-locked");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  function confirmDialog(title, body, confirmLabel, onConfirm, danger) {
    modal(
      "<h3>" + U.esc(title) + "</h3>" +
      '<p class="muted" style="margin-bottom:var(--sp-6)">' + U.esc(body) + "</p>" +
      '<div class="row" style="justify-content:flex-end;gap:var(--sp-3)">' +
      '<button class="btn btn-ghost" data-action="modal-close">' + t("action.cancel") + "</button>" +
      '<button class="btn ' + (danger ? "btn-danger" : "btn-primary") + '" id="confirmYes">' + U.esc(confirmLabel) + "</button>" +
      "</div>",
      { label: title }
    );
    U.$("#confirmYes").addEventListener("click", function () {
      closeModal();
      onConfirm();
    });
  }

  /* ---------------- Header ---------------- */
  const LEVEL_LINKS = TLA.data.levels.map(l => ({ href: "#/learn/" + l.id, t: l.code + " — " + l.uz, s: l.descUz }));

  function navMarkup() {
    const path = location.hash || "#/";
    function active(prefix) { return path.indexOf(prefix) === 0 ? " is-active" : ""; }

    const examLinks = [
      { href: "#/exams/multilevel", t: t("exam.multilevel"), s: "Bo‘limlar + to‘liq mock" },
      { href: "#/exams/tanal", t: t("exam.tanal"), s: "Tayyorgarlik materiallari" },
      { href: "#/exams/darajaviy", t: t("exam.darajaviy"), s: "A1–C2 test to‘plamlari" }
    ];
    const mockLinks = [
      { href: "#/test/diagnostic", t: "Diagnostika", s: "20 savol · bepul" },
      { href: "#/tests?skill=reading", t: t("misc.skill.reading"), s: "Matn asosidagi testlar" },
      { href: "#/tests?skill=listening", t: t("misc.skill.listening"), s: "Audio mashqlar" },
      { href: "#/tests?skill=grammar", t: t("misc.skill.grammar"), s: "Qoidalar bo‘yicha" },
      { href: "#/tests?skill=vocabulary", t: t("misc.skill.vocabulary"), s: "So‘z boyligi" },
      { href: "#/tests?kind=mock", t: "To‘liq mock", s: "Vaqt cheklovli imtihon" }
    ];

    function mega(links, cols) {
      return '<div class="mega" hidden><div class="mega-grid ' + (cols === 2 ? "cols-2" : "") + '">' +
        links.map(l => '<a class="mega-link" href="' + l.href + '"><span><span class="mt">' + U.esc(l.t) +
          '</span><br><span class="ms">' + U.esc(l.s) + "</span></span></a>").join("") +
        "</div></div>";
    }

    return '<nav class="nav-primary" aria-label="' + U.attr(t("nav.home")) + '">' +
      '<div class="nav-item"><a class="nav-link' + (path === "#/" || path === "" ? " is-active" : "") + '" href="#/">' + t("nav.home") + "</a></div>" +
      '<div class="nav-item" data-dropdown><button class="nav-link' + active("#/learn") + '" aria-expanded="false" aria-haspopup="true">' +
      t("nav.learn") + '<span class="caret">▾</span></button>' + mega(LEVEL_LINKS, 2) + "</div>" +
      '<div class="nav-item" data-dropdown><button class="nav-link' + active("#/exams") + '" aria-expanded="false" aria-haspopup="true">' +
      t("nav.exams") + '<span class="caret">▾</span></button>' + mega(examLinks) + "</div>" +
      '<div class="nav-item" data-dropdown><button class="nav-link' + active("#/tests") + '" aria-expanded="false" aria-haspopup="true">' +
      t("nav.mock") + '<span class="caret">▾</span></button>' + mega(mockLinks, 2) + "</div>" +
      '<div class="nav-item"><a class="nav-link' + active("#/library") + '" href="#/library">' + t("nav.library") + "</a></div>" +
      '<div class="nav-item"><a class="nav-link' + active("#/blog") + '" href="#/blog">' + t("nav.blog") + "</a></div>" +
      "</nav>";
  }

  function renderHeader() {
    const host = U.$("#siteHeader");
    if (!host) return;
    const authed = TLA.state.isAuthed();
    const user = TLA.state.currentUser();
    const s = TLA.state.settings();
    const unread = TLA.state.unreadCount();
    const xp = TLA.state.profile().xp || 0;

    host.innerHTML =
      '<div class="container header-inner">' +
      '<a class="logo" href="#/" aria-label="' + U.attr(t("brand.name")) + '">' +
      '<span class="logo-mark"><span>ت</span></span>' +
      '<span class="logo-text"><span class="t1">Tatbiqul Lisan</span><span class="t2">Academy</span></span></a>' +
      navMarkup() +
      '<div class="header-actions">' +
      (authed ? '<span class="xp-pill desktop-only tip" data-tip="XP">✦ ' + U.fmtNumber(xp) + "</span>" : "") +
      '<button class="icon-btn" data-action="search-open" aria-label="' + U.attr(t("nav.search")) + '" title="⌘K">' +
      '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></button>' +
      '<button class="icon-btn" data-action="theme" aria-label="' + U.attr(t("profile.theme")) + '">' +
      (s.theme === "dark"
        ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/></svg>'
        : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>') +
      "</button>" +
      '<div class="lang-switch desktop-only"><button class="lang-btn" data-action="lang-menu" aria-haspopup="true" aria-expanded="false">' +
      TLA.i18n.get().toUpperCase() + '<span class="caret">▾</span></button>' +
      '<div class="menu" hidden id="langMenu">' +
      TLA.i18n.available().map(function (l) {
        const names = { uz: "O‘zbekcha", en: "English", ar: "العربية" };
        return '<button class="menu-item" data-action="set-lang" data-lang="' + l + '">' +
          '<span class="mono">' + l.toUpperCase() + "</span><span>" + names[l] + "</span></button>";
      }).join("") + "</div></div>" +
      (authed
        ? '<button class="icon-btn desktop-only" data-action="notif" aria-label="' + U.attr(t("profile.notifications")) + '">' +
          '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 1 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>' +
          (unread ? '<span class="dot"></span>' : "") + "</button>" +
          '<div class="nav-item desktop-only" data-dropdown style="position:relative">' +
          '<button class="avatar" aria-label="' + U.attr(user.name) + '" aria-expanded="false">' + U.esc(U.initials(user.name)) + "</button>" +
          '<div class="menu" hidden>' +
          '<div class="menu-label">' + U.esc(user.name) + "</div>" +
          '<a class="menu-item" href="#/dashboard">◈ ' + t("nav.dashboard") + "</a>" +
          '<a class="menu-item" href="#/progress">◉ ' + t("nav.progress") + "</a>" +
          '<a class="menu-item" href="#/certificates">✦ ' + t("nav.certificates") + "</a>" +
          '<a class="menu-item" href="#/profile">☰ ' + t("nav.profile") + "</a>" +
          (TLA.state.isAdmin() ? '<a class="menu-item" href="#/admin">⚙ ' + t("nav.admin") + "</a>" : "") +
          '<div class="menu-sep"></div>' +
          '<button class="menu-item danger" data-action="logout">⏻ ' + t("action.logout") + "</button>" +
          "</div></div>"
        : '<button class="btn btn-quiet desktop-only" data-action="auth-login">' + t("action.login") + "</button>" +
          '<button class="btn btn-primary btn-sm desktop-only" data-action="auth-register">' + t("action.register") + "</button>") +
      '<button class="icon-btn burger" data-action="drawer-open" aria-label="Menu">' +
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg></button>' +
      "</div></div>";
  }

  /* ---------------- Drawer ---------------- */
  function openDrawer() {
    const root = U.$("#drawerRoot");
    const authed = TLA.state.isAuthed();
    const user = TLA.state.currentUser();

    const group = (label, links, id) =>
      '<button data-action="drawer-group" data-target="' + id + '">' + U.esc(label) + '<span class="caret">▾</span></button>' +
      '<div class="drawer-sub" id="' + id + '" hidden>' +
      links.map(l => '<a href="' + l.href + '" data-action="drawer-close">' + U.esc(l.t) + "</a>").join("") + "</div>";

    root.innerHTML =
      '<div class="drawer-backdrop" data-action="drawer-close"></div>' +
      '<aside class="drawer" role="dialog" aria-modal="true" aria-label="Menu">' +
      '<div class="drawer-head">' +
      (authed
        ? '<div class="row"><span class="avatar">' + U.esc(U.initials(user.name)) + '</span><div><div class="strong">' +
          U.esc(user.name) + '</div><div class="muted" style="font-size:var(--fs-2xs)">✦ ' + U.fmtNumber(TLA.state.profile().xp) + " XP</div></div></div>"
        : '<span class="logo"><span class="logo-mark"><span>ت</span></span></span>') +
      '<button class="icon-btn" data-action="drawer-close" aria-label="' + U.attr(t("action.close")) + '">✕</button></div>' +
      '<nav class="drawer-nav">' +
      '<a href="#/" data-action="drawer-close">' + t("nav.home") + "</a>" +
      group(t("nav.learn"), LEVEL_LINKS, "dgLearn") +
      group(t("nav.exams"), [
        { href: "#/exams/multilevel", t: t("exam.multilevel") },
        { href: "#/exams/tanal", t: t("exam.tanal") },
        { href: "#/exams/darajaviy", t: t("exam.darajaviy") }
      ], "dgExams") +
      '<a href="#/tests" data-action="drawer-close">' + t("nav.mock") + "</a>" +
      '<a href="#/library" data-action="drawer-close">' + t("nav.library") + "</a>" +
      '<a href="#/dictionary" data-action="drawer-close">' + t("nav.dictionary") + "</a>" +
      '<a href="#/blog" data-action="drawer-close">' + t("nav.blog") + "</a>" +
      '<a href="#/pricing" data-action="drawer-close">' + t("nav.pricing") + "</a>" +
      '<a href="#/free" data-action="drawer-close">' + t("nav.free") + "</a>" +
      '<a href="#/certificates" data-action="drawer-close">' + t("nav.certificates") + "</a>" +
      '<a href="#/about" data-action="drawer-close">' + t("nav.about") + "</a>" +
      '<a href="#/contact" data-action="drawer-close">' + t("nav.contact") + "</a>" +
      (TLA.state.isAdmin() ? '<a href="#/admin" data-action="drawer-close">' + t("nav.admin") + "</a>" : "") +
      "</nav>" +
      '<div class="rule-gold"></div>' +
      '<div class="row" style="gap:var(--sp-2)">' +
      TLA.i18n.available().map(l => '<button class="chip" data-action="set-lang" data-lang="' + l + '"' +
        (TLA.i18n.get() === l ? ' aria-pressed="true"' : "") + ">" + l.toUpperCase() + "</button>").join("") +
      "</div>" +
      (authed
        ? '<button class="btn btn-ghost btn-block" data-action="logout">' + t("action.logout") + "</button>"
        : '<div class="stack-sm"><button class="btn btn-primary btn-block" data-action="auth-register">' + t("action.register") + "</button>" +
          '<button class="btn btn-ghost btn-block" data-action="auth-login">' + t("action.login") + "</button></div>") +
      "</aside>";
    root.hidden = false;
    document.body.classList.add("is-locked");
  }

  function closeDrawer() {
    const root = U.$("#drawerRoot");
    if (!root || root.hidden) return;
    root.hidden = true;
    root.innerHTML = "";
    document.body.classList.remove("is-locked");
  }

  /* ---------------- Bottom navigation ---------------- */
  function renderBottomNav() {
    const host = U.$("#bottomNav");
    if (!host) return;
    const path = location.hash || "#/";
    const items = [
      { href: "#/", icon: "◈", label: t("nav.home"), match: p => p === "#/" || p === "" },
      { href: "#/learn", icon: "❖", label: t("nav.learn"), match: p => p.indexOf("#/learn") === 0 || p.indexOf("#/lesson") === 0 },
      { href: "#/tests", icon: "◉", label: t("nav.tests"), match: p => p.indexOf("#/test") === 0 || p.indexOf("#/exams") === 0 },
      { href: "#/progress", icon: "◑", label: t("nav.progress"), match: p => p.indexOf("#/progress") === 0 || p.indexOf("#/dashboard") === 0 },
      { href: TLA.state.isAuthed() ? "#/profile" : "#/dashboard", icon: "◐", label: t("nav.profile"), match: p => p.indexOf("#/profile") === 0 }
    ];
    host.innerHTML = "<ul>" + items.map(function (i) {
      return '<li><a href="' + i.href + '" class="' + (i.match(path) ? "is-active" : "") + '">' +
        '<span class="bi" aria-hidden="true">' + i.icon + '</span><span>' + U.esc(i.label) + "</span></a></li>";
    }).join("") + "</ul>";
  }

  /* ---------------- Footer ---------------- */
  function renderFooter() {
    const host = U.$("#siteFooter");
    if (!host) return;
    const cfg = TLA.state.config();
    const social = [
      { key: "telegram", label: "Telegram", glyph: "✈" },
      { key: "instagram", label: "Instagram", glyph: "◎" },
      { key: "youtube", label: "YouTube", glyph: "▶" }
    ];

    host.innerHTML = '<div class="container">' +
      '<div class="footer-top">' +
      '<div class="footer-brand">' +
      '<span class="logo"><span class="logo-mark"><span>ت</span></span>' +
      '<span class="logo-text"><span class="t1">Tatbiqul Lisan</span><span class="t2">Academy</span></span></span>' +
      '<p class="ar-motto">تعلّم العربية، طوّر مستواك، وحقق هدفك</p>' +
      "<p>" + t("brand.motto") + "</p>" +
      '<div class="footer-social">' +
      social.map(s => '<a href="' + (cfg.social[s.key] || "#/contact") + '" aria-label="' + s.label +
        '" title="' + s.label + '"' + (cfg.social[s.key] ? ' target="_blank" rel="noopener"' : "") + ">" + s.glyph + "</a>").join("") +
      "</div>" +
      '<p style="font-size:var(--fs-3xs);opacity:.65;margin-top:var(--sp-3)">' + t("footer.socialNote") + "</p>" +
      "</div>" +
      '<div class="footer-col"><h5>' + t("footer.product") + "</h5>" +
      '<a href="#/learn">' + t("nav.learn") + "</a>" +
      '<a href="#/exams/multilevel">' + t("nav.exams") + "</a>" +
      '<a href="#/tests">' + t("nav.mock") + "</a>" +
      '<a href="#/pricing">' + t("nav.pricing") + "</a>" +
      '<a href="#/certificates">' + t("nav.certificates") + "</a></div>" +
      '<div class="footer-col"><h5>' + t("footer.learnSec") + "</h5>" +
      '<a href="#/library">' + t("nav.library") + "</a>" +
      '<a href="#/dictionary">' + t("nav.dictionary") + "</a>" +
      '<a href="#/free">' + t("nav.free") + "</a>" +
      '<a href="#/blog">' + t("nav.blog") + "</a>" +
      '<a href="#/teachers">' + t("nav.teachers") + "</a></div>" +
      '<div class="footer-col"><h5>' + t("footer.legal") + "</h5>" +
      '<a href="#/about">' + t("nav.about") + "</a>" +
      '<a href="#/contact">' + t("nav.contact") + "</a>" +
      '<a href="#/legal/privacy">' + t("footer.privacy") + "</a>" +
      '<a href="#/legal/terms">' + t("footer.terms") + "</a>" +
      '<a href="#/legal/refund">' + t("footer.refund") + "</a>" +
      '<a href="#/legal/offer">' + t("footer.offer") + "</a></div>" +
      "</div>" +
      '<div class="footer-bottom"><span>© ' + new Date().getFullYear() + " Tatbiqul Lisan Academy. " + t("footer.rights") + "</span>" +
      '<span class="links"><a href="#/verify">' + t("cert.verify") + '</a><a href="#/contact">' + t("nav.contact") + "</a></span></div>" +
      "</div>";
  }

  function renderShell() {
    renderHeader();
    renderFooter();
    renderBottomNav();
  }

  /* ---------------- Auth ---------------- */
  function openAuth(mode) {
    const isLogin = mode === "login";
    modal(
      '<div class="text-center" style="margin-bottom:var(--sp-5)">' +
      '<span class="logo-mark" style="margin:0 auto var(--sp-3)"><span>ت</span></span>' +
      "<h3>" + (isLogin ? t("auth.loginTitle") : t("auth.registerTitle")) + "</h3>" +
      '<p class="muted" style="font-size:var(--fs-sm)">' + (isLogin ? "" : t("result.gateBody")) + "</p></div>" +
      '<form id="authForm" novalidate>' +
      (isLogin ? "" :
        '<label class="field"><span class="label">' + t("auth.name") + '</span>' +
        '<input class="input" name="name" autocomplete="name" required><span class="field-msg" data-for="name"></span></label>') +
      '<label class="field"><span class="label">' + t("auth.email") + '</span>' +
      '<input class="input" name="email" type="email" autocomplete="email" required><span class="field-msg" data-for="email"></span></label>' +
      '<label class="field"><span class="label">' + t("auth.password") + '</span>' +
      '<input class="input" name="password" type="password" autocomplete="' + (isLogin ? "current-password" : "new-password") + '" required>' +
      '<span class="field-hint">' + t("auth.passwordHint") + '</span><span class="field-msg" data-for="password"></span></label>' +
      (isLogin ? "" :
        '<label class="check" style="margin-top:var(--sp-4)"><input type="checkbox" name="agree">' +
        "<span>" + t("auth.agree") + "</span></label><span class='field-msg' data-for='agree'></span>") +
      '<button class="btn btn-primary btn-block btn-lg" type="submit" style="margin-top:var(--sp-5)">' +
      (isLogin ? t("action.login") : t("action.register")) + "</button>" +
      "</form>" +
      '<div class="divider-or" style="margin:var(--sp-5) 0">' + t("misc.total") + "</div>" +
      '<button class="btn btn-ghost btn-block" data-action="telegram-auth">✈ ' + t("auth.telegram") + "</button>" +
      '<p class="muted text-center" style="font-size:var(--fs-2xs);margin-top:var(--sp-4)">' + t("auth.demoNote") + "</p>" +
      '<p class="text-center" style="margin-top:var(--sp-4);font-size:var(--fs-sm)">' +
      (isLogin ? t("auth.noAccount") + ' <button class="btn btn-quiet" data-action="auth-register">' + t("action.register") + "</button>"
        : t("auth.haveAccount") + ' <button class="btn btn-quiet" data-action="auth-login">' + t("action.login") + "</button>") +
      "</p>",
      { label: isLogin ? t("auth.loginTitle") : t("auth.registerTitle") }
    );

    const form = U.$("#authForm");
    form.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      const fd = new FormData(form);
      const name = (fd.get("name") || "").toString().trim();
      const email = (fd.get("email") || "").toString().trim();
      const password = (fd.get("password") || "").toString();
      const agree = fd.get("agree");

      U.$$(".field-msg", form).forEach(n => { n.textContent = ""; });
      U.$$(".field", form).forEach(n => n.classList.remove("field-error"));
      function fail(field, message) {
        const msg = form.querySelector('[data-for="' + field + '"]');
        if (msg) { msg.textContent = message; msg.closest(".field") && msg.closest(".field").classList.add("field-error"); }
        return false;
      }

      let ok = true;
      if (!isLogin && name.length < 2) ok = fail("name", t("auth.errName"));
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) ok = fail("email", t("auth.errEmail"));
      if (password.length < 8) ok = fail("password", t("auth.errPass"));
      if (!isLogin && !agree) ok = fail("agree", t("auth.errAgree"));
      if (!ok) return;

      // register()/login() may reach across the network now (05b-api.js) —
      // show that something is happening rather than leaving the button
      // looking inert for the round trip.
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalLabel = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = t("misc.loading");

      let res;
      try {
        res = isLogin ? await TLA.state.login(email, password) : await TLA.state.register(name, email, password);
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalLabel;
      }

      if (!res.ok) {
        if (res.error === "exists") return fail("email", "Bu email allaqachon ro‘yxatdan o‘tgan.");
        if (res.error === "rate_limited") return fail("password", "Juda ko‘p urinish. Birozdan so‘ng qayta urinib ko‘ring.");
        return fail("password", t("auth.errCreds"));
      }
      closeModal();
      renderShell();
      toast(t("auth.welcome", { name: res.user.name }), "success");
      const profile = TLA.state.profile();
      if (!isLogin && !profile.onboarded) openOnboarding();
      else if (TLA.router) TLA.router.go("#/dashboard");
    });
  }

  /* ---------------- Onboarding ---------------- */
  function openOnboarding() {
    const levels = TLA.data.levels;
    modal(
      "<h3>" + t("onb.title") + "</h3>" +
      '<p class="muted" style="margin-bottom:var(--sp-5);font-size:var(--fs-sm)">Javoblaringiz asosida bosh sahifadagi tavsiyalar shakllanadi.</p>' +
      '<form id="onbForm">' +
      '<div class="field"><span class="label">' + t("onb.goalQ") + "</span>" +
      '<div class="row row-wrap" role="radiogroup">' +
      [["exam", t("onb.goalExam")], ["learn", t("onb.goalLearn")], ["work", t("onb.goalWork")]]
        .map((g, i) => '<button type="button" class="chip" data-pick="goal" data-value="' + g[0] + '"' +
          (i === 0 ? ' aria-pressed="true"' : "") + ">" + g[1] + "</button>").join("") +
      "</div></div>" +
      '<label class="field"><span class="label">' + t("onb.targetQ") + "</span>" +
      '<select class="select" name="target">' +
      levels.map(l => '<option value="' + l.id + '"' + (l.id === "b2" ? " selected" : "") + ">" + l.code + " — " + l.uz + "</option>").join("") +
      "</select></label>" +
      '<label class="field"><span class="label">' + t("onb.timeQ") + "</span>" +
      '<select class="select" name="minutes"><option value="15">15 daqiqa</option><option value="30" selected>30 daqiqa</option>' +
      '<option value="45">45 daqiqa</option><option value="60">1 soat va undan ko‘p</option></select></label>' +
      '<label class="field"><span class="label">' + t("onb.examQ") + "</span>" +
      '<input class="input" type="date" name="examDate"></label>' +
      '<div class="row" style="margin-top:var(--sp-6);gap:var(--sp-3)">' +
      '<button type="submit" class="btn btn-primary btn-block">' + t("onb.finish") + "</button>" +
      '<button type="button" class="btn btn-ghost" data-action="modal-close">' + t("onb.skip") + "</button></div>" +
      "</form>",
      { label: t("onb.title") }
    );

    let goal = "exam";
    U.$$('[data-pick="goal"]').forEach(function (btn) {
      btn.addEventListener("click", function () {
        U.$$('[data-pick="goal"]').forEach(b => b.setAttribute("aria-pressed", "false"));
        btn.setAttribute("aria-pressed", "true");
        goal = btn.dataset.value;
      });
    });

    U.$("#onbForm").addEventListener("submit", function (ev) {
      ev.preventDefault();
      const fd = new FormData(ev.target);
      const p = TLA.state.profile();
      p.goal = goal;
      p.targetLevel = fd.get("target");
      p.dailyMinutes = Number(fd.get("minutes"));
      p.examDate = fd.get("examDate") || "";
      p.onboarded = true;
      TLA.state.addXp(0, "onboarding");
      closeModal();
      toast("Reja tayyor — kabinetga o‘tdik.", "success");
      if (TLA.router) TLA.router.go("#/dashboard");
    });
  }

  /* ---------------- Notifications panel ---------------- */
  function openNotifications() {
    const list = TLA.state.notifications();
    modal(
      "<h3>" + t("profile.notifications") + "</h3>" +
      (list.length
        ? '<div class="stack-sm" style="margin-top:var(--sp-5);max-height:52vh;overflow:auto">' +
          list.map(n => '<div class="card card-pad-sm card-flat" style="background:var(--surface-2)">' +
            '<div class="row-between"><strong style="font-size:var(--fs-sm)">' + U.esc(n.title) + "</strong>" +
            '<span class="muted" style="font-size:var(--fs-3xs)">' + U.fmtDate(n.at, TLA.i18n.get()) + "</span></div>" +
            '<p class="muted" style="font-size:var(--fs-2xs);margin-top:4px">' + U.esc(n.body) + "</p></div>").join("") +
          "</div>"
        : '<div class="empty" style="margin-top:var(--sp-5)"><div class="glyph">◔</div><h4>' + t("empty.notifications") +
          '</h4><p>Yangi darslar, test eslatmalari va sertifikatlar shu yerda ko‘rinadi.</p></div>') +
      '<div class="row" style="margin-top:var(--sp-5);justify-content:space-between">' +
      '<a class="btn btn-quiet" href="#/profile" data-action="modal-close">' + t("profile.notifications") + " — " + t("action.edit") + "</a>" +
      '<button class="btn btn-ghost btn-sm" data-action="notif-read">' + t("action.save") + "</button></div>",
      { label: t("profile.notifications") }
    );
  }

  /* ---------------- Global search ---------------- */
  function searchIndex() {
    const idx = [];
    TLA.data.courses.forEach(c => idx.push({
      group: t("nav.learn"), title: c.titleUz, sub: c.descUz, href: "#/learn/" + c.id, key: c.titleUz + " " + c.code + " " + c.descUz
    }));
    TLA.data.allLessons().forEach(function (l) {
      idx.push({
        group: t("lesson.tabs.lesson"), title: l.lesson.titleUz, sub: l.course.code + " · " + l.module.titleUz,
        href: "#/lesson/" + l.lesson.id, key: l.lesson.titleUz + " " + l.lesson.titleAr + " " + l.module.titleUz
      });
    });
    TLA.data.tests.forEach(t2 => idx.push({
      group: t("nav.tests"), title: t2.titleUz, sub: t2.count + " savol · " + t2.minutes + " daqiqa",
      href: "#/test/" + t2.id, key: t2.titleUz + " " + t2.titleAr + " " + t2.track
    }));
    TLA.data.library.forEach(r => idx.push({
      group: t("nav.library"), title: r.titleUz, sub: r.descUz, href: "#/library?open=" + r.id,
      key: r.titleUz + " " + r.titleAr + " " + r.descUz
    }));
    TLA.data.blog.forEach(b => idx.push({
      group: t("nav.blog"), title: b.titleUz, sub: b.excerptUz, href: "#/blog/" + b.slug, key: b.titleUz + " " + b.excerptUz + " " + b.cat
    }));
    TLA.data.dictionary.forEach(d => idx.push({
      group: t("nav.dictionary"), title: d.ar + " — " + d.uz, sub: d.tr + " · " + d.level.toUpperCase(),
      href: "#/dictionary?q=" + encodeURIComponent(d.ar), key: d.ar + " " + d.uz + " " + d.tr
    }));
    return idx;
  }

  let searchCache = null;
  let cursor = 0;

  function openSearch() {
    const overlay = U.$("#searchOverlay");
    searchCache = searchCache || searchIndex();
    const recent = TLA.state.recentSearches();
    overlay.innerHTML =
      '<div class="modal-backdrop" data-action="search-close"></div>' +
      '<div class="search-panel" role="dialog" aria-modal="true" aria-label="' + U.attr(t("nav.search")) + '">' +
      '<div class="search-head search-box">' +
      '<span class="search-ico">⌕</span>' +
      '<input class="input" id="searchInput" placeholder="' + U.attr(t("search.placeholder")) + '" autocomplete="off">' +
      "</div>" +
      '<div class="search-results" id="searchResults">' +
      (recent.length
        ? '<div class="search-group"><div class="search-group-label">' + t("search.recent") + "</div>" +
          recent.map(r => '<button class="search-hit" data-recent="' + U.attr(r) + '"><span class="ht">' + U.esc(r) + "</span></button>").join("") + "</div>"
        : "") +
      "</div>" +
      '<div class="search-foot"><span><span class="kbd">↑↓</span> ' + t("search.hint") + "</span>" +
      '<span><span class="kbd">↵</span> ' + t("search.select") + "</span>" +
      '<span><span class="kbd">esc</span> ' + t("search.esc") + "</span></div></div>";
    overlay.hidden = false;
    document.body.classList.add("is-locked");

    const input = U.$("#searchInput");
    setTimeout(() => input.focus(), 50);
    input.addEventListener("input", U.debounce(function () { runSearch(input.value); }, 120));
    input.addEventListener("keydown", function (ev) {
      const hits = U.$$(".search-hit", U.$("#searchResults"));
      if (ev.key === "ArrowDown") { ev.preventDefault(); cursor = Math.min(hits.length - 1, cursor + 1); paintCursor(hits); }
      else if (ev.key === "ArrowUp") { ev.preventDefault(); cursor = Math.max(0, cursor - 1); paintCursor(hits); }
      else if (ev.key === "Enter") {
        ev.preventDefault();
        const target = hits[cursor];
        if (target) target.click();
      }
    });
    U.$("#searchResults").addEventListener("click", function (ev) {
      const recentBtn = ev.target.closest("[data-recent]");
      if (recentBtn) { input.value = recentBtn.dataset.recent; runSearch(input.value); input.focus(); }
    });
  }

  function paintCursor(hits) {
    hits.forEach((h, i) => h.classList.toggle("is-cursor", i === cursor));
    if (hits[cursor]) hits[cursor].scrollIntoView({ block: "nearest" });
  }

  function runSearch(term) {
    const host = U.$("#searchResults");
    cursor = 0;
    if (!term || term.trim().length < 2) {
      host.innerHTML = '<div class="search-group"><div class="search-group-label">' + t("search.recent") + "</div>" +
        TLA.state.recentSearches().map(r => '<button class="search-hit" data-recent="' + U.attr(r) + '"><span class="ht">' + U.esc(r) + "</span></button>").join("") +
        "</div>";
      return;
    }
    const hits = searchCache.filter(item => U.includesLoose(item.key, term)).slice(0, 24);
    if (!hits.length) {
      host.innerHTML = '<div class="empty" style="border:0;background:none"><div class="glyph">؟</div><h4>' +
        t("empty.search") + "</h4><p>" + t("empty.searchD") + "</p></div>";
      return;
    }
    const groups = U.groupBy(hits, h => h.group);
    host.innerHTML = Object.keys(groups).map(function (g) {
      return '<div class="search-group"><div class="search-group-label">' + U.esc(g) + "</div>" +
        groups[g].map(h => '<a class="search-hit" href="' + h.href + '" data-search-go="' + U.attr(term) + '">' +
          '<span><span class="ht">' + U.esc(h.title) + '</span><br><span class="hs">' + U.esc(h.sub || "") + "</span></span></a>").join("") +
        "</div>";
    }).join("");
    paintCursor(U.$$(".search-hit", host));
  }

  function closeSearch() {
    const overlay = U.$("#searchOverlay");
    if (!overlay || overlay.hidden) return;
    overlay.hidden = true;
    overlay.innerHTML = "";
    document.body.classList.remove("is-locked");
  }

  /* ---------------- Shared fragments ---------------- */
  function levelPill(code) {
    const id = String(code).toLowerCase();
    return '<span class="lvl lvl-' + id + '">' + U.esc(String(code).toUpperCase()) + "</span>";
  }

  function skillBadges(skills) {
    return skills.map(s => '<span class="badge">' + U.esc(t("misc.skill." + s)) + "</span>").join("");
  }

  function emptyState(glyph, title, body, ctaHtml) {
    return '<div class="empty"><div class="glyph">' + glyph + "</div><h4>" + U.esc(title) + "</h4><p>" +
      U.esc(body) + "</p>" + (ctaHtml || "") + "</div>";
  }

  function skeletonCards(n) {
    let out = '<div class="grid grid-3">';
    for (let i = 0; i < (n || 3); i++) out += '<div class="skel skel-card"></div>';
    return out + "</div>";
  }

  function complianceNote(text) {
    return '<p class="note-compliance"><span>⚖</span><span>' + U.esc(text) + "</span></p>";
  }

  function pageHead(opts) {
    const crumbs = (opts.crumbs || []).map(function (c, i, arr) {
      const last = i === arr.length - 1;
      return (c.href && !last ? '<a href="' + c.href + '">' + U.esc(c.label) + "</a>" : "<span>" + U.esc(c.label) + "</span>") +
        (last ? "" : '<span class="sep">/</span>');
    }).join("");
    return '<header class="page-head"><div class="container">' +
      (crumbs ? '<nav class="breadcrumbs" aria-label="breadcrumb">' + crumbs + "</nav>" : "") +
      (opts.eyebrow ? '<span class="eyebrow">' + U.esc(opts.eyebrow) + "</span>" : "") +
      "<h1>" + U.esc(opts.title) + "</h1>" +
      (opts.lead ? '<p class="lead">' + U.esc(opts.lead) + "</p>" : "") +
      (opts.extra || "") + "</div></header>";
  }

  /* ---------------- Scroll reveal ---------------- */
  let observer = null;
  function reveal(root) {
    const nodes = U.$$("[data-reveal]", root || document);
    if (!("IntersectionObserver" in window)) {
      nodes.forEach(n => n.classList.add("is-visible"));
      return;
    }
    if (!observer) {
      observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      }, { rootMargin: "0px 0px -40px 0px", threshold: 0.05 });
    }
    nodes.forEach(n => observer.observe(n));
  }

  /* ---------------- Header scroll state ---------------- */
  function bindScroll() {
    const header = U.$("#siteHeader");
    const onScroll = U.throttle(function () {
      header.classList.toggle("is-scrolled", window.scrollY > 8);
    }, 100);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* ---------------- Global delegated actions ---------------- */
  function bindGlobal() {
    document.addEventListener("click", function (ev) {
      // dropdown toggles
      const dropBtn = ev.target.closest("[data-dropdown] > button");
      if (dropBtn) {
        const item = dropBtn.parentElement;
        const menu = item.querySelector(".mega, .menu");
        const open = item.classList.contains("is-open");
        U.$$("[data-dropdown]").forEach(function (n) {
          n.classList.remove("is-open");
          const m = n.querySelector(".mega, .menu");
          if (m) m.hidden = true;
          const b = n.querySelector("button");
          if (b) b.setAttribute("aria-expanded", "false");
        });
        if (!open && menu) {
          item.classList.add("is-open");
          menu.hidden = false;
          dropBtn.setAttribute("aria-expanded", "true");
        }
        ev.stopPropagation();
        return;
      }

      const act = ev.target.closest("[data-action]");
      if (act) {
        const action = act.dataset.action;
        switch (action) {
          case "theme": toggleTheme(); return;
          case "lang-menu": {
            const menu = U.$("#langMenu");
            if (menu) {
              menu.hidden = !menu.hidden;
              act.setAttribute("aria-expanded", String(!menu.hidden));
            }
            ev.stopPropagation();
            return;
          }
          case "set-lang": setLang(act.dataset.lang); closeDrawer(); return;
          case "search-open": openSearch(); return;
          case "search-close": closeSearch(); return;
          case "drawer-open": openDrawer(); return;
          case "drawer-close": closeDrawer(); return;
          case "drawer-group": {
            const target = U.$("#" + act.dataset.target);
            if (target) target.hidden = !target.hidden;
            return;
          }
          case "modal-close": closeModal(); return;
          case "auth-login": closeDrawer(); openAuth("login"); return;
          case "auth-register": closeDrawer(); openAuth("register"); return;
          case "telegram-auth": toast(t("auth.telegramSoon"), "info"); return;
          case "logout":
            TLA.state.logout();
            closeDrawer();
            closeModal();
            renderShell();
            TLA.router.go("#/");
            toast(t("action.logout"), "info");
            return;
          case "notif": openNotifications(); return;
          case "notif-read": TLA.state.markAllRead(); closeModal(); renderHeader(); return;
          case "speak": {
            const ok = TLA.audio.speakOnce(act.dataset.text || "");
            if (!ok) toast("Bu qurilmada arabcha ovoz mavjud emas.", "info");
            return;
          }
          case "save-word": {
            const word = act.dataset.word;
            if (TLA.state.hasWord(word)) {
              TLA.state.removeWord(word);
              act.classList.remove("is-active");
              act.setAttribute("aria-pressed", "false");
              toast("So‘z ro‘yxatdan olib tashlandi.", "info");
            } else {
              TLA.state.saveWord(word);
              act.classList.add("is-active");
              act.setAttribute("aria-pressed", "true");
              toast(t("lesson.added"), "success");
            }
            return;
          }
          case "bookmark": {
            const on = TLA.state.toggleBookmark(act.dataset.id);
            act.setAttribute("aria-pressed", String(on));
            act.classList.toggle("is-active", on);
            return;
          }
          case "copy": {
            U.copyText(act.dataset.text || "").then(function () { toast(t("action.copied"), "success"); });
            return;
          }
          case "print": window.print(); return;
          case "scroll-top": U.scrollToTop(); return;
        }
      }

      // search result click bookkeeping
      const hit = ev.target.closest("[data-search-go]");
      if (hit) {
        TLA.state.addSearch(hit.dataset.searchGo);
        closeSearch();
        return;
      }

      // close open menus when clicking elsewhere
      U.$$("[data-dropdown].is-open").forEach(function (n) {
        n.classList.remove("is-open");
        const m = n.querySelector(".mega, .menu");
        if (m) m.hidden = true;
      });
      const lang = U.$("#langMenu");
      if (lang && !lang.hidden) lang.hidden = true;
    });

    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape") {
        closeSearch();
        closeModal();
        closeDrawer();
      }
      if ((ev.metaKey || ev.ctrlKey) && ev.key.toLowerCase() === "k") {
        ev.preventDefault();
        openSearch();
      }
    });

    // keep focus inside an open modal
    document.addEventListener("focusin", function (ev) {
      const root = U.$("#modalRoot");
      if (!root || root.hidden) return;
      if (!root.contains(ev.target)) {
        const first = root.querySelector("button, input, select, textarea, a[href]");
        if (first) first.focus();
      }
    });
  }

  return {
    applySettings, toggleTheme, setLang, toast, modal, closeModal, confirmDialog,
    renderShell, renderHeader, renderFooter, renderBottomNav,
    openAuth, openOnboarding, openSearch, closeSearch, openDrawer, closeDrawer,
    levelPill, skillBadges, emptyState, skeletonCards, complianceNote, pageHead,
    reveal, bindGlobal, bindScroll, openNotifications
  };
})();
