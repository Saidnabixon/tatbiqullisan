/* ============================================================
   QR — minimal QR Code generator (version 4, EC level L, byte mode)
   Enough capacity for a verification URL (up to 78 characters).
   Implements ISO/IEC 18004: RS(100,80), all 8 masks with penalty
   scoring, BCH format information.
   ============================================================ */
window.TLA = window.TLA || {};

TLA.qr = (function () {
  "use strict";

  const VERSION = 4;
  const SIZE = 17 + VERSION * 4;          // 33
  const TOTAL_CODEWORDS = 100;
  const EC_CODEWORDS = 20;
  const DATA_CODEWORDS = TOTAL_CODEWORDS - EC_CODEWORDS; // 80
  const ALIGN_POS = [6, 26];
  const G15 = 0x537;
  const G15_MASK = 0x5412;
  const EC_LEVEL_L = 1;                    // format indicator bits for L

  /* ---------- Galois field GF(256) ---------- */
  const EXP = new Uint8Array(512);
  const LOG = new Uint8Array(256);
  (function initGF() {
    let x = 1;
    for (let i = 0; i < 255; i++) {
      EXP[i] = x;
      LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= 0x11d;
    }
    for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  })();

  function gfMul(a, b) {
    if (a === 0 || b === 0) return 0;
    return EXP[LOG[a] + LOG[b]];
  }

  function generatorPoly(degree) {
    let poly = [1];
    for (let i = 0; i < degree; i++) {
      const next = new Array(poly.length + 1).fill(0);
      for (let j = 0; j < poly.length; j++) {
        next[j] ^= poly[j];
        next[j + 1] ^= gfMul(poly[j], EXP[i]);
      }
      poly = next;
    }
    return poly;
  }

  function reedSolomon(data, ecLen) {
    const gen = generatorPoly(ecLen);
    const res = new Array(data.length + ecLen).fill(0);
    for (let i = 0; i < data.length; i++) res[i] = data[i];
    for (let i = 0; i < data.length; i++) {
      const factor = res[i];
      if (factor === 0) continue;
      for (let j = 0; j < gen.length; j++) {
        res[i + j] ^= gfMul(gen[j], factor);
      }
    }
    return res.slice(data.length);
  }

  /* ---------- Data encoding ---------- */
  function toBytes(text) {
    const out = [];
    for (let i = 0; i < text.length; i++) {
      let c = text.charCodeAt(i);
      if (c < 0x80) out.push(c);
      else if (c < 0x800) { out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f)); }
      else { out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f)); }
    }
    return out;
  }

  function encodeData(text) {
    let bytes = toBytes(text);
    if (bytes.length > DATA_CODEWORDS - 2) bytes = bytes.slice(0, DATA_CODEWORDS - 2);

    const bits = [];
    function push(value, length) {
      for (let i = length - 1; i >= 0; i--) bits.push((value >>> i) & 1);
    }
    push(0b0100, 4);              // byte mode
    push(bytes.length, 8);        // character count (versions 1–9)
    bytes.forEach(b => push(b, 8));

    const capacityBits = DATA_CODEWORDS * 8;
    for (let i = 0; i < 4 && bits.length < capacityBits; i++) bits.push(0);
    while (bits.length % 8 !== 0) bits.push(0);

    const codewords = [];
    for (let i = 0; i < bits.length; i += 8) {
      let byte = 0;
      for (let j = 0; j < 8; j++) byte = (byte << 1) | bits[i + j];
      codewords.push(byte);
    }
    const pads = [0xec, 0x11];
    let k = 0;
    while (codewords.length < DATA_CODEWORDS) codewords.push(pads[k++ % 2]);

    return codewords.concat(reedSolomon(codewords, EC_CODEWORDS));
  }

  /* ---------- Matrix ---------- */
  function blank() {
    const m = [];
    for (let r = 0; r < SIZE; r++) m.push(new Array(SIZE).fill(null));
    return m;
  }

  function placeFinder(m, row, col) {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const rr = row + r, cc = col + c;
        if (rr < 0 || rr >= SIZE || cc < 0 || cc >= SIZE) continue;
        const inRing = (r >= 0 && r <= 6 && (c === 0 || c === 6)) ||
          (c >= 0 && c <= 6 && (r === 0 || r === 6)) ||
          (r >= 2 && r <= 4 && c >= 2 && c <= 4);
        m[rr][cc] = inRing;
      }
    }
  }

  function placeAlignment(m) {
    for (let i = 0; i < ALIGN_POS.length; i++) {
      for (let j = 0; j < ALIGN_POS.length; j++) {
        const row = ALIGN_POS[i], col = ALIGN_POS[j];
        if (m[row][col] !== null) continue;      // overlaps a finder
        for (let r = -2; r <= 2; r++) {
          for (let c = -2; c <= 2; c++) {
            m[row + r][col + c] = (Math.abs(r) === 2 || Math.abs(c) === 2 || (r === 0 && c === 0));
          }
        }
      }
    }
  }

  function placeTiming(m) {
    for (let i = 8; i < SIZE - 8; i++) {
      if (m[6][i] === null) m[6][i] = i % 2 === 0;
      if (m[i][6] === null) m[i][6] = i % 2 === 0;
    }
  }

  function bchTypeInfo(data) {
    let d = data << 10;
    function digit(v) { let n = 0; while (v !== 0) { n++; v >>>= 1; } return n; }
    while (digit(d) - digit(G15) >= 0) d ^= (G15 << (digit(d) - digit(G15)));
    return ((data << 10) | d) ^ G15_MASK;
  }

  function placeFormat(m, maskPattern) {
    const bits = bchTypeInfo((EC_LEVEL_L << 3) | maskPattern);
    for (let i = 0; i < 15; i++) {
      const on = ((bits >> i) & 1) === 1;
      if (i < 6) m[i][8] = on;
      else if (i < 8) m[i + 1][8] = on;
      else m[SIZE - 15 + i][8] = on;
    }
    for (let i = 0; i < 15; i++) {
      const on = ((bits >> i) & 1) === 1;
      if (i < 8) m[8][SIZE - i - 1] = on;
      else if (i < 9) m[8][15 - i - 1 + 1] = on;
      else m[8][15 - i - 1] = on;
    }
    m[SIZE - 8][8] = true;  // dark module
  }

  function maskFn(pattern, i, j) {
    switch (pattern) {
      case 0: return (i + j) % 2 === 0;
      case 1: return i % 2 === 0;
      case 2: return j % 3 === 0;
      case 3: return (i + j) % 3 === 0;
      case 4: return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
      case 5: return ((i * j) % 2) + ((i * j) % 3) === 0;
      case 6: return ((((i * j) % 2) + ((i * j) % 3)) % 2) === 0;
      default: return ((((i + j) % 2) + ((i * j) % 3)) % 2) === 0;
    }
  }

  function mapData(m, codewords, maskPattern) {
    let inc = -1, row = SIZE - 1, bitIndex = 7, byteIndex = 0;
    for (let col = SIZE - 1; col > 0; col -= 2) {
      if (col === 6) col--;
      for (;;) {
        for (let c = 0; c < 2; c++) {
          if (m[row][col - c] === null) {
            let dark = false;
            if (byteIndex < codewords.length) {
              dark = ((codewords[byteIndex] >>> bitIndex) & 1) === 1;
            }
            if (maskFn(maskPattern, row, col - c)) dark = !dark;
            m[row][col - c] = dark;
            bitIndex--;
            if (bitIndex === -1) { byteIndex++; bitIndex = 7; }
          }
        }
        row += inc;
        if (row < 0 || row >= SIZE) { row -= inc; inc = -inc; break; }
      }
    }
  }

  function penalty(m) {
    let score = 0;
    // rule 1: runs of 5+
    for (let r = 0; r < SIZE; r++) {
      for (let dir = 0; dir < 2; dir++) {
        let run = 1;
        for (let c = 1; c < SIZE; c++) {
          const prev = dir === 0 ? m[r][c - 1] : m[c - 1][r];
          const cur = dir === 0 ? m[r][c] : m[c][r];
          if (cur === prev) { run++; }
          else { if (run >= 5) score += 3 + (run - 5); run = 1; }
        }
        if (run >= 5) score += 3 + (run - 5);
      }
    }
    // rule 2: 2x2 blocks
    for (let r = 0; r < SIZE - 1; r++) {
      for (let c = 0; c < SIZE - 1; c++) {
        const v = m[r][c];
        if (v === m[r][c + 1] && v === m[r + 1][c] && v === m[r + 1][c + 1]) score += 3;
      }
    }
    // rule 3: finder-like patterns
    const pat = [true, false, true, true, true, false, true, false, false, false, false];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        for (let dir = 0; dir < 2; dir++) {
          let match = true;
          for (let k = 0; k < pat.length; k++) {
            const rr = dir === 0 ? r : r + k;
            const cc = dir === 0 ? c + k : c;
            if (rr >= SIZE || cc >= SIZE || m[rr][cc] !== pat[k]) { match = false; break; }
          }
          if (match) score += 40;
        }
      }
    }
    // rule 4: dark module ratio
    let dark = 0;
    for (let r = 0; r < SIZE; r++) for (let c = 0; c < SIZE; c++) if (m[r][c]) dark++;
    const ratio = Math.abs((dark * 100) / (SIZE * SIZE) - 50);
    score += Math.floor(ratio / 5) * 10;
    return score;
  }

  /** Returns a SIZE×SIZE boolean matrix for the given text. */
  function matrix(text) {
    const codewords = encodeData(String(text || ""));
    let best = null, bestScore = Infinity;
    for (let mask = 0; mask < 8; mask++) {
      const m = blank();
      placeFinder(m, 0, 0);
      placeFinder(m, SIZE - 7, 0);
      placeFinder(m, 0, SIZE - 7);
      placeAlignment(m);
      placeTiming(m);
      placeFormat(m, mask);
      mapData(m, codewords, mask);
      const score = penalty(m);
      if (score < bestScore) { bestScore = score; best = m; }
    }
    return best;
  }

  /** Renders the matrix as a compact, crisp SVG string. */
  function svg(text, opts) {
    const o = opts || {};
    const m = matrix(text);
    const quiet = o.quiet === undefined ? 2 : o.quiet;
    const dim = SIZE + quiet * 2;
    let path = "";
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (m[r][c]) path += "M" + (c + quiet) + " " + (r + quiet) + "h1v1h-1z";
      }
    }
    return '<svg viewBox="0 0 ' + dim + " " + dim + '" shape-rendering="crispEdges" role="img" aria-label="QR">' +
      '<rect width="' + dim + '" height="' + dim + '" fill="#ffffff"/>' +
      '<path d="' + path + '" fill="' + (o.color || "#0b1c2e") + '"/></svg>';
  }

  return { matrix, svg, SIZE };
})();
