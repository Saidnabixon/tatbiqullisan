/* ============================================================
   CHARTS — dependency-free SVG rendering
   The "shamsa" rosette is the platform's signature visual: a skill
   radar drawn as an illuminated manuscript medallion.
   ============================================================ */
window.TLA = window.TLA || {};

TLA.charts = (function () {
  "use strict";
  const U = TLA.utils;

  function polar(cx, cy, r, angleDeg) {
    const a = (angleDeg - 90) * Math.PI / 180;
    return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
  }

  /* ---------------- Shamsa rosette (radar) ---------------- */
  function shamsa(series, opts) {
    const o = opts || {};
    const size = 320, cx = 160, cy = 160, R = o.radius || 104;
    const n = series.length;
    if (!n) return "";
    const step = 360 / n;

    let rings = "";
    [0.25, 0.5, 0.75, 1].forEach(function (f) {
      let d = "";
      for (let i = 0; i < n; i++) {
        const p = polar(cx, cy, R * f, i * step);
        d += (i === 0 ? "M" : "L") + p.x.toFixed(1) + " " + p.y.toFixed(1);
      }
      rings += '<path class="ring" d="' + d + ' Z"/>';
    });

    let spokes = "";
    for (let i = 0; i < n; i++) {
      const p = polar(cx, cy, R, i * step);
      spokes += '<line class="spoke" x1="' + cx + '" y1="' + cy + '" x2="' + p.x.toFixed(1) + '" y2="' + p.y.toFixed(1) + '"/>';
    }

    // scalloped outer rosette
    const petals = 16, pr = R + 12;
    let petalPath = "";
    for (let i = 0; i <= petals; i++) {
      const p = polar(cx, cy, pr, (360 / petals) * i);
      const chord = 2 * pr * Math.sin(Math.PI / petals) / 2;
      petalPath += i === 0
        ? "M" + p.x.toFixed(1) + " " + p.y.toFixed(1)
        : " A" + chord.toFixed(1) + " " + chord.toFixed(1) + " 0 0 1 " + p.x.toFixed(1) + " " + p.y.toFixed(1);
    }

    let area = "", nodes = "", labels = "";
    for (let i = 0; i < n; i++) {
      const value = U.clamp(Number(series[i].value) || 0, 0, 100) / 100;
      const p = polar(cx, cy, R * Math.max(0.06, value), i * step);
      area += (i === 0 ? "M" : "L") + p.x.toFixed(1) + " " + p.y.toFixed(1);
      nodes += '<circle class="node" cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="3.4"/>';

      const lp = polar(cx, cy, R + 30, i * step);
      const anchor = lp.x > cx + 6 ? "start" : (lp.x < cx - 6 ? "end" : "middle");
      labels += '<text class="lbl" x="' + lp.x.toFixed(1) + '" y="' + (lp.y - 2).toFixed(1) + '" text-anchor="' + anchor + '">' +
        U.esc(series[i].label) + "</text>" +
        '<text class="val" x="' + lp.x.toFixed(1) + '" y="' + (lp.y + 11).toFixed(1) + '" text-anchor="' + anchor + '">' +
        Math.round(series[i].value) + "%</text>";
    }

    // The side labels sit outside the plot radius and are end/start anchored,
    // so the viewBox is padded horizontally — otherwise long skill names
    // ("Tinglash", "Leksika") get clipped at the SVG edge.
    const padX = 52;
    return '<svg class="shamsa ' + (o.onDark ? "shamsa-on-dark" : "") + '" viewBox="' + (-padX) + ' 0 ' +
      (size + padX * 2) + ' ' + size +
      '" role="img" aria-label="' + U.attr(o.aria || "Ko‘nikmalar diagrammasi") + '">' +
      '<path class="petal" d="' + petalPath + ' Z"/>' +
      rings + spokes +
      '<path class="area" d="' + area + ' Z"/>' + nodes + labels +
      "</svg>";
  }

  /* ---------------- Bars ---------------- */
  function bars(series, opts) {
    const o = opts || {};
    const w = 520, h = o.height || 190, padL = 34, padB = 26, padT = 12;
    const n = series.length;
    if (!n) return "";
    const max = o.max || 100;
    const bw = (w - padL - 10) / n;
    let grid = "", rects = "", labels = "";

    [0, 0.25, 0.5, 0.75, 1].forEach(function (f) {
      const y = padT + (h - padT - padB) * (1 - f);
      grid += '<line class="grid-line" x1="' + padL + '" y1="' + y.toFixed(1) + '" x2="' + w + '" y2="' + y.toFixed(1) + '"/>' +
        '<text class="axis-lbl" x="' + (padL - 8) + '" y="' + (y + 3).toFixed(1) + '" text-anchor="end">' + Math.round(max * f) + "</text>";
    });

    series.forEach(function (item, i) {
      const value = U.clamp(item.value, 0, max);
      const barH = (h - padT - padB) * (value / max);
      const x = padL + i * bw + bw * 0.18;
      const y = h - padB - barH;
      rects += '<rect class="bar' + (item.alt ? " alt" : "") + '" x="' + x.toFixed(1) + '" y="' + y.toFixed(1) +
        '" width="' + (bw * 0.64).toFixed(1) + '" height="' + Math.max(2, barH).toFixed(1) + '" rx="4"><title>' +
        U.esc(item.label) + ": " + Math.round(item.value) + "</title></rect>";
      labels += '<text class="axis-lbl" x="' + (x + bw * 0.32).toFixed(1) + '" y="' + (h - 8) +
        '" text-anchor="middle">' + U.esc(item.label) + "</text>";
    });

    return '<svg class="chart-svg" viewBox="0 0 ' + w + " " + h + '" preserveAspectRatio="xMidYMid meet" role="img">' +
      grid + rects + labels + "</svg>";
  }

  /* ---------------- Line ---------------- */
  function line(points, opts) {
    const o = opts || {};
    const w = 520, h = o.height || 190, padL = 34, padB = 26, padT = 14, padR = 10;
    if (points.length < 2) {
      return '<div class="empty" style="padding:2rem"><p class="muted">' +
        U.esc(o.emptyText || "Grafik uchun kamida ikkita natija kerak.") + "</p></div>";
    }
    const max = o.max || 100;
    const innerW = w - padL - padR;
    const innerH = h - padT - padB;
    const stepX = innerW / (points.length - 1);

    let grid = "";
    [0, 0.5, 1].forEach(function (f) {
      const y = padT + innerH * (1 - f);
      grid += '<line class="grid-line" x1="' + padL + '" y1="' + y.toFixed(1) + '" x2="' + (w - padR) + '" y2="' + y.toFixed(1) + '"/>' +
        '<text class="axis-lbl" x="' + (padL - 8) + '" y="' + (y + 3).toFixed(1) + '" text-anchor="end">' + Math.round(max * f) + "</text>";
    });

    let d = "", dots = "", labels = "";
    points.forEach(function (pt, i) {
      const x = padL + stepX * i;
      const y = padT + innerH * (1 - U.clamp(pt.value, 0, max) / max);
      d += (i === 0 ? "M" : "L") + x.toFixed(1) + " " + y.toFixed(1);
      dots += '<circle class="dot" cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="4"><title>' +
        U.esc(pt.label) + ": " + Math.round(pt.value) + "</title></circle>";
      if (points.length <= 8 || i % 2 === 0) {
        labels += '<text class="axis-lbl" x="' + x.toFixed(1) + '" y="' + (h - 8) + '" text-anchor="middle">' + U.esc(pt.label) + "</text>";
      }
    });

    const areaPath = d + " L" + (padL + stepX * (points.length - 1)).toFixed(1) + " " + (h - padB) +
      " L" + padL + " " + (h - padB) + " Z";

    return '<svg class="chart-svg" viewBox="0 0 ' + w + " " + h + '" preserveAspectRatio="xMidYMid meet" role="img">' +
      '<defs><linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0%" stop-color="rgba(200,162,83,.42)"/><stop offset="100%" stop-color="rgba(200,162,83,0)"/>' +
      "</linearGradient></defs>" +
      grid + '<path class="line-area" d="' + areaPath + '"/><path class="line" d="' + d + '"/>' + dots + labels + "</svg>";
  }

  /* ---------------- Donut ---------------- */
  function donut(value, opts) {
    const o = opts || {};
    const size = o.size || 168, stroke = o.stroke || 12;
    const r = (size - stroke) / 2;
    const c = 2 * Math.PI * r;
    const filled = c * U.clamp(value, 0, 100) / 100;
    return '<svg viewBox="0 0 ' + size + " " + size + '" width="' + size + '" height="' + size + '" role="img" aria-label="' +
      Math.round(value) + '%">' +
      '<circle class="donut-track" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r.toFixed(1) + '" stroke-width="' + stroke + '"/>' +
      '<circle class="donut-value" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r.toFixed(1) + '" stroke-width="' + stroke +
      '" stroke-dasharray="' + filled.toFixed(1) + " " + c.toFixed(1) + '" transform="rotate(-90 ' + size / 2 + " " + size / 2 + ')"/>' +
      "</svg>";
  }

  /* ---------------- Sparkline ---------------- */
  function sparkline(values, opts) {
    const o = opts || {};
    const w = o.width || 120, h = o.height || 32;
    if (!values.length) return "";
    const max = Math.max.apply(null, values.concat([1]));
    const step = values.length > 1 ? w / (values.length - 1) : w;
    let d = "";
    values.forEach(function (v, i) {
      const x = step * i;
      const y = h - (h - 4) * (v / max) - 2;
      d += (i === 0 ? "M" : "L") + x.toFixed(1) + " " + y.toFixed(1);
    });
    return '<svg class="chart-svg" viewBox="0 0 ' + w + " " + h + '" width="' + w + '" height="' + h + '" aria-hidden="true">' +
      '<path class="line" d="' + d + '" stroke-width="2"/></svg>';
  }

  return { shamsa, bars, line, donut, sparkline };
})();
