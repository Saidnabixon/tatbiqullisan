/* ============================================================
   DATA — levels, skills, courses, modules, lessons, content packs
   All educational content here is demo/practice material authored
   for the prototype. It is never presented as official exam content.
   ============================================================ */
window.TLA = window.TLA || {};
TLA.data = TLA.data || {};

(function () {
  "use strict";

  /* ---------------- Levels (CEFR) ---------------- */
  TLA.data.levels = [
    { id: "a1", code: "A1", uz: "Boshlang‘ich", en: "Beginner", ar: "مبتدئ", words: 500,
      descUz: "Harflar, oddiy jumlalar va kundalik so‘rashuv.", hours: 40 },
    { id: "a2", code: "A2", uz: "Elementar", en: "Elementary", ar: "ما قبل المتوسط", words: 1100,
      descUz: "Kundalik mavzular, o‘tgan zamon, oddiy matnlar.", hours: 50 },
    { id: "b1", code: "B1", uz: "O‘rta", en: "Intermediate", ar: "متوسط", words: 2200,
      descUz: "Erkin muloqot, matn tahlili, fikr bildirish.", hours: 60 },
    { id: "b2", code: "B2", uz: "O‘rtadan yuqori", en: "Upper intermediate", ar: "فوق المتوسط", words: 3500,
      descUz: "Murakkab matnlar, munozara, akademik uslub.", hours: 70 },
    { id: "c1", code: "C1", uz: "Yuqori", en: "Advanced", ar: "متقدّم", words: 5000,
      descUz: "Ilmiy va badiiy matnlar, nozik uslubiy farqlar.", hours: 80 },
    { id: "c2", code: "C2", uz: "Mukammal", en: "Proficient", ar: "متمكّن", words: 7000,
      descUz: "Ona tilida so‘zlashuvchiga yaqin daraja.", hours: 90 }
  ];

  TLA.data.skills = [
    { id: "reading", icon: "◈", key: "misc.skill.reading" },
    { id: "listening", icon: "◉", key: "misc.skill.listening" },
    { id: "grammar", icon: "◆", key: "misc.skill.grammar" },
    { id: "vocabulary", icon: "❖", key: "misc.skill.vocabulary" },
    { id: "writing", icon: "✎", key: "misc.skill.writing" },
    { id: "speaking", icon: "◑", key: "misc.skill.speaking" }
  ];

  /* ---------------- Arabic reading texts (demo content) ---------------- */
  TLA.data.texts = {
    t_a1: {
      level: "a1",
      titleAr: "التَّعَارُف",
      titleUz: "Tanishuv",
      body: "مَرْحَبًا! اسْمِي أَحْمَدُ وَأَنَا طَالِبٌ فِي الْجَامِعَةِ. أَسْكُنُ فِي مَدِينَةِ طَشْقَنْد مَعَ أُسْرَتِي. لِي أَخٌ وَأُخْتٌ. أَبِي مُهَنْدِسٌ وَأُمِّي مُعَلِّمَةٌ. أَدْرُسُ اللُّغَةَ الْعَرَبِيَّةَ كُلَّ يَوْمٍ لِأَنَّهَا لُغَةٌ جَمِيلَةٌ. فِي الصَّبَاحِ أَذْهَبُ إِلَى الْجَامِعَةِ، وَفِي الْمَسَاءِ أَقْرَأُ الْكُتُبَ.",
      uz: "Salom! Mening ismim Ahmad, men universitet talabasiman. Toshkent shahrida oilam bilan yashayman. Bir akam va bir opam bor. Otam muhandis, onam o‘qituvchi. Har kuni arab tilini o‘rganaman, chunki u go‘zal til. Ertalab universitetga boraman, kechqurun kitob o‘qiyman."
    },
    t_a2: {
      level: "a2",
      titleAr: "يَوْمِي الدِّرَاسِيّ",
      titleUz: "Mening o‘quv kunim",
      body: "أَسْتَيْقِظُ فِي السَّاعَةِ السَّادِسَةِ صَبَاحًا. بَعْدَ الْفَطُورِ أَرْكَبُ الْحَافِلَةَ وَأَذْهَبُ إِلَى الْمَعْهَدِ. تَبْدَأُ الدُّرُوسُ فِي الثَّامِنَةِ وَتَنْتَهِي فِي الثَّانِيَةَ عَشْرَةَ. بَعْدَ الظُّهْرِ أَعُودُ إِلَى الْبَيْتِ وَأُرَاجِعُ الدُّرُوسَ. أَمْسِ ذَهَبْتُ إِلَى الْمَكْتَبَةِ وَاسْتَعَرْتُ كِتَابًا جَدِيدًا عَنْ تَارِيخِ الْعَرَبِ. أَنَا سَعِيدٌ لِأَنَّ مُسْتَوَايَ يَتَحَسَّنُ شَيْئًا فَشَيْئًا.",
      uz: "Ertalab soat oltida uyg‘onaman. Nonushtadan keyin avtobusga chiqib institutga boraman. Darslar sakkizda boshlanib, o‘n ikkida tugaydi. Tushdan keyin uyga qaytib darslarni takrorlayman. Kecha kutubxonaga borib, arablar tarixi haqida yangi kitob oldim. Darajam asta-sekin yaxshilanayotgani uchun xursandman."
    },
    t_b1: {
      level: "b1",
      titleAr: "السَّفَرُ وَالسِّيَاحَة",
      titleUz: "Sayohat va turizm",
      body: "يُحِبُّ كَثِيرٌ مِنَ النَّاسِ السَّفَرَ لِأَنَّهُ يَفْتَحُ أَمَامَهُمْ عَالَمًا جَدِيدًا. عِنْدَمَا نُسَافِرُ إِلَى بَلَدٍ آخَرَ، نَتَعَرَّفُ عَلَى عَادَاتِ أَهْلِهِ وَطَعَامِهِمْ وَلُغَتِهِمْ. وَقَبْلَ السَّفَرِ يَجِبُ أَنْ نُخَطِّطَ جَيِّدًا: نَحْجِزُ التَّذَاكِرَ، وَنَبْحَثُ عَنْ فُنْدُقٍ مُنَاسِبٍ، وَنَقْرَأُ عَنِ الْأَمَاكِنِ السِّيَاحِيَّةِ. بَعْضُ النَّاسِ يُفَضِّلُونَ السَّفَرَ فِي مَجْمُوعَةٍ، وَآخَرُونَ يُفَضِّلُونَ السَّفَرَ وَحْدَهُمْ لِأَنَّهُمْ يَشْعُرُونَ بِحُرِّيَّةٍ أَكْبَرَ. وَمَهْمَا كَانَتِ الطَّرِيقَةُ، فَإِنَّ السَّفَرَ يُعَلِّمُنَا الصَّبْرَ وَاحْتِرَامَ الِاخْتِلَافِ.",
      uz: "Ko‘p odamlar sayohatni yaxshi ko‘radi, chunki u ular oldida yangi dunyoni ochadi. Boshqa mamlakatga borganda uning aholisi odatlari, taomlari va tili bilan tanishamiz. Sayohatdan oldin yaxshi rejalashtirish kerak: chiptalarni band qilamiz, mos mehmonxona izlaymiz va sayyohlik joylari haqida o‘qiymiz. Ba’zilar guruh bilan sayohat qilishni afzal ko‘rsa, boshqalar yolg‘iz sayohatni tanlaydi, chunki o‘zini erkinroq his qiladi. Usul qanday bo‘lmasin, sayohat bizga sabr va farqni hurmat qilishni o‘rgatadi."
    },
    t_b2: {
      level: "b2",
      titleAr: "التَّعْلِيمُ فِي عَصْرِ التِّقْنِيَة",
      titleUz: "Texnologiya asrida ta’lim",
      body: "أَحْدَثَتِ التِّقْنِيَةُ الْحَدِيثَةُ تَحَوُّلًا عَمِيقًا فِي طَرَائِقِ التَّعْلِيمِ. فَلَمْ يَعُدِ الطَّالِبُ مُقَيَّدًا بِجُدْرَانِ الصَّفِّ، بَلْ صَارَ فِي إِمْكَانِهِ أَنْ يَحْضُرَ مُحَاضَرَةً تُبَثُّ مِنْ مَدِينَةٍ بَعِيدَةٍ. غَيْرَ أَنَّ هٰذَا التَّحَوُّلَ لَا يَخْلُو مِنْ تَحَدِّيَاتٍ؛ إِذْ يَحْتَاجُ التَّعَلُّمُ عَنْ بُعْدٍ إِلَى انْضِبَاطٍ ذَاتِيٍّ عَالٍ، وَإِلَى بِنْيَةٍ تَقْنِيَّةٍ مُسْتَقِرَّةٍ. وَيَرَى الْبَاحِثُونَ أَنَّ الْحَلَّ الْأَمْثَلَ هُوَ الْمَزْجُ بَيْنَ التَّعْلِيمِ الْحُضُورِيِّ وَالرَّقْمِيِّ، بِحَيْثُ يُسْتَفَادُ مِنْ مَزَايَا كُلٍّ مِنْهُمَا.",
      uz: "Zamonaviy texnologiya ta’lim usullarida chuqur o‘zgarish yasadi. Talaba endi sinf devorlari bilan chegaralanmaydi, balki uzoq shahardan translyatsiya qilinayotgan ma’ruzada qatnasha oladi. Biroq bu o‘zgarish muammolarsiz emas: masofaviy ta’lim yuqori o‘z-o‘zini nazorat qilish va barqaror texnik infratuzilmani talab qiladi. Tadqiqotchilar eng maqbul yechim — an’anaviy va raqamli ta’limni birlashtirish, deb hisoblashadi."
    },
    t_c1: {
      level: "c1",
      titleAr: "الْبِيئَةُ وَالتَّنْمِيَةُ الْمُسْتَدَامَة",
      titleUz: "Atrof-muhit va barqaror rivojlanish",
      body: "يَشْهَدُ الْعَالَمُ الْيَوْمَ جَدَلًا وَاسِعًا حَوْلَ الْعَلَاقَةِ بَيْنَ النُّمُوِّ الِاقْتِصَادِيِّ وَحِمَايَةِ الْبِيئَةِ. فَبَيْنَمَا يَذْهَبُ فَرِيقٌ إِلَى أَنَّ التَّصْنِيعَ ضَرُورَةٌ لَا مَفَرَّ مِنْهَا لِرَفْعِ مُسْتَوَى الْمَعِيشَةِ، يُحَذِّرُ فَرِيقٌ آخَرُ مِنْ أَنَّ اسْتِنْزَافَ الْمَوَارِدِ سَيُكَلِّفُ الْأَجْيَالَ الْقَادِمَةَ ثَمَنًا بَاهِظًا. وَلَعَلَّ الْمَخْرَجَ يَكْمُنُ فِي مَفْهُومِ التَّنْمِيَةِ الْمُسْتَدَامَةِ الَّذِي يُوَازِنُ بَيْنَ حَاجَاتِ الْحَاضِرِ وَحُقُوقِ الْمُسْتَقْبَلِ، مِنْ غَيْرِ أَنْ يُضَحِّيَ بِأَحَدِهِمَا مِنْ أَجْلِ الْآخَرِ.",
      uz: "Bugungi dunyoda iqtisodiy o‘sish va atrof-muhitni muhofaza qilish o‘rtasidagi bog‘liqlik haqida keng bahs bormoqda. Bir guruh sanoatlashtirish turmush darajasini oshirish uchun muqarrar zarurat deb hisoblasa, boshqa guruh resurslarning tugashi kelajak avlodlarga qimmatga tushishidan ogohlantiradi. Yechim, ehtimol, barqaror rivojlanish tushunchasida — u bugungi ehtiyojlar bilan kelajak huquqlarini biri ikkinchisi hisobiga qurbon qilmasdan muvozanatlaydi."
    },
    t_c2: {
      level: "c2",
      titleAr: "اللُّغَةُ وَالْهُوِيَّة",
      titleUz: "Til va o‘zlik",
      body: "لَيْسَتِ اللُّغَةُ وِعَاءً مُحَايِدًا يُنْقَلُ فِيهِ الْمَعْنَى فَحَسْبُ، بَلْ هِيَ ذَاكِرَةٌ جَمَاعِيَّةٌ تَخْتَزِنُ رُؤْيَةَ أَهْلِهَا لِلْعَالَمِ. وَمِنْ ثَمَّ فَإِنَّ فُقْدَانَ لُغَةٍ لَيْسَ خَسَارَةً مُعْجَمِيَّةً، وَإِنَّمَا هُوَ انْطِفَاءُ طَرِيقَةٍ كَامِلَةٍ فِي التَّفْكِيرِ وَالتَّصْنِيفِ وَالتَّذَوُّقِ. عَلَى أَنَّ الْحِفَاظَ عَلَى اللُّغَةِ لَا يَعْنِي تَحْنِيطَهَا؛ فَاللُّغَاتُ الْحَيَّةُ هِيَ الَّتِي تَتَّسِعُ لِلْمُصْطَلَحِ الْجَدِيدِ مِنْ غَيْرِ أَنْ تَتَنَازَلَ عَنْ بِنْيَتِهَا الْعَمِيقَةِ.",
      uz: "Til shunchaki ma’noni tashiydigan betaraf idish emas, balki o‘z egalarining dunyoqarashini saqlovchi jamoaviy xotiradir. Shu bois tilning yo‘qolishi lug‘aviy yo‘qotish emas, balki fikrlash, tasniflash va did shakllantirishning butun bir usuli so‘nishidir. Ammo tilni asrash uni mumiyolash degani emas: tirik tillar chuqur tuzilishidan voz kechmagan holda yangi atamalarga joy topa oladigan tillardir."
    }
  };

  /* ---------------- Grammar notes (demo content) ---------------- */
  TLA.data.grammar = {
    g_a1_jumla: {
      level: "a1", titleUz: "Ismli jumla (الجملة الاسمية)", titleAr: "الْجُمْلَةُ الِاسْمِيَّة",
      bodyUz: "Ismli jumla ega (mubtada) va kesim (xabar)dan tuziladi. Ikkalasi ham odatda marfu’ (dammali) holatda bo‘ladi. Ega aniq (ال bilan), xabar esa noaniq bo‘ladi.",
      examples: [
        { ar: "الطَّالِبُ مُجْتَهِدٌ.", uz: "Talaba tirishqoq." },
        { ar: "الْبَيْتُ كَبِيرٌ.", uz: "Uy katta." },
        { ar: "اللُّغَةُ الْعَرَبِيَّةُ جَمِيلَةٌ.", uz: "Arab tili go‘zal." }
      ]
    },
    g_a1_tarif: {
      level: "a1", titleUz: "Aniqlik va noaniqlik (ال)", titleAr: "التَّعْرِيفُ وَالتَّنْكِير",
      bodyUz: "Noaniq ism oxirida tanvin (ــٌ ــً ــٍ) bo‘ladi. ال qo‘shilsa ism aniq bo‘lib, tanvin tushadi. Quyosh harflaridan oldin ل talaffuzda assimilyatsiya bo‘ladi.",
      examples: [
        { ar: "كِتَابٌ ← الْكِتَابُ", uz: "kitob → o‘sha kitob" },
        { ar: "شَمْسٌ ← الشَّمْسُ", uz: "quyosh → o‘sha quyosh (assimilyatsiya)" }
      ]
    },
    g_a2_mudari: {
      level: "a2", titleUz: "Hozirgi-kelasi zamon fe’li (المضارع)", titleAr: "الْفِعْلُ الْمُضَارِع",
      bodyUz: "Mudori’ fe’li أ، ن، ي، ت qo‘shimchalari bilan boshlanadi va shaxs-son bo‘yicha o‘zgaradi. Inkor uchun لَا, kelasi zamon uchun سَـ yoki سَوْفَ ishlatiladi.",
      examples: [
        { ar: "أَنَا أَكْتُبُ — نَحْنُ نَكْتُبُ", uz: "Men yozaman — Biz yozamiz" },
        { ar: "هُوَ يَدْرُسُ — هِيَ تَدْرُسُ", uz: "U (m) o‘qiydi — U (f) o‘qiydi" },
        { ar: "سَأَذْهَبُ غَدًا.", uz: "Ertaga boraman." }
      ]
    },
    g_a2_kana: {
      level: "a2", titleUz: "كَانَ va uning singillari", titleAr: "كَانَ وَأَخَوَاتُهَا",
      bodyUz: "كَانَ ismli jumlaga kirsa, egani marfu’ (ismi kana), kesimni mansub (xabari kana) qiladi. O‘tgan zamon ma’nosini beradi.",
      examples: [
        { ar: "الطَّقْسُ جَمِيلٌ ← كَانَ الطَّقْسُ جَمِيلًا.", uz: "Ob-havo chiroyli → Ob-havo chiroyli edi." },
        { ar: "أَصْبَحَ الْجَوُّ بَارِدًا.", uz: "Havo sovuq bo‘lib qoldi." }
      ]
    },
    g_b1_inna: {
      level: "b1", titleUz: "إِنَّ va uning singillari", titleAr: "إِنَّ وَأَخَوَاتُهَا",
      bodyUz: "إِنَّ، أَنَّ، لَكِنَّ، كَأَنَّ، لَيْتَ، لَعَلَّ egani mansub (ismi inna), kesimni marfu’ (xabari inna) qiladi — كان ning teskarisi.",
      examples: [
        { ar: "إِنَّ الطَّالِبَ مُجْتَهِدٌ.", uz: "Albatta, talaba tirishqoq." },
        { ar: "عَلِمْتُ أَنَّ الِامْتِحَانَ صَعْبٌ.", uz: "Imtihon qiyinligini bildim." },
        { ar: "لَعَلَّ النَّتِيجَةَ جَيِّدَةٌ.", uz: "Balki natija yaxshidir." }
      ]
    },
    g_b1_amr: {
      level: "b1", titleUz: "Buyruq va qaytariq (الأمر والنهي)", titleAr: "الْأَمْرُ وَالنَّهْي",
      bodyUz: "Buyruq mudori’dan yasaladi: harakat harfi olib tashlanadi, kerak bo‘lsa hamzat al-vasl qo‘shiladi. Qaytariq لَا + majzum mudori’ orqali beriladi.",
      examples: [
        { ar: "تَكْتُبُ ← اُكْتُبْ!", uz: "yozasan → yoz!" },
        { ar: "لَا تَتَأَخَّرْ عَنِ الدَّرْسِ.", uz: "Darsga kechikma." }
      ]
    },
    g_b2_majhul: {
      level: "b2", titleUz: "Majhul nisbat (المبني للمجهول)", titleAr: "الْمَبْنِيُّ لِلْمَجْهُول",
      bodyUz: "Majhulda fail tushiriladi, maf’ul esa noibu-l-fail bo‘lib marfu’ bo‘ladi. Mozida birinchi harf dammali, oxirgidan oldingisi kasrali; mudori’da birinchi harf dammali, oxirgidan oldingisi fathali bo‘ladi.",
      examples: [
        { ar: "كَتَبَ الطَّالِبُ الدَّرْسَ ← كُتِبَ الدَّرْسُ.", uz: "Talaba darsni yozdi → Dars yozildi." },
        { ar: "يُفْتَحُ الْبَابُ فِي الثَّامِنَةِ.", uz: "Eshik sakkizda ochiladi." }
      ]
    },
    g_b2_hal: {
      level: "b2", titleUz: "Hol va tamyiz (الحال والتمييز)", titleAr: "الْحَالُ وَالتَّمْيِيز",
      bodyUz: "Hol harakat holatini bildiradi va mansub bo‘ladi; sohibul-hol odatda ma’rifa bo‘ladi. Tamyiz esa mavhumlikni aniqlashtiradi.",
      examples: [
        { ar: "جَاءَ الطَّالِبُ مُسْرِعًا.", uz: "Talaba shoshib keldi." },
        { ar: "اِزْدَادَ الطَّالِبُ عِلْمًا.", uz: "Talabaning ilmi ortdi." }
      ]
    },
    g_c1_shart: {
      level: "c1", titleUz: "Shart uslubi (أسلوب الشرط)", titleAr: "أُسْلُوبُ الشَّرْط",
      bodyUz: "إِنْ، مَنْ، مَا، مَهْمَا، إِذَا kabi shart edatlari ikki fe’lni majzum qiladi (إذا bundan mustasno). Javob jumlasi ba’zan فَ bilan boshlanadi.",
      examples: [
        { ar: "إِنْ تَجْتَهِدْ تَنْجَحْ.", uz: "Tirishsang, muvaffaqiyat qozonasan." },
        { ar: "مَهْمَا تَفْعَلْ فَاللهُ عَلِيمٌ بِهِ.", uz: "Nima qilsang ham, Alloh uni biluvchi." }
      ]
    },
    g_c1_mafool: {
      level: "c1", titleUz: "Maf’ul li-ajlih va mutlaq", titleAr: "الْمَفْعُولُ لِأَجْلِهِ وَالْمُطْلَق",
      bodyUz: "Maf’ul li-ajlih harakat sababini bildiradi va mansub bo‘ladi. Maf’ul mutlaq esa fe’lni ta’kidlash yoki turini bayon qilish uchun keladi.",
      examples: [
        { ar: "قُمْتُ احْتِرَامًا لِلْأُسْتَاذِ.", uz: "Ustozga hurmat yuzasidan turdim." },
        { ar: "شَكَرْتُهُ شُكْرًا جَزِيلًا.", uz: "Unga katta minnatdorchilik bildirdim." }
      ]
    },
    g_c2_balaga: {
      level: "c2", titleUz: "Balog‘at: tashbih, tibaq, jinos", titleAr: "الْبَلَاغَة: التَّشْبِيهُ وَالطِّبَاقُ وَالْجِنَاس",
      bodyUz: "Tashbih ikki narsani o‘xshatadi; tibaq qarama-qarshi ma’noli so‘zlarni yonma-yon keltiradi; jinos esa shakli o‘xshash, ma’nosi turlicha so‘zlarga asoslanadi.",
      examples: [
        { ar: "العِلْمُ نُورٌ وَالجَهْلُ ظَلَامٌ.", uz: "Ilm — nur, jaholat — zulmat (tibaq)." },
        { ar: "هُوَ كَالْبَحْرِ فِي الْكَرَمِ.", uz: "U saxovatda dengizdek (tashbih)." }
      ]
    }
  };

  /* ---------------- Module blueprint per level ---------------- */
  const moduleTopics = {
    a1: [
      { uz: "Alifbo va talaffuz", ar: "الْحُرُوفُ وَالنُّطْق" },
      { uz: "Tanishuv va salomlashuv", ar: "التَّحِيَّةُ وَالتَّعَارُف" },
      { uz: "Oila va uy", ar: "الْأُسْرَةُ وَالْبَيْت" },
      { uz: "Sonlar va vaqt", ar: "الْأَعْدَادُ وَالْوَقْت" },
      { uz: "Ovqat va bozor", ar: "الطَّعَامُ وَالسُّوق" },
      { uz: "Ismli jumla asoslari", ar: "أَسَاسُ الْجُمْلَةِ الِاسْمِيَّة" }
    ],
    a2: [
      { uz: "Kundalik tartib", ar: "الرُّوتِينُ الْيَوْمِيّ" },
      { uz: "Ta’lim va universitet", ar: "التَّعْلِيمُ وَالْجَامِعَة" },
      { uz: "Shahar va yo‘nalish", ar: "الْمَدِينَةُ وَالِاتِّجَاهَات" },
      { uz: "O‘tgan zamon", ar: "الْفِعْلُ الْمَاضِي" },
      { uz: "Sog‘liq va shifokor", ar: "الصِّحَّةُ وَالطَّبِيب" },
      { uz: "Xat va xabar yozish", ar: "كِتَابَةُ الرِّسَالَة" }
    ],
    b1: [
      { uz: "Sayohat va turizm", ar: "السَّفَرُ وَالسِّيَاحَة" },
      { uz: "Ish va kasb", ar: "الْعَمَلُ وَالْمِهْنَة" },
      { uz: "Ommaviy axborot", ar: "وَسَائِلُ الْإِعْلَام" },
      { uz: "Fe’l zamonlari tizimi", ar: "نِظَامُ الْأَزْمِنَة" },
      { uz: "Fikr bildirish va bahs", ar: "إِبْدَاءُ الرَّأْي" },
      { uz: "Matn tahlili", ar: "تَحْلِيلُ النَّصّ" }
    ],
    b2: [
      { uz: "Texnologiya va ta’lim", ar: "التِّقْنِيَةُ وَالتَّعْلِيم" },
      { uz: "Iqtisod va bozor", ar: "الِاقْتِصَادُ وَالسُّوق" },
      { uz: "Majhul nisbat", ar: "الْمَبْنِيُّ لِلْمَجْهُول" },
      { uz: "Ilmiy uslub", ar: "الْأُسْلُوبُ الْعِلْمِيّ" },
      { uz: "Munozara va dalil", ar: "الْمُنَاظَرَةُ وَالْحُجَّة" },
      { uz: "Insho tuzilishi", ar: "بِنَاءُ الْمَقَال" }
    ],
    c1: [
      { uz: "Atrof-muhit va rivojlanish", ar: "الْبِيئَةُ وَالتَّنْمِيَة" },
      { uz: "Huquq va jamiyat", ar: "الْقَانُونُ وَالْمُجْتَمَع" },
      { uz: "Shart uslubi", ar: "أُسْلُوبُ الشَّرْط" },
      { uz: "Klassik matnlar", ar: "النُّصُوصُ التُّرَاثِيَّة" },
      { uz: "Akademik yozuv", ar: "الْكِتَابَةُ الْأَكَادِيمِيَّة" },
      { uz: "Nutq va taqdimot", ar: "الْخِطَابُ وَالْعَرْض" }
    ],
    c2: [
      { uz: "Til va o‘zlik", ar: "اللُّغَةُ وَالْهُوِيَّة" },
      { uz: "Adabiy tanqid", ar: "النَّقْدُ الْأَدَبِيّ" },
      { uz: "Balog‘at ilmi", ar: "عِلْمُ الْبَلَاغَة" },
      { uz: "Qiyosiy tahlil", ar: "التَّحْلِيلُ الْمُقَارَن" },
      { uz: "Tarjima mahorati", ar: "مَهَارَةُ التَّرْجَمَة" },
      { uz: "Ilmiy tadqiqot", ar: "الْبَحْثُ الْعِلْمِيّ" }
    ]
  };

  const skillCycle = ["vocabulary", "grammar", "reading", "listening", "speaking", "writing"];
  const packsByLevel = {
    a1: { text: "t_a1", grammar: ["g_a1_jumla", "g_a1_tarif"] },
    a2: { text: "t_a2", grammar: ["g_a2_mudari", "g_a2_kana"] },
    b1: { text: "t_b1", grammar: ["g_b1_inna", "g_b1_amr"] },
    b2: { text: "t_b2", grammar: ["g_b2_majhul", "g_b2_hal"] },
    c1: { text: "t_c1", grammar: ["g_c1_shart", "g_c1_mafool"] },
    c2: { text: "t_c2", grammar: ["g_c2_balaga", "g_c2_balaga"] }
  };

  /* ---------------- Courses ---------------- */
  const courseCopy = {
    a1: {
      forWhom: "Arab tilini noldan boshlayotganlar; harflarni tanimaydigan yoki endi o‘qishni o‘rganayotganlar.",
      outcomes: ["Arab alifbosini erkin o‘qish va yozish", "O‘zingiz va oilangiz haqida gapirish", "200+ eng ko‘p ishlatiladigan so‘zni bilish", "Oddiy ismli jumla tuzish"]
    },
    a2: {
      forWhom: "A1 darajasini yakunlagan yoki oddiy jumlalarni tushunadigan o‘quvchilar.",
      outcomes: ["Kundalik mavzularda suhbat qurish", "O‘tgan zamonda gapirish va yozish", "Qisqa matnlarni lug‘atsiz tushunish", "Rasmiy bo‘lmagan xat yozish"]
    },
    b1: {
      forWhom: "Muloqotni boshlagan, endi imtihon formatiga tayyorlanmoqchi bo‘lganlar.",
      outcomes: ["Tanish mavzularda erkin fikr bildirish", "O‘rta murakkablikdagi matnlarni tahlil qilish", "Multilevel va Darajaviy B1 formatiga kirish", "150 so‘zlik izchil insho yozish"]
    },
    b2: {
      forWhom: "B1 ni yakunlagan, akademik yoki kasbiy maqsadda arab tili kerak bo‘lganlar.",
      outcomes: ["Munozarada dalil keltirish", "Ilmiy-ommabop matnlarni tushunish", "Majhul nisbat va murakkab tuzilmalarni ishlatish", "Tuzilgan insho va hisobot yozish"]
    },
    c1: {
      forWhom: "Murakkab matnlar bilan ishlaydigan, tarjima yoki oliy ta’lim yo‘nalishidagilar.",
      outcomes: ["Klassik va zamonaviy matnlarni qiyoslash", "Nutq va taqdimot tayyorlash", "Uslubiy nozikliklarni farqlash", "Akademik matn yozish"]
    },
    c2: {
      forWhom: "Yuqori darajadagi o‘quvchilar, o‘qituvchilar va tarjimonlar.",
      outcomes: ["Badiiy matnni tanqidiy tahlil qilish", "Balog‘at vositalarini aniqlash", "Ikki tomonlama tarjima qilish", "Ilmiy maqola tuzilmasini egallash"]
    }
  };

  TLA.data.courses = TLA.data.levels.map(function (lvl, li) {
    const topics = moduleTopics[lvl.id];
    const perModule = [4, 4, 3, 3, 3, 3];
    let lessonNo = 0;
    const modules = topics.map(function (topic, mi) {
      const lessons = [];
      for (let i = 0; i < perModule[mi]; i++) {
        lessonNo++;
        const skill = skillCycle[(mi + i) % skillCycle.length];
        lessons.push({
          id: lvl.id + "-l" + lessonNo,
          no: lessonNo,
          titleUz: topic.uz + " — " + (i + 1) + "-dars",
          titleAr: topic.ar,
          skill: skill,
          minutes: 18 + ((mi + i) % 3) * 6,
          free: li === 0 || (mi === 0 && i < 2),
          textId: packsByLevel[lvl.id].text,
          grammarId: packsByLevel[lvl.id].grammar[i % 2]
        });
      }
      return {
        id: lvl.id + "-m" + (mi + 1),
        no: mi + 1,
        titleUz: topic.uz,
        titleAr: topic.ar,
        lessons: lessons
      };
    });

    const totalLessons = modules.reduce((n, m) => n + m.lessons.length, 0);
    return {
      id: lvl.id,
      level: lvl.id,
      code: lvl.code,
      titleUz: lvl.code + " Arab tili",
      titleAr: "اللُّغَةُ الْعَرَبِيَّة " + lvl.code,
      titleEn: lvl.code + " Arabic",
      subtitleUz: lvl.uz + " daraja",
      descUz: lvl.descUz,
      lessons: totalLessons,
      hours: lvl.hours,
      words: lvl.words,
      free: li === 0,
      skills: ["reading", "listening", "grammar", "vocabulary", "speaking", "writing"],
      forWhom: courseCopy[lvl.id].forWhom,
      outcomes: courseCopy[lvl.id].outcomes,
      modules: modules
    };
  });

  TLA.data.courseById = function (id) {
    return TLA.data.courses.filter(c => c.id === id)[0] || null;
  };

  TLA.data.lessonById = function (lessonId) {
    for (const course of TLA.data.courses) {
      for (const mod of course.modules) {
        for (const lesson of mod.lessons) {
          if (lesson.id === lessonId) return { course, module: mod, lesson };
        }
      }
    }
    return null;
  };

  TLA.data.allLessons = function () {
    const out = [];
    TLA.data.courses.forEach(c => c.modules.forEach(m => m.lessons.forEach(l => out.push({ course: c, module: m, lesson: l }))));
    return out;
  };

  /* ---------------- Course FAQ (shared) ---------------- */
  TLA.data.courseFaq = [
    { q: "Kursni qanday boshlayman?", a: "Ro‘yxatdan o‘ting, diagnostik testni topshiring va tizim sizga mos darajani tavsiya qiladi. So‘ng kursni ochib, birinchi darsdan boshlaysiz." },
    { q: "Darslar tartibi majburiymi?", a: "Yo‘q. Modullar ichida erkin harakatlanishingiz mumkin, lekin tizim ketma-ketlikni tavsiya qiladi — har bir dars oldingisiga tayanadi." },
    { q: "Sertifikat beriladimi?", a: "Kursning barcha darslari va yakuniy testi tugatilgach, platformaning ichki sertifikati beriladi. U davlat tomonidan tan olingan rasmiy hujjat emas." },
    { q: "Mobil telefonda ishlaydimi?", a: "Ha. Platforma telefon, planshet va kompyuter uchun alohida moslashtirilgan; test interfeysi mobil uchun qayta ishlangan." },
    { q: "Materiallar qanday yangilanadi?", a: "Darslar, savollar bazasi va kutubxona admin panel orqali boshqariladi; yangilanishlar bildirishnoma sifatida yetkaziladi." }
  ];
})();
