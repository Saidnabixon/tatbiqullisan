/* ============================================================
   QUESTION BANK — part 2: reading, listening, writing, speaking
   Listening scripts double as transcripts (revealed only when
   the section allows it) and as text for speech synthesis.
   ============================================================ */
window.TLA = window.TLA || {};
TLA.data = TLA.data || {};

/* ---------------- Listening scripts (demo content) ---------------- */
TLA.data.scripts = {
  s_a1: {
    level: "a1", titleUz: "Tanishuv", titleAr: "فِي الْجَامِعَة", seconds: 34,
    body: "مَرْحَبًا، اسْمِي سَارَة. أَنَا طَالِبَةٌ جَدِيدَةٌ فِي قِسْمِ اللُّغَةِ الْعَرَبِيَّةِ. أَسْكُنُ قَرِيبًا مِنَ الْجَامِعَةِ. أَذْهَبُ إِلَى الدَّرْسِ مَشْيًا كُلَّ صَبَاحٍ. أُحِبُّ الْقِرَاءَةَ فِي الْمَكْتَبَةِ بَعْدَ الدُّرُوسِ.",
    uz: "Salom, mening ismim Sora. Men arab tili bo‘limining yangi talabasiman. Universitetga yaqin joyda yashayman. Har kuni ertalab darsga piyoda boraman. Darslardan keyin kutubxonada o‘qishni yaxshi ko‘raman."
  },
  s_a2: {
    level: "a2", titleUz: "E’lon", titleAr: "إِعْلَانٌ فِي الْمَعْهَد", seconds: 38,
    body: "انْتِبَاهْ، أَيُّهَا الطُّلَّابُ. سَيَبْدَأُ دَرْسُ الِاسْتِمَاعِ غَدًا فِي السَّاعَةِ التَّاسِعَةِ صَبَاحًا فِي الْقَاعَةِ الثَّالِثَةِ، وَلَيْسَ فِي الْقَاعَةِ الْأُولَى. يُرْجَى إِحْضَارُ الْكِتَابِ وَالسَّمَّاعَاتِ. مَنْ تَأَخَّرَ أَكْثَرَ مِنْ عَشْرِ دَقَائِقَ فَلَنْ يَدْخُلَ الْقَاعَةَ.",
    uz: "Diqqat, talabalar. Tinglash darsi ertaga soat to‘qqizda birinchi emas, uchinchi xonada boshlanadi. Kitob va quloqchin olib kelish so‘raladi. O‘n daqiqadan ortiq kechikkan talaba xonaga kiritilmaydi."
  },
  s_b1: {
    level: "b1", titleUz: "Mehmonxonada", titleAr: "حَجْزٌ فِي الْفُنْدُق", seconds: 46,
    body: "مَسَاءَ الْخَيْرِ، أُرِيدُ حَجْزَ غُرْفَةٍ لِشَخْصَيْنِ لِمُدَّةِ ثَلَاثِ لَيَالٍ. — أَهْلًا وَسَهْلًا. عِنْدَنَا غُرْفَةٌ فِي الطَّابِقِ الثَّالِثِ بِإِطْلَالَةٍ عَلَى الْبَحْرِ. — كَمْ سِعْرُ اللَّيْلَةِ؟ — مِائَةٌ وَعِشْرُونَ دُولَارًا، وَالْفَطُورُ مَشْمُولٌ. — هَلْ يُوجَدُ إِنْتَرْنِتْ مَجَّانِيٌّ؟ — نَعَمْ، فِي كُلِّ الْغُرَفِ. — حَسَنًا، سَأَحْجِزُ.",
    uz: "Xayrli kech, uch kechaga ikki kishilik xona band qilmoqchiman. — Xush kelibsiz. Uchinchi qavatda dengizga qaraydigan xonamiz bor. — Bir kechasi qancha? — Bir yuz yigirma dollar, nonushta narxga kiradi. — Bepul internet bormi? — Ha, barcha xonalarda. — Yaxshi, band qilaman."
  },
  s_b2: {
    level: "b2", titleUz: "Onlayn ta’lim", titleAr: "مُحَاضَرَةٌ قَصِيرَة", seconds: 52,
    body: "فِي السَّنَوَاتِ الْأَخِيرَةِ انْتَشَرَ التَّعْلِيمُ عَنْ بُعْدٍ انْتِشَارًا وَاسِعًا. وَتُشِيرُ التَّجَارِبُ إِلَى أَنَّ نَجَاحَهُ لَا يَعْتَمِدُ عَلَى جَوْدَةِ الْمَنَصَّةِ وَحْدَهَا، بَلْ عَلَى قُدْرَةِ الطَّالِبِ عَلَى تَنْظِيمِ وَقْتِهِ. وَلِذٰلِكَ تُوصِي كَثِيرٌ مِنَ الْمُؤَسَّسَاتِ بِتَحْدِيدِ سَاعَاتٍ ثَابِتَةٍ لِلدِّرَاسَةِ، وَبِتَقْسِيمِ الْمَادَّةِ إِلَى وَحَدَاتٍ قَصِيرَةٍ.",
    uz: "So‘nggi yillarda masofaviy ta’lim keng tarqaldi. Tajribalar shuni ko‘rsatadiki, uning muvaffaqiyati faqat platforma sifatiga emas, balki talabaning vaqtini tashkil qila olishiga bog‘liq. Shuning uchun ko‘p muassasalar o‘qish uchun qat’iy soatlar belgilashni va materialni qisqa bo‘limlarga bo‘lishni tavsiya qiladi."
  },
  s_c1: {
    level: "c1", titleUz: "Xabar", titleAr: "نَشْرَةٌ إِخْبَارِيَّة", seconds: 55,
    body: "اِخْتَتَمَ أَمْسِ فِي الْعَاصِمَةِ مُؤْتَمَرٌ دَوْلِيٌّ حَوْلَ التَّغَيُّرِ الْمُنَاخِيِّ، شَارَكَ فِيهِ بَاحِثُونَ مِنْ أَكْثَرَ مِنْ ثَلَاثِينَ دَوْلَةً. وَقَدْ أَكَّدَ الْمُشَارِكُونَ أَنَّ خَفْضَ الِانْبِعَاثَاتِ لَنْ يَتَحَقَّقَ مِنْ غَيْرِ اسْتِثْمَارٍ حَقِيقِيٍّ فِي الطَّاقَةِ الْمُتَجَدِّدَةِ، وَدَعَوْا إِلَى إِنْشَاءِ صُنْدُوقٍ مُشْتَرَكٍ لِدَعْمِ الدُّوَلِ النَّامِيَةِ.",
    uz: "Kecha poytaxtda iqlim o‘zgarishiga bag‘ishlangan xalqaro konferensiya yakunlandi; unda o‘ttizdan ortiq davlat tadqiqotchilari ishtirok etdi. Ishtirokchilar chiqindilarni kamaytirish qayta tiklanuvchi energiyaga real investitsiyasiz amalga oshmasligini ta’kidladi va rivojlanayotgan davlatlarni qo‘llab-quvvatlash uchun umumiy jamg‘arma tuzishga chaqirdi."
  },
  s_c2: {
    level: "c2", titleUz: "Adabiy sharh", titleAr: "تَعْلِيقٌ نَقْدِيّ", seconds: 58,
    body: "يَذْهَبُ بَعْضُ النُّقَّادِ إِلَى أَنَّ قِيمَةَ النَّصِّ لَا تُقَاسُ بِمَا يَقُولُهُ صَرَاحَةً، وَإِنَّمَا بِمَا يَتْرُكُهُ لِلْقَارِئِ مِنْ فَرَاغَاتٍ يَمْلَؤُهَا بِتَأْوِيلِهِ. غَيْرَ أَنَّ هٰذَا الرَّأْيَ، عَلَى وَجَاهَتِهِ، قَدْ يُفْضِي إِلَى فَوْضَى تَأْوِيلِيَّةٍ إِذَا لَمْ يُضْبَطْ بِمَعَايِيرَ لُغَوِيَّةٍ وَسِيَاقِيَّةٍ وَاضِحَةٍ.",
    uz: "Ba’zi tanqidchilar matnning qiymati u ochiq aytgan narsa bilan emas, balki o‘quvchiga qoldirgan va uning talqini bilan to‘ldiriladigan bo‘shliqlar bilan o‘lchanadi, deb hisoblaydi. Biroq bu fikr, o‘rinli bo‘lsa-da, aniq lisoniy va kontekstual mezonlar bilan tartibga solinmasa, talqin tartibsizligiga olib kelishi mumkin."
  }
};

/* ---------------- Reading questions ---------------- */
TLA.data.questions.push(
  { id: "r-a1-1", type: "reading", textId: "t_a1", level: "a1", skill: "reading", topic: "tanishuv", diff: "easy",
    promptUz: "Matnga ko‘ra savolga javob bering:", ar: "مَا اسْمُ الطَّالِبِ؟",
    opts: ["أَحْمَد", "مُحَمَّد", "عَلِيّ", "خَالِد"], optsAr: true, ans: 0,
    expUz: "Matn boshida: «اسْمِي أَحْمَدُ»." },
  { id: "r-a1-2", type: "reading", textId: "t_a1", level: "a1", skill: "reading", topic: "tanishuv", diff: "easy",
    promptUz: "Matnga ko‘ra:", ar: "أَيْنَ يَسْكُنُ أَحْمَدُ؟",
    opts: ["فِي طَشْقَنْد", "فِي الْقَاهِرَة", "فِي دِمَشْق", "فِي بُخَارَى"], optsAr: true, ans: 0,
    expUz: "«أَسْكُنُ فِي مَدِينَةِ طَشْقَنْد مَعَ أُسْرَتِي»." },
  { id: "r-a1-3", type: "reading", textId: "t_a1", level: "a1", skill: "reading", topic: "tanishuv", diff: "medium",
    promptUz: "Matnga ko‘ra:", ar: "مَاذَا يَفْعَلُ فِي الْمَسَاءِ؟",
    opts: ["يَقْرَأُ الْكُتُبَ", "يَذْهَبُ إِلَى الْجَامِعَةِ", "يَلْعَبُ كُرَةَ الْقَدَمِ", "يَعْمَلُ فِي الْمَكْتَبِ"], optsAr: true, ans: 0,
    expUz: "«وَفِي الْمَسَاءِ أَقْرَأُ الْكُتُبَ»." },

  { id: "r-a2-1", type: "reading", textId: "t_a2", level: "a2", skill: "reading", topic: "kunlik", diff: "easy",
    promptUz: "Matnga ko‘ra:", ar: "مَتَى يَسْتَيْقِظُ الطَّالِبُ؟",
    opts: ["فِي السَّادِسَةِ صَبَاحًا", "فِي الثَّامِنَةِ", "فِي الْخَامِسَةِ", "بَعْدَ الظُّهْرِ"], optsAr: true, ans: 0,
    expUz: "«أَسْتَيْقِظُ فِي السَّاعَةِ السَّادِسَةِ صَبَاحًا»." },
  { id: "r-a2-2", type: "reading", textId: "t_a2", level: "a2", skill: "reading", topic: "kunlik", diff: "medium",
    promptUz: "Matnga ko‘ra:", ar: "كَيْفَ يَذْهَبُ إِلَى الْمَعْهَدِ؟",
    opts: ["بِالْحَافِلَةِ", "مَشْيًا", "بِالسَّيَّارَةِ", "بِالْقِطَارِ"], optsAr: true, ans: 0,
    expUz: "«أَرْكَبُ الْحَافِلَةَ وَأَذْهَبُ إِلَى الْمَعْهَدِ»." },
  { id: "r-a2-3", type: "reading", textId: "t_a2", level: "a2", skill: "reading", topic: "kunlik", diff: "medium",
    promptUz: "Matnga ko‘ra:", ar: "مَاذَا فَعَلَ أَمْسِ؟",
    opts: ["اِسْتَعَارَ كِتَابًا مِنَ الْمَكْتَبَةِ", "سَافَرَ إِلَى مَدِينَةٍ أُخْرَى", "زَارَ صَدِيقَهُ", "بَدَأَ عَمَلًا جَدِيدًا"], optsAr: true, ans: 0,
    expUz: "«أَمْسِ ذَهَبْتُ إِلَى الْمَكْتَبَةِ وَاسْتَعَرْتُ كِتَابًا جَدِيدًا»." },

  { id: "r-b1-1", type: "reading", textId: "t_b1", level: "b1", skill: "reading", topic: "sayohat", diff: "medium",
    promptUz: "Matnga ko‘ra:", ar: "لِمَاذَا يُحِبُّ النَّاسُ السَّفَرَ؟",
    opts: ["لِأَنَّهُ يَفْتَحُ عَالَمًا جَدِيدًا", "لِأَنَّهُ رَخِيصٌ", "لِأَنَّهُ سَهْلٌ", "لِأَنَّهُ قَصِيرٌ"], optsAr: true, ans: 0,
    expUz: "Matn boshida sayohatning sababi: «لِأَنَّهُ يَفْتَحُ أَمَامَهُمْ عَالَمًا جَدِيدًا»." },
  { id: "r-b1-2", type: "reading", textId: "t_b1", level: "b1", skill: "reading", topic: "sayohat", diff: "medium",
    promptUz: "Matnga ko‘ra sayohatdan oldin nima qilinadi?", ar: "مَاذَا يَجِبُ قَبْلَ السَّفَرِ؟",
    opts: ["التَّخْطِيطُ وَحَجْزُ التَّذَاكِرِ", "تَعَلُّمُ لُغَةٍ جَدِيدَةٍ", "شِرَاءُ سَيَّارَةٍ", "تَغْيِيرُ الْعَمَلِ"], optsAr: true, ans: 0,
    expUz: "«يَجِبُ أَنْ نُخَطِّطَ جَيِّدًا: نَحْجِزُ التَّذَاكِرَ...»." },
  { id: "r-b1-3", type: "reading", textId: "t_b1", level: "b1", skill: "reading", topic: "sayohat", diff: "hard",
    promptUz: "Matnga ko‘ra:", ar: "لِمَاذَا يُفَضِّلُ بَعْضُ النَّاسِ السَّفَرَ وَحْدَهُمْ؟",
    opts: ["لِأَنَّهُمْ يَشْعُرُونَ بِحُرِّيَّةٍ أَكْبَرَ", "لِأَنَّ السَّفَرَ وَحْدَهُ أَرْخَصُ", "لِأَنَّهُمْ لَا يُحِبُّونَ النَّاسَ", "لِأَنَّهُ أَسْرَعُ"], optsAr: true, ans: 0,
    expUz: "«وَآخَرُونَ يُفَضِّلُونَ السَّفَرَ وَحْدَهُمْ لِأَنَّهُمْ يَشْعُرُونَ بِحُرِّيَّةٍ أَكْبَرَ»." },

  { id: "r-b2-1", type: "reading", textId: "t_b2", level: "b2", skill: "reading", topic: "talim", diff: "medium",
    promptUz: "Matnga ko‘ra masofaviy ta’limning qiyinchiligi nima?", ar: "مَا التَّحَدِّي الَّذِي يَذْكُرُهُ النَّصُّ؟",
    opts: ["الِانْضِبَاطُ الذَّاتِيُّ وَالْبِنْيَةُ التَّقْنِيَّةُ", "غَلَاءُ الْكُتُبِ", "قِلَّةُ الْمُعَلِّمِينَ", "طُولُ الْمُحَاضَرَاتِ"], optsAr: true, ans: 0,
    expUz: "«يَحْتَاجُ التَّعَلُّمُ عَنْ بُعْدٍ إِلَى انْضِبَاطٍ ذَاتِيٍّ عَالٍ، وَإِلَى بِنْيَةٍ تَقْنِيَّةٍ مُسْتَقِرَّةٍ»." },
  { id: "r-b2-2", type: "reading", textId: "t_b2", level: "b2", skill: "reading", topic: "talim", diff: "hard",
    promptUz: "Tadqiqotchilar fikricha eng maqbul yechim:", ar: "مَا الْحَلُّ الْأَمْثَلُ فِي رَأْيِ الْبَاحِثِينَ؟",
    opts: ["الْمَزْجُ بَيْنَ الْحُضُورِيِّ وَالرَّقْمِيِّ", "إِلْغَاءُ التَّعْلِيمِ الرَّقْمِيِّ", "الِاكْتِفَاءُ بِالتَّعْلِيمِ عَنْ بُعْدٍ", "تَقْلِيلُ عَدَدِ الطُّلَّابِ"], optsAr: true, ans: 0,
    expUz: "«الْحَلَّ الْأَمْثَلَ هُوَ الْمَزْجُ بَيْنَ التَّعْلِيمِ الْحُضُورِيِّ وَالرَّقْمِيِّ»." },
  { id: "r-b2-3", type: "reading", textId: "t_b2", level: "b2", skill: "reading", topic: "talim", diff: "hard",
    promptUz: "«لَمْ يَعُدِ الطَّالِبُ مُقَيَّدًا بِجُدْرَانِ الصَّفِّ» iborasi nimani anglatadi?", ar: "",
    opts: ["Talaba masofadan ham dars ola oladi", "Sinflar yopilgan", "Talaba darsga bormaydi", "Sinfda joy yetishmaydi"], ans: 0,
    expUz: "Ibora ko‘chma ma’noda: ta’lim sinf devorlari bilan chegaralanmaydi." },

  { id: "r-c1-1", type: "reading", textId: "t_c1", level: "c1", skill: "reading", topic: "ekologiya", diff: "hard",
    promptUz: "Birinchi guruhning qarashi:", ar: "مَا مَوْقِفُ الْفَرِيقِ الْأَوَّلِ؟",
    opts: ["التَّصْنِيعُ ضَرُورَةٌ لِرَفْعِ مُسْتَوَى الْمَعِيشَةِ", "يَجِبُ إِيقَافُ التَّصْنِيعِ", "الْبِيئَةُ لَا تَهُمُّ", "التَّنْمِيَةُ مُسْتَحِيلَةٌ"], optsAr: true, ans: 0,
    expUz: "«يَذْهَبُ فَرِيقٌ إِلَى أَنَّ التَّصْنِيعَ ضَرُورَةٌ لَا مَفَرَّ مِنْهَا لِرَفْعِ مُسْتَوَى الْمَعِيشَةِ»." },
  { id: "r-c1-2", type: "reading", textId: "t_c1", level: "c1", skill: "reading", topic: "ekologiya", diff: "hard",
    promptUz: "Ikkinchi guruh nimadan ogohlantiradi?", ar: "مِمَّ يُحَذِّرُ الْفَرِيقُ الْآخَرُ؟",
    opts: ["اِسْتِنْزَافِ الْمَوَارِدِ وَكُلْفَتِهِ عَلَى الْأَجْيَالِ", "اِرْتِفَاعِ الْأَسْعَارِ", "قِلَّةِ الْوَظَائِفِ", "ضَعْفِ التَّعْلِيمِ"], optsAr: true, ans: 0,
    expUz: "«اِسْتِنْزَافَ الْمَوَارِدِ سَيُكَلِّفُ الْأَجْيَالَ الْقَادِمَةَ ثَمَنًا بَاهِظًا»." },
  { id: "r-c1-3", type: "reading", textId: "t_c1", level: "c1", skill: "reading", topic: "ekologiya", diff: "expert",
    promptUz: "Matnga ko‘ra barqaror rivojlanish nimani anglatadi?", ar: "",
    opts: ["Bugungi ehtiyoj va kelajak huquqi muvozanatini", "Faqat iqtisodiy o‘sishni", "Sanoatni to‘xtatishni", "Resurslarni ko‘proq ishlatishni"], ans: 0,
    expUz: "«يُوَازِنُ بَيْنَ حَاجَاتِ الْحَاضِرِ وَحُقُوقِ الْمُسْتَقْبَلِ»." },

  { id: "r-c2-1", type: "reading", textId: "t_c2", level: "c2", skill: "reading", topic: "til", diff: "expert",
    promptUz: "Matnning asosiy g‘oyasi:", ar: "مَا الْفِكْرَةُ الرَّئِيسَةُ؟",
    opts: ["اللُّغَةُ ذَاكِرَةٌ جَمَاعِيَّةٌ لَا وِعَاءٌ مُحَايِدٌ", "اللُّغَةُ وَسِيلَةُ نَقْلٍ فَقَطْ", "اللُّغَاتُ كُلُّهَا مُتَشَابِهَةٌ", "الْمُعْجَمُ أَهَمُّ مِنَ التَّرْكِيبِ"], optsAr: true, ans: 0,
    expUz: "Birinchi jumla asosiy tezisni beradi: til betaraf idish emas, jamoaviy xotira." },
  { id: "r-c2-2", type: "reading", textId: "t_c2", level: "c2", skill: "reading", topic: "til", diff: "expert",
    promptUz: "Muallifga ko‘ra tilning yo‘qolishi nima?", ar: "",
    opts: ["Butun bir fikrlash usulining so‘nishi", "Faqat lug‘atning kamayishi", "Yozuvning o‘zgarishi", "Talaffuzning buzilishi"], ans: 0,
    expUz: "«انْطِفَاءُ طَرِيقَةٍ كَامِلَةٍ فِي التَّفْكِيرِ وَالتَّصْنِيفِ وَالتَّذَوُّقِ»." },
  { id: "r-c2-3", type: "reading", textId: "t_c2", level: "c2", skill: "reading", topic: "til", diff: "expert",
    promptUz: "Matnga ko‘ra tirik til qanday bo‘ladi?", ar: "",
    opts: ["Chuqur tuzilishini saqlagan holda yangi atamaga joy topadi", "Mumiyolangan holda saqlanadi", "Boshqa tillardan uzoqlashadi", "O‘zgarishdan butunlay voz kechadi"], ans: 0,
    expUz: "«اللُّغَاتُ الْحَيَّةُ هِيَ الَّتِي تَتَّسِعُ لِلْمُصْطَلَحِ الْجَدِيدِ مِنْ غَيْرِ أَنْ تَتَنَازَلَ عَنْ بِنْيَتِهَا الْعَمِيقَةِ»." }
);

/* ---------------- Listening questions ---------------- */
TLA.data.questions.push(
  { id: "l-a1-1", type: "listening", scriptId: "s_a1", level: "a1", skill: "listening", topic: "tanishuv", diff: "easy",
    promptUz: "Audioga ko‘ra:", ar: "مَنْ تَتَكَلَّمُ؟",
    opts: ["طَالِبَةٌ جَدِيدَةٌ", "مُعَلِّمَةٌ", "مُوَظَّفَةٌ", "طَبِيبَةٌ"], optsAr: true, ans: 0,
    expUz: "«أَنَا طَالِبَةٌ جَدِيدَةٌ فِي قِسْمِ اللُّغَةِ الْعَرَبِيَّةِ»." },
  { id: "l-a1-2", type: "listening", scriptId: "s_a1", level: "a1", skill: "listening", topic: "tanishuv", diff: "easy",
    promptUz: "Audioga ko‘ra:", ar: "كَيْفَ تَذْهَبُ إِلَى الدَّرْسِ؟",
    opts: ["مَشْيًا", "بِالْحَافِلَةِ", "بِالسَّيَّارَةِ", "بِالدَّرَّاجَةِ"], optsAr: true, ans: 0,
    expUz: "«أَذْهَبُ إِلَى الدَّرْسِ مَشْيًا كُلَّ صَبَاحٍ»." },
  { id: "l-a1-3", type: "listening", scriptId: "s_a1", level: "a1", skill: "listening", topic: "tanishuv", diff: "medium",
    promptUz: "Audioga ko‘ra darslardan keyin nima qiladi?", ar: "",
    opts: ["Kutubxonada o‘qiydi", "Uyga qaytadi", "Ishga boradi", "Sport bilan shug‘ullanadi"], ans: 0,
    expUz: "«أُحِبُّ الْقِرَاءَةَ فِي الْمَكْتَبَةِ بَعْدَ الدُّرُوسِ»." },

  { id: "l-a2-1", type: "listening", scriptId: "s_a2", level: "a2", skill: "listening", topic: "elon", diff: "medium",
    promptUz: "E’longa ko‘ra dars qayerda bo‘ladi?", ar: "أَيْنَ سَيَكُونُ الدَّرْسُ؟",
    opts: ["فِي الْقَاعَةِ الثَّالِثَةِ", "فِي الْقَاعَةِ الْأُولَى", "فِي الْمَكْتَبَةِ", "فِي الطَّابِقِ الثَّانِي"], optsAr: true, ans: 0,
    expUz: "«فِي الْقَاعَةِ الثَّالِثَةِ، وَلَيْسَ فِي الْقَاعَةِ الْأُولَى»." },
  { id: "l-a2-2", type: "listening", scriptId: "s_a2", level: "a2", skill: "listening", topic: "elon", diff: "medium",
    promptUz: "Nima olib kelish so‘raladi?", ar: "",
    opts: ["Kitob va quloqchin", "Daftar va qalam", "Kompyuter", "Lug‘at"], ans: 0,
    expUz: "«يُرْجَى إِحْضَارُ الْكِتَابِ وَالسَّمَّاعَاتِ»." },
  { id: "l-a2-3", type: "listening", scriptId: "s_a2", level: "a2", skill: "listening", topic: "elon", diff: "hard",
    promptUz: "Necha daqiqadan ortiq kechikkan talaba kiritilmaydi?", ar: "",
    opts: ["10", "5", "15", "20"], ans: 0,
    expUz: "«مَنْ تَأَخَّرَ أَكْثَرَ مِنْ عَشْرِ دَقَائِقَ فَلَنْ يَدْخُلَ الْقَاعَةَ»." },

  { id: "l-b1-1", type: "listening", scriptId: "s_b1", level: "b1", skill: "listening", topic: "sayohat", diff: "medium",
    promptUz: "Suhbatga ko‘ra:", ar: "كَمْ لَيْلَةً يُرِيدُ الضَّيْفُ؟",
    opts: ["ثَلَاثَ لَيَالٍ", "لَيْلَتَيْنِ", "أَرْبَعَ لَيَالٍ", "لَيْلَةً وَاحِدَةً"], optsAr: true, ans: 0,
    expUz: "«أُرِيدُ حَجْزَ غُرْفَةٍ لِشَخْصَيْنِ لِمُدَّةِ ثَلَاثِ لَيَالٍ»." },
  { id: "l-b1-2", type: "listening", scriptId: "s_b1", level: "b1", skill: "listening", topic: "sayohat", diff: "medium",
    promptUz: "Bir kechaning narxi qancha?", ar: "",
    opts: ["120 dollar", "100 dollar", "150 dollar", "200 dollar"], ans: 0,
    expUz: "«مِائَةٌ وَعِشْرُونَ دُولَارًا، وَالْفَطُورُ مَشْمُولٌ»." },
  { id: "l-b1-3", type: "listening", scriptId: "s_b1", level: "b1", skill: "listening", topic: "sayohat", diff: "hard",
    promptUz: "Narxga nima kiradi?", ar: "",
    opts: ["Nonushta", "Tushlik", "Transport", "Ekskursiya"], ans: 0,
    expUz: "«وَالْفَطُورُ مَشْمُولٌ» — nonushta narxga kiradi." },

  { id: "l-b2-1", type: "listening", scriptId: "s_b2", level: "b2", skill: "listening", topic: "talim", diff: "hard",
    promptUz: "Ma’ruzaga ko‘ra masofaviy ta’lim muvaffaqiyati nimaga bog‘liq?", ar: "",
    opts: ["Talabaning vaqtini tashkil qila olishiga", "Faqat platforma sifatiga", "Talabalar soniga", "Kitoblar narxiga"], ans: 0,
    expUz: "«لَا يَعْتَمِدُ عَلَى جَوْدَةِ الْمَنَصَّةِ وَحْدَهَا، بَلْ عَلَى قُدْرَةِ الطَّالِبِ عَلَى تَنْظِيمِ وَقْتِهِ»." },
  { id: "l-b2-2", type: "listening", scriptId: "s_b2", level: "b2", skill: "listening", topic: "talim", diff: "hard",
    promptUz: "Muassasalar nimani tavsiya qiladi?", ar: "",
    opts: ["Qat’iy o‘qish soatlari va qisqa bo‘limlar", "Ko‘proq imtihon", "Kamroq dars", "Guruhli loyihalar"], ans: 0,
    expUz: "«بِتَحْدِيدِ سَاعَاتٍ ثَابِتَةٍ لِلدِّرَاسَةِ، وَبِتَقْسِيمِ الْمَادَّةِ إِلَى وَحَدَاتٍ قَصِيرَةٍ»." },
  { id: "l-b2-3", type: "listening", scriptId: "s_b2", level: "b2", skill: "listening", topic: "talim", diff: "expert",
    promptUz: "Ma’ruzaning umumiy ohangi:", ar: "",
    opts: ["Muvozanatli tahlil", "Keskin tanqid", "To‘liq rad etish", "Reklama"], ans: 0,
    expUz: "Matn ijobiy va salbiy tomonlarni birga ko‘rsatadi — muvozanatli tahliliy ohang." },

  { id: "l-c1-1", type: "listening", scriptId: "s_c1", level: "c1", skill: "listening", topic: "xabar", diff: "hard",
    promptUz: "Xabarga ko‘ra konferensiya mavzusi:", ar: "",
    opts: ["Iqlim o‘zgarishi", "Ta’lim islohoti", "Savdo shartnomalari", "Sog‘liqni saqlash"], ans: 0,
    expUz: "«مُؤْتَمَرٌ دَوْلِيٌّ حَوْلَ التَّغَيُّرِ الْمُنَاخِيِّ»." },
  { id: "l-c1-2", type: "listening", scriptId: "s_c1", level: "c1", skill: "listening", topic: "xabar", diff: "expert",
    promptUz: "Ishtirokchilar nimaga chaqirdi?", ar: "",
    opts: ["Umumiy jamg‘arma tuzishga", "Yangi qonun qabul qilishga", "Konferensiyani ko‘chirishga", "Sanoatni to‘xtatishga"], ans: 0,
    expUz: "«دَعَوْا إِلَى إِنْشَاءِ صُنْدُوقٍ مُشْتَرَكٍ لِدَعْمِ الدُّوَلِ النَّامِيَةِ»." },
  { id: "l-c1-3", type: "listening", scriptId: "s_c1", level: "c1", skill: "listening", topic: "xabar", diff: "hard",
    promptUz: "Necha davlat vakillari qatnashdi?", ar: "",
    opts: ["30 dan ortiq", "20 ta", "15 ta", "50 dan ortiq"], ans: 0,
    expUz: "«بَاحِثُونَ مِنْ أَكْثَرَ مِنْ ثَلَاثِينَ دَوْلَةً»." },

  { id: "l-c2-1", type: "listening", scriptId: "s_c2", level: "c2", skill: "listening", topic: "tanqid", diff: "expert",
    promptUz: "Ba’zi tanqidchilar fikricha matn qiymati nima bilan o‘lchanadi?", ar: "",
    opts: ["O‘quvchiga qoldirilgan bo‘shliqlar bilan", "Muallif obro‘si bilan", "Matn uzunligi bilan", "So‘zlar soni bilan"], ans: 0,
    expUz: "«بِمَا يَتْرُكُهُ لِلْقَارِئِ مِنْ فَرَاغَاتٍ يَمْلَؤُهَا بِتَأْوِيلِهِ»." },
  { id: "l-c2-2", type: "listening", scriptId: "s_c2", level: "c2", skill: "listening", topic: "tanqid", diff: "expert",
    promptUz: "Muallif bu qarashga qanday munosabatda?", ar: "",
    opts: ["O‘rinli, lekin mezon kerak deb hisoblaydi", "To‘liq rad etadi", "So‘zsiz qo‘llab-quvvatlaydi", "Umuman baho bermaydi"], ans: 0,
    expUz: "«عَلَى وَجَاهَتِهِ، قَدْ يُفْضِي إِلَى فَوْضَى تَأْوِيلِيَّةٍ إِذَا لَمْ يُضْبَطْ...» — qisman qabul, shart bilan." },
  { id: "l-c2-3", type: "listening", scriptId: "s_c2", level: "c2", skill: "listening", topic: "tanqid", diff: "expert",
    promptUz: "«فَوْضَى تَأْوِيلِيَّة» iborasining ma’nosi:", ar: "",
    opts: ["Talqin tartibsizligi", "Til xatosi", "Uslub go‘zalligi", "Matn qisqarishi"], ans: 0,
    expUz: "فَوْضَى — tartibsizlik, تَأْوِيل — talqin." }
);

/* ---------------- Writing tasks ---------------- */
TLA.data.writingTasks = [
  { id: "w-a1", level: "a1", minWords: 40, maxWords: 60, minutes: 15,
    promptAr: "اُكْتُبْ عَنْ نَفْسِكَ وَأُسْرَتِكَ.", promptUz: "O‘zingiz va oilangiz haqida yozing.",
    hints: ["Ism, yosh, shahar", "Oila a’zolari", "O‘qish yoki ish", "Yoqtirgan mashg‘ulot"] },
  { id: "w-a2", level: "a2", minWords: 60, maxWords: 90, minutes: 20,
    promptAr: "صِفْ يَوْمَكَ الدِّرَاسِيَّ مِنَ الصَّبَاحِ إِلَى الْمَسَاءِ.", promptUz: "O‘quv kuningizni ertalabdan kechgacha tasvirlang.",
    hints: ["Vaqt ifodalari", "Mudori’ fe’llar", "Bog‘lovchilar: ثُمَّ، بَعْدَ ذٰلِكَ"] },
  { id: "w-b1", level: "b1", minWords: 100, maxWords: 150, minutes: 25,
    promptAr: "كَيْفَ تَقْضِي يَوْمَكَ؟ وَمَا الَّذِي تَوَدُّ تَغْيِيرَهُ فِي رُوتِينِكَ؟", promptUz: "Kuningizni qanday o‘tkazasiz va tartibingizda nimani o‘zgartirmoqchisiz?",
    hints: ["Kirish, asosiy qism, xulosa", "Sabab bog‘lovchilari: لِأَنَّ، لِذٰلِكَ", "Kamida 3 ta murakkab jumla"] },
  { id: "w-b2", level: "b2", minWords: 150, maxWords: 200, minutes: 30,
    promptAr: "هَلْ يُغْنِي التَّعْلِيمُ عَنْ بُعْدٍ عَنِ التَّعْلِيمِ الْحُضُورِيِّ؟ نَاقِشْ بِالْحُجَجِ.", promptUz: "Masofaviy ta’lim an’anaviy ta’lim o‘rnini bosa oladimi? Dalillar bilan muhokama qiling.",
    hints: ["Ikki tomonlama dalil", "Misol keltiring", "Aniq xulosa bilan yakunlang"] },
  { id: "w-c1", level: "c1", minWords: 200, maxWords: 250, minutes: 35,
    promptAr: "كَيْفَ يُمْكِنُ التَّوْفِيقُ بَيْنَ النُّمُوِّ الِاقْتِصَادِيِّ وَحِمَايَةِ الْبِيئَةِ؟", promptUz: "Iqtisodiy o‘sish va atrof-muhit muhofazasini qanday uyg‘unlashtirish mumkin?",
    hints: ["Tezis — dalil — qarshi dalil — xulosa", "Akademik uslub", "Aniq atamalardan foydalaning"] },
  { id: "w-c2", level: "c2", minWords: 250, maxWords: 320, minutes: 40,
    promptAr: "«اللُّغَةُ ذَاكِرَةٌ جَمَاعِيَّةٌ» — نَاقِشْ هٰذِهِ الْمَقُولَةَ نَقْدِيًّا.", promptUz: "«Til — jamoaviy xotira» degan fikrni tanqidiy tahlil qiling.",
    hints: ["Tezisni aniqlang", "Qarama-qarshi qarashni bering", "Uslubiy vositalardan foydalaning"] }
];

/* ---------------- Speaking prompts ---------------- */
TLA.data.speakingTasks = [
  { id: "sp-a1", level: "a1", prepSeconds: 30, speakSeconds: 60,
    promptAr: "عَرِّفْ بِنَفْسِكَ: الِاسْمُ، الْعُمْرُ، الْمَدِينَةُ، الدِّرَاسَةُ.", promptUz: "O‘zingiz bilan tanishtiring: ism, yosh, shahar, o‘qish." },
  { id: "sp-a2", level: "a2", prepSeconds: 40, speakSeconds: 90,
    promptAr: "تَحَدَّثْ عَنْ عُطْلَةِ نِهَايَةِ الْأُسْبُوعِ الْمَاضِيَةِ.", promptUz: "O‘tgan dam olish kunlaringiz haqida gapiring." },
  { id: "sp-b1", level: "b1", prepSeconds: 60, speakSeconds: 120,
    promptAr: "أَيُّهُمَا تُفَضِّلُ: السَّفَرُ فِي مَجْمُوعَةٍ أَمْ وَحْدَكَ؟ وَلِمَاذَا؟", promptUz: "Guruh bilan sayohatni afzal ko‘rasizmi yoki yolg‘iz? Nega?" },
  { id: "sp-b2", level: "b2", prepSeconds: 60, speakSeconds: 150,
    promptAr: "مَا أَثَرُ التِّقْنِيَةِ فِي طَرِيقَةِ تَعَلُّمِكَ؟ اذْكُرْ إِيجَابِيَّاتٍ وَسَلْبِيَّاتٍ.", promptUz: "Texnologiya o‘qish usulingizga qanday ta’sir qildi? Ijobiy va salbiy tomonlarini ayting." },
  { id: "sp-c1", level: "c1", prepSeconds: 90, speakSeconds: 180,
    promptAr: "هَلْ تَرَى أَنَّ حِمَايَةَ الْبِيئَةِ مَسْؤُولِيَّةُ الْأَفْرَادِ أَمِ الدَّوْلَةِ؟", promptUz: "Atrof-muhitni muhofaza qilish shaxs zimmasidami yoki davlat zimmasida?" },
  { id: "sp-c2", level: "c2", prepSeconds: 90, speakSeconds: 210,
    promptAr: "نَاقِشْ: هَلْ تُهَدِّدُ الْعَوْلَمَةُ التَّنَوُّعَ اللُّغَوِيَّ؟", promptUz: "Muhokama qiling: globallashuv til xilma-xilligiga tahdid soladimi?" }
];

/* ---------------- Bank helpers ---------------- */
TLA.data.questionById = function (id) {
  return TLA.data.questions.filter(q => q.id === id)[0] || null;
};

TLA.data.filterQuestions = function (filter) {
  const f = filter || {};
  return TLA.data.questions.filter(function (q) {
    if (f.level && q.level !== f.level) return false;
    if (f.levels && f.levels.indexOf(q.level) === -1) return false;
    if (f.skill && q.skill !== f.skill) return false;
    if (f.skills && f.skills.indexOf(q.skill) === -1) return false;
    if (f.diff && q.diff !== f.diff) return false;
    if (f.topic && q.topic !== f.topic) return false;
    return true;
  });
};
