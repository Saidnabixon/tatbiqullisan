/* ============================================================
   STATE — application state, auth, progress, gamification
   Every mutation goes through here, then persists via TLA.store.
   Replacing the bodies with API calls is enough to move to a
   real backend; the UI never touches storage directly.
   ============================================================ */
window.TLA = window.TLA || {};

TLA.state = (function () {
  "use strict";
  const U = TLA.utils;

  let data = null;
  const listeners = [];

  /* ---------- demo-only password digest ----------
     Real deployments hash server-side with bcrypt/argon2 and never
     send or keep the plain password. This exists so the prototype
     never stores a readable password, not as real security.        */
  function digest(text) {
    let h1 = 0x811c9dc5, h2 = 0x1000193;
    const salted = "tla$" + text;
    for (let i = 0; i < salted.length; i++) {
      const c = salted.charCodeAt(i);
      h1 = ((h1 ^ c) * 16777619) >>> 0;
      h2 = ((h2 + c * 31) ^ (h2 << 5)) >>> 0;
    }
    return h1.toString(36) + "-" + h2.toString(36);
  }

  function blankProfile() {
    return {
      level: null,
      targetLevel: "b2",
      goal: "exam",
      dailyMinutes: 30,
      examDate: "",
      plan: "free",
      xp: 0,
      streak: 0,
      bestStreak: 0,
      lastActiveDay: null,
      activeDays: [],
      lessons: {},          // lessonId -> { done:true, at }
      attempts: [],         // test attempts (newest last)
      skills: {},           // skillId -> rolling score 0..100
      vocab: {},            // arabic word -> { added, box, due }
      bookmarks: [],
      certificates: [],
      achievements: [],
      payments: [],
      tasks: {},            // dateKey -> { vocab:true, ... }
      studyMinutes: 0,
      onboarded: false
    };
  }

  function defaults() {
    return {
      v: 1,
      settings: {
        theme: "light",
        lang: "uz",
        motion: "on",
        fontScale: 1,
        publicRank: true,
        analytics: true,
        notif: { lessons: true, tests: true, streak: true, marketing: false }
      },
      session: { userId: null },
      users: [],
      profiles: {},
      guest: blankProfile(),
      config: JSON.parse(JSON.stringify(TLA.data.defaultConfig)),
      configVersion: TLA.data.configVersion || 0,
      plans: JSON.parse(JSON.stringify(TLA.data.defaultPlans)),
      admin: { extraQuestions: [], teachers: [], notices: [], certCounter: 0 },
      notifications: [],
      analytics: [],
      recentSearches: []
    };
  }

  function migrate(loaded) {
    const base = defaults();
    if (!loaded || typeof loaded !== "object") return base;
    const out = Object.assign(base, loaded);
    out.settings = Object.assign(base.settings, loaded.settings || {});
    out.settings.notif = Object.assign(base.settings.notif, (loaded.settings || {}).notif || {});
    // A newer site.config.json wins over whatever an admin saved locally,
    // so redeploying with updated contacts actually reaches returning visitors.
    const savedVersion = loaded.configVersion || 0;
    const fileVersion = TLA.data.configVersion || 0;
    out.config = fileVersion > savedVersion
      ? JSON.parse(JSON.stringify(TLA.data.defaultConfig))
      : Object.assign(base.config, loaded.config || {});
    out.configVersion = Math.max(savedVersion, fileVersion);
    out.admin = Object.assign(base.admin, loaded.admin || {});
    out.guest = Object.assign(blankProfile(), loaded.guest || {});
    out.profiles = loaded.profiles || {};
    Object.keys(out.profiles).forEach(function (k) {
      out.profiles[k] = Object.assign(blankProfile(), out.profiles[k]);
    });
    if (!Array.isArray(out.plans) || !out.plans.length) out.plans = base.plans;
    return out;
  }

  function persist() {
    TLA.store.save(data);
    listeners.forEach(fn => { try { fn(data); } catch (e) { /* ignore */ } });
  }

  async function init() {
    const loaded = await TLA.store.load();
    data = migrate(loaded);
    return data;
  }

  function onChange(fn) { listeners.push(fn); }

  /* ---------------- Session ---------------- */
  function currentUser() {
    if (!data.session.userId) return null;
    return data.users.filter(u => u.id === data.session.userId)[0] || null;
  }
  function isAuthed() { return !!currentUser(); }
  function isAdmin() {
    const u = currentUser();
    return !!u && (u.role === "admin" || u.role === "superadmin");
  }

  /** Active profile: the signed-in user's, or the guest sandbox. */
  function profile() {
    const u = currentUser();
    if (!u) return data.guest;
    if (!data.profiles[u.id]) data.profiles[u.id] = blankProfile();
    return data.profiles[u.id];
  }

  /** Mirrors a backend user record into local state so the rest of the
   *  app (admin panel's user list, profile page, leaderboard) keeps
   *  working against `data.users`/`data.profiles` unchanged — this is a
   *  read-through cache of identity, not a second source of truth for
   *  passwords (backend-mirrored users have no local `pass` digest, so
   *  `loginLocal` can never match them — see registerLocal/loginLocal
   *  fallback notes below). */
  function mirrorBackendUser(bu) {
    let existing = data.users.filter(u => u.id === bu.id)[0];
    if (!existing) {
      existing = { id: bu.id, name: bu.name, email: bu.email, role: bu.role, createdAt: new Date().toISOString(), backend: true };
      data.users.push(existing);
    } else {
      existing.name = bu.name;
      existing.email = bu.email;
      existing.role = bu.role;
    }
    if (!data.profiles[bu.id]) data.profiles[bu.id] = blankProfile();
    return existing;
  }

  /** Local-only account creation — the original (pre-backend) behaviour.
   *  Used automatically when no backend is reachable, so the static site
   *  keeps working standalone exactly as before a backend existed. The
   *  first local account still auto-becomes admin, since without a
   *  backend there is no other way to reach the admin panel. */
  function registerLocal(name, email, password, role) {
    const mail = String(email).trim().toLowerCase();
    if (data.users.some(u => u.email === mail)) {
      return { ok: false, error: "exists" };
    }
    const isFirst = data.users.length === 0;
    const user = {
      id: U.uid("u"),
      name: String(name).trim(),
      email: mail,
      pass: digest(password),
      role: role || (isFirst ? "admin" : "student"),
      createdAt: new Date().toISOString()
    };
    data.users.push(user);
    data.profiles[user.id] = Object.assign(blankProfile(), JSON.parse(JSON.stringify(data.guest)));
    data.guest = blankProfile();
    data.session.userId = user.id;
    track("registration", { role: user.role });
    notify("system", "Hisob yaratildi", "Xush kelibsiz! Shaxsiy o‘quv rejangiz tayyor.");
    touchStreak();
    persist();
    return { ok: true, user: user };
  }

  function loginLocal(email, password) {
    const mail = String(email).trim().toLowerCase();
    const user = data.users.filter(u => u.email === mail && u.pass === digest(password))[0];
    if (!user) return { ok: false, error: "creds" };
    data.session.userId = user.id;
    track("login", {});
    touchStreak();
    persist();
    return { ok: true, user: user };
  }

  /** Tries the backend first; falls back to local-only ONLY on a network
   *  failure (backend unreachable), never on a validation failure (e.g.
   *  duplicate email) — see 05b-api.js header comment for why that
   *  distinction matters. Callers now receive a Promise. */
  async function register(name, email, password, role) {
    let result;
    try {
      result = await TLA.api.register(name, email, password);
    } catch (networkErr) {
      return registerLocal(name, email, password, role);
    }
    if (!result.ok) return { ok: false, error: result.error };

    const user = mirrorBackendUser(result.user);
    TLA.api.setToken(result.token);
    data.profiles[user.id] = Object.assign(blankProfile(), JSON.parse(JSON.stringify(data.guest)));
    data.guest = blankProfile();
    data.session.userId = user.id;
    track("registration", { role: user.role, backend: true });
    notify("system", "Hisob yaratildi", "Xush kelibsiz! Shaxsiy o‘quv rejangiz tayyor.");
    touchStreak();
    persist();
    return { ok: true, user: user };
  }

  async function login(email, password) {
    let result;
    try {
      result = await TLA.api.login(email, password);
    } catch (networkErr) {
      return loginLocal(email, password);
    }
    if (!result.ok) return { ok: false, error: result.error };

    const user = mirrorBackendUser(result.user);
    TLA.api.setToken(result.token);
    data.session.userId = user.id;
    track("login", { backend: true });
    touchStreak();
    persist();
    return { ok: true, user: user };
  }

  /** Called once at boot (20-router.js) so a page reload with a valid
   *  saved token comes back signed in instead of flashing "guest".
   *  Silent no-op when there's no token, the token is invalid/expired,
   *  or the backend is unreachable right now (the token is kept in that
   *  last case, so it can still work once the backend is back up). */
  async function restoreSession() {
    const token = TLA.api.getToken();
    if (!token) return;
    let result;
    try {
      result = await TLA.api.me();
    } catch (networkErr) {
      return;
    }
    if (!result.ok) { TLA.api.clearToken(); return; }
    const user = mirrorBackendUser(result.user);
    data.session.userId = user.id;
    persist();
  }

  /** Synchronous on purpose (no caller currently awaits logout): local
   *  session clears immediately so the UI updates right away, while the
   *  backend token invalidation happens best-effort in the background. */
  function logout() {
    const token = TLA.api.getToken();
    data.session.userId = null;
    TLA.api.clearToken();
    persist();
    if (token) TLA.api.logout().catch(function () { /* best effort */ });
  }

  function updateUser(patch) {
    const u = currentUser();
    if (!u) return;
    Object.assign(u, patch);
    persist();
  }

  /** Local-only for now: this backend increment has no DELETE /api/users
   *  endpoint yet, so a backend-mirrored account still exists server-side
   *  after this call — only its local mirror and session are removed.
   *  Clearing the token is essential: without it, restoreSession() would
   *  silently re-fetch and re-mirror the same "deleted" account on the
   *  next page load. */
  function deleteAccount() {
    const u = currentUser();
    if (!u) return;
    delete data.profiles[u.id];
    data.users = data.users.filter(x => x.id !== u.id);
    data.session.userId = null;
    TLA.api.clearToken();
    persist();
  }

  /* ---------------- Settings ---------------- */
  function settings() { return data.settings; }
  function setSetting(key, value) {
    data.settings[key] = value;
    persist();
  }
  function setNotifPref(key, value) {
    data.settings.notif[key] = value;
    persist();
  }

  /* ---------------- Streak & XP ---------------- */
  function touchStreak() {
    const p = profile();
    const today = U.todayKey();
    if (p.lastActiveDay === today) return;
    if (p.lastActiveDay) {
      const gap = U.daysBetween(p.lastActiveDay, today);
      p.streak = gap === 1 ? p.streak + 1 : 1;
    } else {
      p.streak = 1;
    }
    p.lastActiveDay = today;
    p.bestStreak = Math.max(p.bestStreak || 0, p.streak);
    if (p.activeDays.indexOf(today) === -1) p.activeDays.push(today);
    if (p.activeDays.length > 400) p.activeDays = p.activeDays.slice(-400);
    checkAchievements();
    persist();
  }

  function addXp(amount, reason) {
    const p = profile();
    p.xp = (p.xp || 0) + amount;
    track("xp", { amount: amount, reason: reason || "" });
    persist();
    return p.xp;
  }

  function xpToday() {
    const p = profile();
    const today = U.todayKey();
    return (p.attempts || [])
      .filter(a => (a.at || "").slice(0, 10) === today)
      .reduce((sum, a) => sum + (a.xp || 0), 0);
  }

  /* ---------------- Lessons ---------------- */
  function completeLesson(lessonId, minutes) {
    const p = profile();
    if (!p.lessons[lessonId]) {
      p.lessons[lessonId] = { done: true, at: new Date().toISOString() };
      p.studyMinutes = (p.studyMinutes || 0) + (minutes || 20);
      addXp(10, "lesson");
      track("lesson_completed", { lesson: lessonId });
    }
    touchStreak();
    checkAchievements();
    persist();
  }

  function lessonDone(lessonId) {
    return !!(profile().lessons[lessonId] && profile().lessons[lessonId].done);
  }

  function courseProgress(courseId) {
    const course = TLA.data.courseById(courseId);
    if (!course) return { done: 0, total: 0, pct: 0 };
    let done = 0, total = 0;
    course.modules.forEach(m => m.lessons.forEach(l => {
      total++;
      if (lessonDone(l.id)) done++;
    }));
    return { done: done, total: total, pct: U.pct(done, total) };
  }

  /* ---------------- Attempts ---------------- */
  function recordAttempt(attempt) {
    const p = profile();
    attempt.id = attempt.id || U.uid("at");
    attempt.at = new Date().toISOString();
    p.attempts.push(attempt);
    if (p.attempts.length > 200) p.attempts = p.attempts.slice(-200);

    // rolling per-skill score: newest result weighted 40%
    Object.keys(attempt.skillScores || {}).forEach(function (skill) {
      const fresh = attempt.skillScores[skill];
      p.skills[skill] = p.skills[skill] == null ? fresh : Math.round(p.skills[skill] * 0.6 + fresh * 0.4);
    });

    if (attempt.level) p.level = attempt.level;
    p.studyMinutes = (p.studyMinutes || 0) + Math.round((attempt.seconds || 0) / 60);

    let xp = 20;
    if (attempt.score >= 90) xp += 30;
    else if (attempt.score >= 75) xp += 10;
    attempt.xp = xp;
    addXp(xp, "test");

    track("test_completed", { test: attempt.testId, score: attempt.score });
    touchStreak();
    checkAchievements();
    maybeIssueCertificate(attempt);
    persist();
    return attempt;
  }

  function attempts() { return profile().attempts.slice().reverse(); }
  function attemptById(id) { return profile().attempts.filter(a => a.id === id)[0] || null; }
  function attemptsFor(testId) { return profile().attempts.filter(a => a.testId === testId); }

  function stats() {
    const p = profile();
    const list = p.attempts || [];
    const scores = list.map(a => a.score);
    return {
      xp: p.xp || 0,
      streak: p.streak || 0,
      level: p.level,
      tests: list.length,
      avg: scores.length ? Math.round(U.average(scores)) : 0,
      lessons: Object.keys(p.lessons || {}).length,
      hours: Math.round((p.studyMinutes || 0) / 60),
      minutes: p.studyMinutes || 0
    };
  }

  /* ---------------- Vocabulary (spaced repetition) ---------------- */
  const BOX_DAYS = [1, 3, 7, 15, 30];

  function saveWord(word) {
    const p = profile();
    if (p.vocab[word]) return false;
    p.vocab[word] = { added: U.todayKey(), box: 0, due: U.todayKey() };
    track("word_saved", {});
    persist();
    return true;
  }
  function removeWord(word) {
    const p = profile();
    delete p.vocab[word];
    persist();
  }
  function hasWord(word) { return !!profile().vocab[word]; }

  function reviewWord(word, remembered) {
    const p = profile();
    const item = p.vocab[word];
    if (!item) return;
    item.box = remembered ? Math.min(BOX_DAYS.length - 1, item.box + 1) : 0;
    const days = BOX_DAYS[item.box];
    const next = new Date();
    next.setDate(next.getDate() + days);
    item.due = U.todayKey(next);
    persist();
  }

  function dueWords() {
    const p = profile();
    const today = U.todayKey();
    return Object.keys(p.vocab).filter(w => p.vocab[w].due <= today);
  }

  /* ---------------- Bookmarks ---------------- */
  function toggleBookmark(id) {
    const p = profile();
    const i = p.bookmarks.indexOf(id);
    if (i === -1) p.bookmarks.push(id); else p.bookmarks.splice(i, 1);
    persist();
    return p.bookmarks.indexOf(id) !== -1;
  }
  function isBookmarked(id) { return profile().bookmarks.indexOf(id) !== -1; }

  /* ---------------- Achievements ---------------- */
  function checkAchievements() {
    const p = profile();
    const s = stats();
    const questionsAnswered = (p.attempts || []).reduce((n, a) => n + (a.total || 0), 0);
    const gained = [];

    TLA.data.achievements.forEach(function (a) {
      if (p.achievements.indexOf(a.id) !== -1) return;
      const c = a.cond;
      let ok = false;
      if (c.lessons) ok = s.lessons >= c.lessons;
      else if (c.attempts) ok = s.tests >= c.attempts;
      else if (c.streak) ok = s.streak >= c.streak;
      else if (c.questions) ok = questionsAnswered >= c.questions;
      else if (c.skill) ok = (p.skills[c.skill] || 0) >= c.score;
      else if (c.mockScore) ok = (p.attempts || []).some(x => x.kind === "mock" && x.score >= c.mockScore);
      else if (c.courseDone) ok = TLA.data.courses.some(cc => courseProgress(cc.id).pct === 100);
      if (ok) { p.achievements.push(a.id); gained.push(a); }
    });

    gained.forEach(function (a) {
      notify("achievement", "Yangi yutuq: " + a.uz, "Tabriklaymiz! Yutuq profilingizga qo‘shildi.");
      if (TLA.ui && TLA.ui.toast) TLA.ui.toast(a.uz, "xp");
    });
    return gained;
  }

  function hasAchievement(id) { return profile().achievements.indexOf(id) !== -1; }

  /* ---------------- Certificates ---------------- */
  function nextCertId() {
    data.admin.certCounter = (data.admin.certCounter || 0) + 1;
    const prefix = (data.config.certificatePrefix || "TLA");
    const year = new Date().getFullYear();
    return prefix + "-" + year + "-" + String(data.admin.certCounter).padStart(4, "0");
  }

  function issueCertificate(payload) {
    const p = profile();
    const u = currentUser();
    const cert = {
      id: nextCertId(),
      name: u ? u.name : "Mehmon",
      titleUz: payload.titleUz,
      level: payload.level || "",
      score: payload.score || null,
      issued: new Date().toISOString(),
      kind: payload.kind || "course"
    };
    p.certificates.push(cert);
    track("certificate_earned", { kind: cert.kind });
    notify("certificate", "Sertifikat berildi", cert.titleUz + " — " + cert.id);
    persist();
    return cert;
  }

  function maybeIssueCertificate(attempt) {
    if (!isAuthed()) return;
    const p = profile();
    if (attempt.kind === "mock" && attempt.score >= 80) {
      const already = p.certificates.some(c => c.kind === "mock" && c.titleUz === attempt.titleUz);
      if (!already) issueCertificate({ titleUz: attempt.titleUz, level: attempt.level, score: attempt.score, kind: "mock" });
    }
    TLA.data.courses.forEach(function (c) {
      if (courseProgress(c.id).pct === 100) {
        const already = p.certificates.some(x => x.kind === "course" && x.titleUz === c.titleUz);
        if (!already) issueCertificate({ titleUz: c.titleUz, level: c.code, kind: "course" });
      }
    });
  }

  function findCertificate(id) {
    const wanted = String(id).trim().toUpperCase();
    let found = null;
    Object.keys(data.profiles).forEach(function (uid) {
      (data.profiles[uid].certificates || []).forEach(function (c) {
        if (c.id.toUpperCase() === wanted) found = c;
      });
    });
    (data.guest.certificates || []).forEach(function (c) {
      if (c.id.toUpperCase() === wanted) found = c;
    });
    return found;
  }

  /* ---------------- Daily tasks ---------------- */
  function taskState() {
    const p = profile();
    const today = U.todayKey();
    if (!p.tasks[today]) p.tasks[today] = {};
    // keep only the last 30 days
    const keys = Object.keys(p.tasks).sort();
    if (keys.length > 30) keys.slice(0, keys.length - 30).forEach(k => delete p.tasks[k]);
    return p.tasks[today];
  }
  function completeTask(key) {
    const t = taskState();
    if (t[key]) return false;
    t[key] = true;
    addXp(5, "task");
    touchStreak();
    persist();
    return true;
  }

  /* ---------------- Plans & payments ---------------- */
  function plans() { return data.plans; }
  function setPlanPrice(planId, price) {
    const plan = data.plans.filter(p => p.id === planId)[0];
    if (plan) { plan.price = Math.max(0, Number(price) || 0); persist(); }
  }
  function currentPlan() { return profile().plan || "free"; }

  function recordPayment(planId, method) {
    const p = profile();
    const plan = data.plans.filter(x => x.id === planId)[0];
    const pay = {
      id: U.uid("pay"),
      planId: planId,
      planName: plan ? plan.uz : planId,
      amount: plan ? plan.price : 0,
      method: method,
      status: "paid",
      at: new Date().toISOString(),
      demo: true
    };
    p.payments.push(pay);
    p.plan = planId;
    track("purchase_completed", { plan: planId, method: method });
    notify("payment", "To‘lov qabul qilindi (demo)", (plan ? plan.uz : planId) + " tarifi faollashtirildi.");
    persist();
    return pay;
  }

  function allPayments() {
    const out = [];
    Object.keys(data.profiles).forEach(function (uid) {
      const user = data.users.filter(u => u.id === uid)[0];
      (data.profiles[uid].payments || []).forEach(function (p) {
        out.push(Object.assign({ user: user ? user.name : "—" }, p));
      });
    });
    return out.sort((a, b) => (a.at < b.at ? 1 : -1));
  }

  /* ---------------- Notifications ---------------- */
  function notify(type, title, body) {
    data.notifications.unshift({
      id: U.uid("n"), type: type, title: title, body: body,
      at: new Date().toISOString(), read: false
    });
    if (data.notifications.length > 40) data.notifications.length = 40;
    persist();
  }
  function notifications() { return data.notifications; }
  function unreadCount() { return data.notifications.filter(n => !n.read).length; }
  function markAllRead() {
    data.notifications.forEach(n => { n.read = true; });
    persist();
  }

  /* ---------------- Analytics (local, no PII) ---------------- */
  function track(event, props) {
    if (!data.settings.analytics) return;
    data.analytics.push({ e: event, t: Date.now(), p: props || {} });
    if (data.analytics.length > 500) data.analytics = data.analytics.slice(-500);
  }
  function analyticsSummary() {
    const counts = {};
    data.analytics.forEach(a => { counts[a.e] = (counts[a.e] || 0) + 1; });
    return counts;
  }

  /* ---------------- Search history ---------------- */
  function addSearch(term) {
    if (!term) return;
    data.recentSearches = [term].concat(data.recentSearches.filter(t => t !== term)).slice(0, 6);
    persist();
  }
  function recentSearches() { return data.recentSearches; }

  /* ---------------- Config & admin ---------------- */
  function config() { return data.config; }
  function setConfig(path, value) {
    const parts = path.split(".");
    let node = data.config;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!node[parts[i]]) node[parts[i]] = {};
      node = node[parts[i]];
    }
    node[parts[parts.length - 1]] = value;
    persist();
  }

  function allUsers() { return data.users; }
  function profileOf(userId) { return data.profiles[userId] || blankProfile(); }
  function setUserRole(userId, role) {
    const u = data.users.filter(x => x.id === userId)[0];
    if (u) { u.role = role; persist(); }
  }
  function removeUser(userId) {
    data.users = data.users.filter(u => u.id !== userId);
    delete data.profiles[userId];
    if (data.session.userId === userId) data.session.userId = null;
    persist();
  }

  function extraQuestions() { return data.admin.extraQuestions; }
  function addQuestion(q) {
    q.id = q.id || U.uid("q");
    q.custom = true;
    data.admin.extraQuestions.push(q);
    TLA.data.questions.push(q);
    persist();
    return q;
  }
  function removeQuestion(id) {
    data.admin.extraQuestions = data.admin.extraQuestions.filter(q => q.id !== id);
    const i = TLA.data.questions.findIndex(q => q.id === id);
    if (i > -1) TLA.data.questions.splice(i, 1);
    persist();
  }

  function teachers() { return data.admin.teachers; }
  function addTeacher(t) {
    t.id = U.uid("t");
    data.admin.teachers.push(t);
    persist();
    return t;
  }
  function removeTeacher(id) {
    data.admin.teachers = data.admin.teachers.filter(t => t.id !== id);
    persist();
  }

  function exportData() {
    const u = currentUser();
    return JSON.stringify({
      exportedAt: new Date().toISOString(),
      user: u ? { name: u.name, email: u.email, role: u.role } : null,
      profile: profile(),
      settings: data.settings
    }, null, 2);
  }

  async function wipe() {
    await TLA.store.clear();
    data = defaults();
    persist();
  }

  /* Load custom questions saved by an admin back into the bank. */
  function hydrateCustomQuestions() {
    (data.admin.extraQuestions || []).forEach(function (q) {
      if (!TLA.data.questions.some(x => x.id === q.id)) TLA.data.questions.push(q);
    });
  }

  return {
    init, onChange, raw: () => data, hydrateCustomQuestions,
    currentUser, isAuthed, isAdmin, profile, register, login, logout, restoreSession, updateUser, deleteAccount,
    settings, setSetting, setNotifPref,
    touchStreak, addXp, xpToday,
    completeLesson, lessonDone, courseProgress,
    recordAttempt, attempts, attemptById, attemptsFor, stats,
    saveWord, removeWord, hasWord, reviewWord, dueWords,
    toggleBookmark, isBookmarked,
    checkAchievements, hasAchievement,
    issueCertificate, findCertificate,
    taskState, completeTask,
    plans, setPlanPrice, currentPlan, recordPayment, allPayments,
    notify, notifications, unreadCount, markAllRead,
    track, analyticsSummary,
    addSearch, recentSearches,
    config, setConfig,
    allUsers, profileOf, setUserRole, removeUser,
    extraQuestions, addQuestion, removeQuestion,
    teachers, addTeacher, removeTeacher,
    exportData, wipe
  };
})();
