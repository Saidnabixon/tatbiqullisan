/* ============================================================
   PAGE — Admin panel
   Content and platform management. Everything an operator would
   otherwise be tempted to hard-code (contacts, teachers, prices)
   is editable here instead of invented in the markup.
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  const TABS = [
    { id: "overview", label: "Umumiy" },
    { id: "users", label: "Foydalanuvchilar" },
    { id: "questions", label: "Savollar bazasi" },
    { id: "content", label: "Kontent" },
    { id: "teachers", label: "O‘qituvchilar" },
    { id: "payments", label: "To‘lovlar" },
    { id: "analytics", label: "Analitika" },
    { id: "settings", label: "Sozlamalar" }
  ];

  function statTile(label, value, sub) {
    return '<div class="stat-tile"><div class="k">' + U.esc(label) + '</div><div class="v">' + value + "</div>" +
      (sub ? '<div class="d">' + U.esc(sub) + "</div>" : "") + "</div>";
  }

  /* ---------------- Tab renderers ---------------- */
  const views = {
    overview: function () {
      const users = TLA.state.allUsers();
      const payments = TLA.state.allPayments();
      const revenue = payments.reduce((n, p) => n + (p.amount || 0), 0);
      const totalLessons = TLA.data.courses.reduce((n, c) => n + c.lessons, 0);
      const counts = TLA.state.analyticsSummary();

      return '<div class="grid grid-4" style="gap:var(--sp-3)">' +
        statTile("Foydalanuvchilar", users.length, "ro‘yxatdan o‘tgan") +
        statTile("Kurslar", TLA.data.courses.length, totalLessons + " dars") +
        statTile("Savollar", TLA.data.questions.length, TLA.state.extraQuestions().length + " qo‘shilgan") +
        statTile("Testlar", TLA.data.tests.length, "to‘plam") +
        "</div>" +
        '<div class="grid grid-2" style="margin-top:var(--sp-6)">' +
        '<div class="card"><h3>Hodisalar statistikasi</h3>' +
        (Object.keys(counts).length
          ? '<div class="table-wrap" style="margin-top:var(--sp-4)"><table class="tbl"><tbody>' +
            Object.keys(counts).sort((a, b) => counts[b] - counts[a]).map(k =>
              "<tr><th>" + U.esc(k) + "</th><td>" + counts[k] + "</td></tr>").join("") +
            "</tbody></table></div>"
          : '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm)">Hali hodisa qayd etilmagan.</p>') +
        '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-3)">Hodisalar anonim: foydalanuvchi identifikatori yozilmaydi.</p></div>' +
        '<div class="card"><h3>To‘lovlar (demo)</h3>' +
        '<div class="grid grid-2" style="gap:var(--sp-3);margin-top:var(--sp-4)">' +
        statTile("Tranzaksiyalar", payments.length, "demo rejim") +
        statTile("Summa", U.fmtNumber(revenue), TLA.state.config().currency) +
        "</div>" +
        TLA.ui.complianceNote("Demo to‘lovlar haqiqiy pul harakatini bildirmaydi.") + "</div>" +
        "</div>" +
        '<div class="card" style="margin-top:var(--sp-6)"><h3>Tezkor amallar</h3>' +
        '<div class="row row-wrap" style="gap:var(--sp-3);margin-top:var(--sp-4)">' +
        '<a class="btn btn-soft btn-sm" href="#/admin?tab=questions">Savol qo‘shish</a>' +
        '<a class="btn btn-soft btn-sm" href="#/admin?tab=teachers">O‘qituvchi qo‘shish</a>' +
        '<a class="btn btn-soft btn-sm" href="#/admin?tab=settings">Kontaktlarni to‘ldirish</a>' +
        '<a class="btn btn-soft btn-sm" href="#/admin?tab=payments">Narxlarni o‘zgartirish</a>' +
        "</div></div>";
    },

    users: function () {
      const users = TLA.state.allUsers();
      if (!users.length) {
        return TLA.ui.emptyState("◐", "Foydalanuvchilar yo‘q", "Birinchi ro‘yxatdan o‘tgan foydalanuvchi avtomatik administrator bo‘ladi.");
      }
      return '<div class="card"><div class="row-between" style="margin-bottom:var(--sp-4)">' +
        "<h3>Foydalanuvchilar (" + users.length + ")</h3></div>" +
        '<div class="table-wrap"><table class="tbl"><thead><tr>' +
        "<th>Ism</th><th>Email</th><th>Rol</th><th>XP</th><th>Testlar</th><th style='text-align:end'>Amallar</th>" +
        "</tr></thead><tbody>" +
        users.map(function (u) {
          const p = TLA.state.profileOf(u.id);
          return "<tr><td>" + U.esc(u.name) + "</td><td>" + U.esc(u.email) + "</td>" +
            '<td><select class="select" data-role="' + u.id + '" style="min-width:120px;padding:6px 10px">' +
            ["student", "teacher", "admin"].map(r => '<option value="' + r + '"' + (u.role === r ? " selected" : "") + ">" + r + "</option>").join("") +
            "</select></td>" +
            "<td>" + U.fmtNumber(p.xp || 0) + "</td><td>" + (p.attempts || []).length + "</td>" +
            '<td style="text-align:end"><button class="btn btn-quiet btn-sm" data-del-user="' + u.id + '">' + t("action.delete") + "</button></td></tr>";
        }).join("") +
        "</tbody></table></div>" +
        TLA.ui.complianceNote("Demo rejimda ma’lumotlar shu qurilmada saqlanadi. Ishlab chiqarishda rollar serverda tekshiriladi — frontend roli hech qachon yagona himoya bo‘lmasligi kerak.") +
        "</div>";
    },

    questions: function () {
      const custom = TLA.state.extraQuestions();
      const stats = TLA.engine.questionStats().slice(0, 10);

      return '<div class="card"><h3>Yangi savol qo‘shish</h3>' +
        '<form id="qForm" style="margin-top:var(--sp-4)">' +
        '<div class="grid grid-2" style="gap:var(--sp-4)">' +
        '<label class="field"><span class="label">Daraja</span><select class="select" name="level">' +
        TLA.data.levels.map(l => '<option value="' + l.id + '">' + l.code + "</option>").join("") + "</select></label>" +
        '<label class="field"><span class="label">Ko‘nikma</span><select class="select" name="skill">' +
        ["grammar", "vocabulary"].map(s => '<option value="' + s + '">' + t("misc.skill." + s) + "</option>").join("") + "</select></label>" +
        "</div>" +
        '<label class="field"><span class="label">Savol matni (o‘zbekcha)</span><input class="input" name="promptUz" required></label>' +
        '<label class="field"><span class="label">Arabcha qism (ixtiyoriy)</span><input class="input ar-input" name="ar" dir="rtl"></label>' +
        '<div class="grid grid-2" style="gap:var(--sp-3)">' +
        [0, 1, 2, 3].map(i => '<label class="field"><span class="label">Variant ' + String.fromCharCode(65 + i) +
          (i === 0 ? " (to‘g‘ri javob)" : "") + '</span><input class="input" name="opt' + i + '" required></label>').join("") +
        "</div>" +
        '<label class="check"><input type="checkbox" name="optsAr"><span>Variantlar arab tilida</span></label>' +
        '<label class="field" style="margin-top:var(--sp-3)"><span class="label">Izoh (nega shu javob to‘g‘ri)</span>' +
        '<textarea class="textarea" name="expUz" style="min-height:90px" required></textarea></label>' +
        '<button class="btn btn-primary" type="submit" style="margin-top:var(--sp-4)">Savolni qo‘shish</button>' +
        '<p class="field-hint">Variantlar test paytida avtomatik aralashtiriladi, shuning uchun birinchi variantni to‘g‘ri javob sifatida kiriting.</p>' +
        "</form></div>" +

        '<div class="card" style="margin-top:var(--sp-6)"><h3>Qo‘shilgan savollar (' + custom.length + ")</h3>" +
        (custom.length
          ? '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
            custom.map(q => '<div class="row-between" style="padding:var(--sp-3);background:var(--surface-2);border-radius:var(--r-sm)">' +
              '<span style="min-width:0"><strong style="font-size:var(--fs-sm)">' + U.esc(q.promptUz) + "</strong><br>" +
              '<span class="muted" style="font-size:var(--fs-2xs)">' + q.level.toUpperCase() + " · " + t("misc.skill." + q.skill) + "</span></span>" +
              '<button class="btn btn-quiet btn-sm" data-del-q="' + q.id + '">' + t("action.delete") + "</button></div>").join("") +
            "</div>"
          : '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm)">Hali savol qo‘shilmagan. Bazadagi ' +
            TLA.data.questions.length + " ta savol o‘zgarishsiz ishlaydi.</p>") +
        "</div>" +

        '<div class="card" style="margin-top:var(--sp-6)"><h3>Eng qiyin savollar</h3>' +
        '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-2)">To‘g‘ri javob ulushi (p-qiymat) past bo‘lgan savollar — matn yoki variantlarni qayta ko‘rib chiqish tavsiya etiladi.</p>' +
        (stats.length
          ? '<div class="table-wrap" style="margin-top:var(--sp-4)"><table class="tbl"><thead><tr>' +
            "<th>Savol</th><th>Daraja</th><th>Urinish</th><th>To‘g‘ri %</th></tr></thead><tbody>" +
            stats.map(s => "<tr><td>" + U.esc(String(s.promptUz).slice(0, 60)) + "</td><td>" + String(s.level).toUpperCase() +
              "</td><td>" + s.n + '</td><td><span class="badge ' + (s.pValue < 40 ? "badge-red" : "badge-jade") + '">' +
              s.pValue + "%</span></td></tr>").join("") +
            "</tbody></table></div>"
          : '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm)">Statistika testlar topshirilgach shakllanadi.</p>') +
        "</div>";
    },

    content: function () {
      return '<div class="grid grid-2">' +
        '<div class="card"><h3>Kurslar</h3>' +
        '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
        TLA.data.courses.map(c => '<div class="row-between" style="padding:var(--sp-3);background:var(--surface-2);border-radius:var(--r-sm)">' +
          "<span>" + TLA.ui.levelPill(c.code) + " " + U.esc(c.titleUz) + "</span>" +
          '<span class="muted" style="font-size:var(--fs-2xs)">' + c.lessons + " dars · " + c.modules.length + " modul</span></div>").join("") +
        "</div>" +
        '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-4)">Kurs tuzilmasi kontent fayllarida saqlanadi. Backend ulangach, bu ro‘yxat CRUD interfeysига aylanadi.</p></div>' +

        '<div class="card"><h3>Kutubxona</h3>' +
        '<div class="stack-sm" style="margin-top:var(--sp-4);max-height:340px;overflow:auto">' +
        TLA.data.library.map(r => '<div class="row-between" style="padding:var(--sp-3);background:var(--surface-2);border-radius:var(--r-sm)">' +
          '<span style="min-width:0"><strong style="font-size:var(--fs-sm)">' + U.esc(r.titleUz) + "</strong><br>" +
          '<span class="muted" style="font-size:var(--fs-2xs)">' + r.type + " · " + r.level.toUpperCase() + "</span></span>" +
          (r.free ? '<span class="badge badge-free">' + t("misc.free") + "</span>" : '<span class="badge badge-gold">' + t("misc.premium") + "</span>") +
          "</div>").join("") +
        "</div></div>" +

        '<div class="card"><h3>Blog</h3>' +
        '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
        TLA.data.blog.map(b => '<div class="row-between" style="padding:var(--sp-3);background:var(--surface-2);border-radius:var(--r-sm)">' +
          '<span style="min-width:0"><strong style="font-size:var(--fs-sm)">' + U.esc(b.titleUz) + "</strong><br>" +
          '<span class="muted" style="font-size:var(--fs-2xs)">' + U.esc(b.cat) + " · " + U.fmtDate(b.date, "uz") + "</span></span>" +
          '<a class="btn btn-quiet btn-sm" href="#/blog/' + b.slug + '">' + t("action.open") + "</a></div>").join("") +
        "</div></div>" +

        '<div class="card"><h3>Testlar</h3>' +
        '<div class="grid grid-2" style="gap:var(--sp-3);margin-top:var(--sp-4)">' +
        TLA.data.examTracks.map(e => statTile(e.uz, TLA.data.testsByTrack(e.id).length, "test")).join("") +
        "</div>" +
        '<a class="btn btn-ghost btn-sm btn-block" style="margin-top:var(--sp-4)" href="#/tests">Testlar katalogi</a></div>' +
        "</div>";
    },

    teachers: function () {
      const list = TLA.state.teachers();
      return '<div class="card"><h3>O‘qituvchi qo‘shish</h3>' +
        '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-2)">Faqat haqiqiy ma’lumot kiriting. Tasdiqlanmagan malaka yoki diplom haqidagi da’volar joylashtirilmasligi kerak.</p>' +
        '<form id="teacherForm" style="margin-top:var(--sp-4)">' +
        '<div class="grid grid-2" style="gap:var(--sp-4)">' +
        '<label class="field"><span class="label">Ism familiya</span><input class="input" name="name" required></label>' +
        '<label class="field"><span class="label">Lavozim</span><input class="input" name="title" placeholder="masalan: Arab tili o‘qituvchisi"></label>' +
        "</div>" +
        '<label class="field"><span class="label">Qisqacha ma’lumot</span><textarea class="textarea" name="bio" style="min-height:90px"></textarea></label>' +
        '<label class="field"><span class="label">Tillar (vergul bilan)</span><input class="input" name="languages" placeholder="Arabcha, O‘zbekcha, Inglizcha"></label>' +
        '<button class="btn btn-primary" type="submit" style="margin-top:var(--sp-4)">Qo‘shish</button>' +
        "</form></div>" +
        '<div class="card" style="margin-top:var(--sp-6)"><h3>Ro‘yxat (' + list.length + ")</h3>" +
        (list.length
          ? '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
            list.map(x => '<div class="row-between" style="padding:var(--sp-3);background:var(--surface-2);border-radius:var(--r-sm)">' +
              '<span><strong style="font-size:var(--fs-sm)">' + U.esc(x.name) + "</strong><br>" +
              '<span class="muted" style="font-size:var(--fs-2xs)">' + U.esc(x.title || "") + "</span></span>" +
              '<button class="btn btn-quiet btn-sm" data-del-teacher="' + x.id + '">' + t("action.delete") + "</button></div>").join("") +
            "</div>"
          : '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm)">Hozircha bo‘sh. Saytdagi «O‘qituvchilar» sahifasi ham bo‘sh holatni ko‘rsatadi — o‘ylab topilgan profillar yaratilmaydi.</p>') +
        "</div>";
    },

    payments: function () {
      const payments = TLA.state.allPayments();
      const plans = TLA.state.plans();
      const currency = TLA.state.config().currency;

      return '<div class="card"><h3>Tarif narxlari</h3>' +
        '<div class="grid grid-2" style="gap:var(--sp-4);margin-top:var(--sp-4)">' +
        plans.map(p => '<label class="field"><span class="label">' + U.esc(p.uz) + " (" + currency + ")</span>" +
          '<input class="input" type="number" min="0" step="1000" data-price="' + p.id + '" value="' + p.price + '"></label>').join("") +
        "</div>" +
        '<button class="btn btn-primary" id="savePrices" style="margin-top:var(--sp-3)">' + t("action.save") + "</button>" +
        '<p class="field-hint">Narxlar «Narxlar» sahifasida darhol yangilanadi.</p></div>' +

        '<div class="card" style="margin-top:var(--sp-6)"><h3>Tranzaksiyalar (' + payments.length + ")</h3>" +
        (payments.length
          ? '<div class="table-wrap" style="margin-top:var(--sp-4)"><table class="tbl"><thead><tr>' +
            "<th>Sana</th><th>Foydalanuvchi</th><th>Tarif</th><th>Summa</th><th>Usul</th><th>Holat</th></tr></thead><tbody>" +
            payments.map(p => "<tr><td>" + U.fmtDate(p.at, "uz") + "</td><td>" + U.esc(p.user) + "</td>" +
              "<td>" + U.esc(p.planName) + "</td><td>" + U.fmtNumber(p.amount) + "</td><td>" + U.esc(p.method) + "</td>" +
              '<td><span class="badge badge-jade">' + U.esc(p.status) + " (demo)</span></td></tr>").join("") +
            "</tbody></table></div>"
          : '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm)">Hali to‘lov qayd etilmagan.</p>') +
        TLA.ui.complianceNote("To‘lov provayderi kalitlari faqat serverda saqlanadi. Bu panel demo tranzaksiyalarni ko‘rsatadi.") +
        "</div>";
    },

    analytics: function () {
      const counts = TLA.state.analyticsSummary();
      const users = TLA.state.allUsers();
      const levelDist = {};
      users.forEach(function (u) {
        const p = TLA.state.profileOf(u.id);
        if (p.level) levelDist[p.level] = (levelDist[p.level] || 0) + 1;
      });
      const series = TLA.data.levels.map(l => ({ label: l.code, value: levelDist[l.id] || 0 }));
      const maxUsers = Math.max(1, Math.max.apply(null, series.map(s => s.value)));

      return '<div class="grid grid-2">' +
        '<div class="card"><h3>Foydalanuvchilar darajasi</h3>' +
        '<div style="margin-top:var(--sp-4)">' + TLA.charts.bars(series, { max: maxUsers }) + "</div></div>" +
        '<div class="card"><h3>Hodisalar</h3>' +
        (Object.keys(counts).length
          ? '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
            Object.keys(counts).sort((a, b) => counts[b] - counts[a]).slice(0, 10).map(function (k) {
              const max = Math.max.apply(null, Object.keys(counts).map(x => counts[x]));
              return '<div class="meter-row"><span class="lbl">' + U.esc(k) + '</span><span class="val">' + counts[k] +
                '</span><span class="progress"><span style="width:' + U.pct(counts[k], max) + '%"></span></span></div>';
            }).join("") + "</div>"
          : '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm)">Hodisalar hali yozilmagan.</p>') +
        "</div></div>" +
        '<div class="card" style="margin-top:var(--sp-6)"><h3>Savol sifati</h3>' +
        '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-2)">Savollar bazasi bo‘limida p-qiymat bo‘yicha to‘liq ro‘yxat mavjud.</p>' +
        '<a class="btn btn-ghost btn-sm" style="margin-top:var(--sp-4)" href="#/admin?tab=questions">Ochish</a></div>';
    },

    settings: function () {
      const cfg = TLA.state.config();
      const field = (path, label, value, type, placeholder) =>
        '<label class="field"><span class="label">' + U.esc(label) + "</span>" +
        '<input class="input" type="' + (type || "text") + '" data-cfg="' + path + '" value="' + U.attr(value || "") +
        '" placeholder="' + U.attr(placeholder || "") + '"></label>';

      return '<div class="card"><h3>Kontakt ma’lumotlari</h3>' +
        '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-2)">Bu maydonlar «Aloqa» sahifasi va footerda ko‘rsatiladi. Bo‘sh qoldirilsa, sayt «admin panelda kiritiladi» deb yozadi — soxta raqam yoki manzil hech qachon ko‘rsatilmaydi.</p>' +
        '<div class="grid grid-2" style="gap:var(--sp-4);margin-top:var(--sp-4)">' +
        field("contact.phone", "Telefon", cfg.contact.phone, "tel", "+998 ...") +
        field("contact.email", "Email", cfg.contact.email, "email", "info@...") +
        field("contact.telegram", "Telegram havolasi", cfg.contact.telegram, "url", "https://t.me/...") +
        field("contact.address", "Manzil", cfg.contact.address) +
        field("contact.workHours", "Ish vaqti", cfg.contact.workHours, "text", "Du–Sha 09:00–18:00") +
        "</div></div>" +

        '<div class="card" style="margin-top:var(--sp-6)"><h3>Ijtimoiy tarmoqlar</h3>' +
        '<div class="grid grid-2" style="gap:var(--sp-4);margin-top:var(--sp-4)">' +
        field("social.telegram", "Telegram kanal", cfg.social.telegram, "url") +
        field("social.instagram", "Instagram", cfg.social.instagram, "url") +
        field("social.youtube", "YouTube", cfg.social.youtube, "url") +
        "</div></div>" +

        '<div class="card" style="margin-top:var(--sp-6)"><h3>Umumiy</h3>' +
        '<div class="grid grid-2" style="gap:var(--sp-4);margin-top:var(--sp-4)">' +
        field("currency", "Valyuta belgisi", cfg.currency) +
        field("certificatePrefix", "Sertifikat prefiksi", cfg.certificatePrefix, "text", "TLA") +
        field("verifyBaseUrl", "Tekshirish URL asosi", cfg.verifyBaseUrl, "url") +
        "</div>" +
        '<button class="btn btn-primary" id="saveCfg" style="margin-top:var(--sp-4)">' + t("action.save") + "</button>" +
        '<p class="field-hint">Tekshirish URL sertifikatdagi QR kodga yoziladi.</p></div>';
    }
  };

  /* ---------------- Page ---------------- */
  TLA.pages.admin = {
    render: function (params) {
      if (!TLA.state.isAuthed()) {
        return TLA.ui.pageHead({ title: t("nav.admin") }) +
          '<section class="section"><div class="container container-narrow">' +
          TLA.ui.emptyState("◍", t("auth.needAuth"), t("admin.roleNote"),
            '<button class="btn btn-primary" data-action="auth-login">' + t("action.login") + "</button>") +
          "</div></section>";
      }
      if (!TLA.state.isAdmin()) {
        return TLA.ui.pageHead({ title: t("nav.admin") }) +
          '<section class="section"><div class="container container-narrow">' +
          TLA.ui.emptyState("⚿", "Ruxsat yo‘q", t("admin.roleNote"),
            '<a class="btn btn-ghost" href="#/dashboard">' + t("nav.dashboard") + "</a>") +
          "</div></section>";
      }

      const active = params.query.tab && views[params.query.tab] ? params.query.tab : "overview";

      return TLA.ui.pageHead({
        eyebrow: t("nav.admin"),
        title: t("admin.title"),
        lead: "Kontent, foydalanuvchilar va platforma sozlamalarini boshqarish."
      }) +
        '<section class="section"><div class="container">' +
        '<div class="alert alert-info" style="margin-bottom:var(--sp-5)"><span class="ico">◈</span><span>' +
        t("admin.demoNote") + "</span></div>" +
        '<div class="tabs" style="margin-bottom:var(--sp-6)">' +
        TABS.map(x => '<a class="tab" href="#/admin?tab=' + x.id + '" aria-selected="' + (x.id === active) + '">' +
          U.esc(x.label) + "</a>").join("") +
        "</div>" +
        '<div id="adminPanel">' + views[active]() + "</div>" +
        "</div></section>";
    },

    mounted: function (params) {
      if (!TLA.state.isAdmin()) return;
      const active = params.query.tab && views[params.query.tab] ? params.query.tab : "overview";

      if (active === "users") {
        U.$$("[data-role]").forEach(function (sel) {
          sel.addEventListener("change", function () {
            TLA.state.setUserRole(sel.dataset.role, sel.value);
            TLA.ui.toast("Rol yangilandi.", "success");
            TLA.ui.renderHeader();
          });
        });
        U.$$("[data-del-user]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            TLA.ui.confirmDialog("Foydalanuvchini o‘chirish", "Bu amalni bekor qilib bo‘lmaydi.", t("action.delete"), function () {
              TLA.state.removeUser(btn.dataset.delUser);
              TLA.router.rerender();
              TLA.ui.toast("O‘chirildi.", "info");
            }, true);
          });
        });
      }

      if (active === "questions") {
        const form = U.$("#qForm");
        if (form) {
          form.addEventListener("submit", function (ev) {
            ev.preventDefault();
            const fd = new FormData(form);
            const opts = [0, 1, 2, 3].map(i => (fd.get("opt" + i) || "").toString().trim());
            if (opts.some(o => !o)) return TLA.ui.toast("Barcha variantlarni to‘ldiring.", "error");
            TLA.state.addQuestion({
              type: "mcq",
              level: fd.get("level"),
              skill: fd.get("skill"),
              topic: "custom",
              diff: "medium",
              promptUz: (fd.get("promptUz") || "").toString().trim(),
              ar: (fd.get("ar") || "").toString().trim(),
              opts: opts,
              optsAr: !!fd.get("optsAr"),
              ans: 0,
              expUz: (fd.get("expUz") || "").toString().trim(),
              tags: ["custom"]
            });
            TLA.ui.toast("Savol qo‘shildi.", "success");
            TLA.router.rerender();
          });
        }
        U.$$("[data-del-q]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            TLA.state.removeQuestion(btn.dataset.delQ);
            TLA.router.rerender();
            TLA.ui.toast("Savol o‘chirildi.", "info");
          });
        });
      }

      if (active === "teachers") {
        const form = U.$("#teacherForm");
        if (form) {
          form.addEventListener("submit", function (ev) {
            ev.preventDefault();
            const fd = new FormData(form);
            const name = (fd.get("name") || "").toString().trim();
            if (name.length < 2) return TLA.ui.toast("Ismni kiriting.", "error");
            TLA.state.addTeacher({
              name: name,
              title: (fd.get("title") || "").toString().trim(),
              bio: (fd.get("bio") || "").toString().trim(),
              languages: (fd.get("languages") || "").toString().trim()
            });
            TLA.ui.toast("O‘qituvchi qo‘shildi.", "success");
            TLA.router.rerender();
          });
        }
        U.$$("[data-del-teacher]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            TLA.state.removeTeacher(btn.dataset.delTeacher);
            TLA.router.rerender();
          });
        });
      }

      if (active === "payments") {
        const save = U.$("#savePrices");
        if (save) {
          save.addEventListener("click", function () {
            U.$$("[data-price]").forEach(function (input) {
              TLA.state.setPlanPrice(input.dataset.price, input.value);
            });
            TLA.ui.toast("Narxlar saqlandi.", "success");
          });
        }
      }

      if (active === "settings") {
        const save = U.$("#saveCfg");
        if (save) {
          save.addEventListener("click", function () {
            U.$$("[data-cfg]").forEach(function (input) {
              TLA.state.setConfig(input.dataset.cfg, input.value.trim());
            });
            TLA.ui.toast("Sozlamalar saqlandi.", "success");
            TLA.ui.renderFooter();
          });
        }
      }
    },

    meta: { title: "Admin panel — Tatbiqul Lisan Academy", desc: "" }
  };
})();
