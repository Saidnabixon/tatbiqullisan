/* ============================================================
   ENGINE — test assembly, scoring, level estimation,
   recommendation logic
   ============================================================ */
window.TLA = window.TLA || {};

TLA.engine = (function () {
  "use strict";
  const U = TLA.utils;
  const ORDER = ["a1", "a2", "b1", "b2", "c1", "c2"];

  /* ---------------- Test assembly ---------------- */

  /**
   * Builds a question set for a test definition.
   * Reading/listening items stay grouped by their passage so the
   * learner never jumps between texts mid-section.
   */
  function buildTest(def, seed) {
    const rnd = U.seededRandom(seed || def.id + "-" + Date.now());
    const pool = TLA.data.questions.filter(function (q) {
      if (q.type === "writing" || q.type === "speaking") return false;
      if (def.levels && def.levels.indexOf(q.level) === -1) return false;
      if (def.skills && def.skills.indexOf(q.skill) === -1) return false;
      return true;
    });

    const perSkill = {};
    def.skills.forEach(s => { perSkill[s] = []; });
    pool.forEach(q => { if (perSkill[q.skill]) perSkill[q.skill].push(q); });

    const skills = def.skills.filter(s => perSkill[s] && perSkill[s].length);
    if (!skills.length) return [];

    const base = Math.floor(def.count / skills.length);
    let remainder = def.count - base * skills.length;
    const picked = [];

    skills.forEach(function (skill) {
      let want = base + (remainder-- > 0 ? 1 : 0);
      const list = perSkill[skill];
      if (skill === "reading" || skill === "listening") {
        // keep passages intact: take whole groups until quota is met
        const key = skill === "reading" ? "textId" : "scriptId";
        const groups = U.groupBy(list, q => q[key]);
        const groupKeys = U.shuffle(Object.keys(groups), rnd);
        groupKeys.forEach(function (gk) {
          if (want <= 0) return;
          const group = groups[gk];
          group.slice(0, Math.max(1, Math.min(group.length, want))).forEach(function (q) {
            if (want > 0) { picked.push(q); want--; }
          });
        });
      } else {
        U.shuffle(list, rnd).slice(0, want).forEach(q => picked.push(q));
      }
    });

    // order: grammar/vocabulary first, then reading, then listening
    const rank = { grammar: 0, vocabulary: 1, reading: 2, listening: 3, writing: 4, speaking: 5 };
    picked.sort(function (a, b) {
      const r = (rank[a.skill] ?? 9) - (rank[b.skill] ?? 9);
      if (r !== 0) return r;
      const ga = a.textId || a.scriptId || "";
      const gb = b.textId || b.scriptId || "";
      if (ga !== gb) return ga < gb ? -1 : 1;
      return ORDER.indexOf(a.level) - ORDER.indexOf(b.level);
    });

    // shuffle answer options while tracking the correct index
    return picked.map(function (q) {
      const idx = q.opts.map((_, i) => i);
      const shuffled = U.shuffle(idx, rnd);
      return {
        ref: q.id,
        q: q,
        optOrder: shuffled,
        correctPos: shuffled.indexOf(q.ans)
      };
    });
  }

  /** Diagnostic pulls a fixed spread across levels so the estimate is meaningful. */
  function buildDiagnostic(seed) {
    const rnd = U.seededRandom(seed || "diag-" + Date.now());
    const plan = [
      { level: "a1", n: 3 }, { level: "a2", n: 3 }, { level: "b1", n: 4 },
      { level: "b2", n: 4 }, { level: "c1", n: 3 }, { level: "c2", n: 3 }
    ];
    const picked = [];
    plan.forEach(function (slot) {
      const skillsWanted = ["grammar", "vocabulary", "reading", "listening"];
      const bucket = TLA.data.questions.filter(q =>
        q.level === slot.level && skillsWanted.indexOf(q.skill) !== -1);
      const grouped = U.groupBy(bucket, q => q.skill);
      const keys = U.shuffle(Object.keys(grouped), rnd);
      let taken = 0, ki = 0;
      while (taken < slot.n && ki < keys.length * 3) {
        const list = grouped[keys[ki % keys.length]];
        const item = list && list.length ? list.splice(Math.floor(rnd() * list.length), 1)[0] : null;
        if (item) { picked.push(item); taken++; }
        ki++;
      }
    });

    const rank = { grammar: 0, vocabulary: 1, reading: 2, listening: 3 };
    picked.sort(function (a, b) {
      const r = (rank[a.skill] ?? 9) - (rank[b.skill] ?? 9);
      if (r !== 0) return r;
      return ORDER.indexOf(a.level) - ORDER.indexOf(b.level);
    });

    return picked.map(function (q) {
      const shuffled = U.shuffle(q.opts.map((_, i) => i), rnd);
      return { ref: q.id, q: q, optOrder: shuffled, correctPos: shuffled.indexOf(q.ans) };
    });
  }

  /* ---------------- Scoring ---------------- */

  function scoreAttempt(items, answers) {
    let correct = 0;
    const bySkill = {};
    const byLevel = {};

    items.forEach(function (item, i) {
      const skill = item.q.skill;
      const level = item.q.level;
      bySkill[skill] = bySkill[skill] || { c: 0, n: 0 };
      byLevel[level] = byLevel[level] || { c: 0, n: 0 };
      bySkill[skill].n++;
      byLevel[level].n++;
      const given = answers[i];
      const ok = given !== null && given !== undefined && given === item.correctPos;
      if (ok) { correct++; bySkill[skill].c++; byLevel[level].c++; }
    });

    const skillScores = {};
    Object.keys(bySkill).forEach(function (s) {
      skillScores[s] = U.pct(bySkill[s].c, bySkill[s].n);
    });

    const levelAccuracy = {};
    Object.keys(byLevel).forEach(function (l) {
      levelAccuracy[l] = U.pct(byLevel[l].c, byLevel[l].n);
    });

    return {
      correct: correct,
      total: items.length,
      score: U.pct(correct, items.length),
      skillScores: skillScores,
      levelAccuracy: levelAccuracy
    };
  }

  /** Highest level the learner clears at ≥60%, with an overall-score fallback. */
  function estimateLevel(result) {
    const acc = result.levelAccuracy || {};
    let best = null;
    for (let i = 0; i < ORDER.length; i++) {
      const lv = ORDER[i];
      if (acc[lv] === undefined) continue;
      if (acc[lv] >= 60) best = lv;
      else if (best) break;
    }
    if (!best) {
      const s = result.score;
      if (s >= 88) best = "c1";
      else if (s >= 74) best = "b2";
      else if (s >= 58) best = "b1";
      else if (s >= 40) best = "a2";
      else best = "a1";
    }
    return best;
  }

  function bandFromScore(score) {
    if (score >= 92) return "c2";
    if (score >= 80) return "c1";
    if (score >= 66) return "b2";
    if (score >= 50) return "b1";
    if (score >= 34) return "a2";
    return "a1";
  }

  /** Per-skill CEFR estimate, never above the hardest item that skill contained. */
  function skillLevels(items, result) {
    const maxLevel = {};
    items.forEach(function (item) {
      const s = item.q.skill;
      const li = ORDER.indexOf(item.q.level);
      maxLevel[s] = Math.max(maxLevel[s] === undefined ? -1 : maxLevel[s], li);
    });
    const out = {};
    Object.keys(result.skillScores).forEach(function (s) {
      const band = ORDER.indexOf(bandFromScore(result.skillScores[s]));
      const cap = maxLevel[s] === undefined ? band : maxLevel[s];
      out[s] = ORDER[Math.max(0, Math.min(band, cap))];
    });
    return out;
  }

  function strengthsAndGaps(skillScores) {
    const entries = Object.keys(skillScores).map(k => ({ skill: k, score: skillScores[k] }));
    entries.sort((a, b) => b.score - a.score);
    const strengths = entries.filter(e => e.score >= 70).slice(0, 2);
    const gaps = entries.slice().reverse().filter(e => e.score < 75).slice(0, 2);
    return { strengths: strengths, gaps: gaps };
  }

  /* ---------------- Recommendations ---------------- */

  /**
   * Turns a skill profile into concrete next steps: lessons for the
   * weakest skills first, then a matching practice test.
   */
  function recommend(opts) {
    const o = opts || {};
    const p = TLA.state.profile();
    const skills = o.skillScores || p.skills || {};
    const level = o.level || p.level || "a1";
    const li = Math.max(0, ORDER.indexOf(level));

    const ranked = Object.keys(skills).map(k => ({ skill: k, score: skills[k] }))
      .sort((a, b) => a.score - b.score);
    const weak = ranked.length ? ranked.slice(0, 2).map(r => r.skill) : ["listening", "vocabulary"];

    const out = [];
    const course = TLA.data.courses[li];
    if (course) {
      weak.forEach(function (skill) {
        const lesson = course.modules
          .reduce((acc, m) => acc.concat(m.lessons), [])
          .filter(l => l.skill === skill && !TLA.state.lessonDone(l.id))[0];
        if (lesson) {
          out.push({
            kind: "lesson",
            titleUz: lesson.titleUz,
            metaUz: course.code + " · " + TLA.i18n.t("misc.skill." + skill),
            href: "#/lesson/" + lesson.id
          });
        }
      });
    }

    weak.forEach(function (skill) {
      const test = TLA.data.testById("darajaviy-" + ORDER[li] + "-" + skill);
      if (test) {
        out.push({
          kind: "test",
          titleUz: test.titleUz,
          metaUz: test.count + " " + TLA.i18n.t("test.questions") + " · " + test.minutes + " " + TLA.i18n.t("test.minutes"),
          href: "#/test/" + test.id
        });
      }
    });

    const due = TLA.state.dueWords();
    if (due.length) {
      out.push({
        kind: "vocab",
        titleUz: "Takrorlash: " + due.length + " ta so‘z",
        metaUz: "Intervalli takrorlash rejasi",
        href: "#/dictionary?due=1"
      });
    }

    if (out.length < 3) {
      out.push({
        kind: "test",
        titleUz: TLA.data.testById("daily-challenge").titleUz,
        metaUz: "8 savol · 8 daqiqa",
        href: "#/test/daily-challenge"
      });
    }
    return out.slice(0, 4);
  }

  /** Short Uzbek sentence explaining what to work on next. */
  function planSentence(skillScores, level) {
    const ranked = Object.keys(skillScores).map(k => ({ skill: k, score: skillScores[k] }))
      .sort((a, b) => a.score - b.score);
    if (!ranked.length) return "";
    const nextLevel = ORDER[Math.min(ORDER.length - 1, ORDER.indexOf(level) + 1)];
    const names = ranked.slice(0, 2).map(r => TLA.i18n.t("misc.skill." + r.skill));
    return "Natijangizga ko‘ra " + nextLevel.toUpperCase() + " darajasiga o‘tishdan oldin " +
      names.join(" va ") + " ko‘nikmalarini mustahkamlash tavsiya etiladi.";
  }

  /* ---------------- Question difficulty analytics ---------------- */

  /** Aggregate answer statistics — feeds the admin "hardest questions" view. */
  function questionStats() {
    const map = {};
    TLA.state.raw && null;
    const all = TLA.state.profile().attempts || [];
    all.forEach(function (a) {
      (a.detail || []).forEach(function (d) {
        map[d.ref] = map[d.ref] || { n: 0, c: 0 };
        map[d.ref].n++;
        if (d.ok) map[d.ref].c++;
      });
    });
    return Object.keys(map).map(function (ref) {
      const q = TLA.data.questionById(ref);
      return {
        id: ref,
        skill: q ? q.skill : "—",
        level: q ? q.level : "—",
        promptUz: q ? (q.promptUz || q.ar) : ref,
        n: map[ref].n,
        pValue: U.pct(map[ref].c, map[ref].n)
      };
    }).sort((a, b) => a.pValue - b.pValue);
  }

  return {
    ORDER, buildTest, buildDiagnostic, scoreAttempt, estimateLevel,
    bandFromScore, skillLevels, strengthsAndGaps, recommend, planSentence, questionStats
  };
})();
