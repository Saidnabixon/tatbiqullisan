/* ============================================================
   STORAGE — swappable persistence layer
   Order of preference:
     1. window.storage  (host-provided async key/value store)
     2. localStorage    (browser)
     3. in-memory       (always works, resets on reload)
   The rest of the app only talks to TLA.store, so replacing this
   file with real API calls is the only change needed for a backend.
   ============================================================ */
window.TLA = window.TLA || {};

TLA.store = (function () {
  "use strict";

  const KEY = "tla:v1:state";
  let driver = "memory";
  let memory = {};
  let cache = null;
  let writeTimer = null;

  function detect() {
    if (typeof window !== "undefined" && window.storage && typeof window.storage.get === "function") {
      driver = "host";
      return;
    }
    try {
      const probe = "__tla_probe__";
      window.localStorage.setItem(probe, "1");
      window.localStorage.removeItem(probe);
      driver = "local";
    } catch (e) {
      driver = "memory";
    }
  }

  async function readRaw() {
    try {
      if (driver === "host") {
        const res = await window.storage.get(KEY);
        return res && res.value ? res.value : null;
      }
      if (driver === "local") return window.localStorage.getItem(KEY);
      return memory[KEY] || null;
    } catch (e) {
      return null;
    }
  }

  async function writeRaw(text) {
    try {
      if (driver === "host") { await window.storage.set(KEY, text); return true; }
      if (driver === "local") { window.localStorage.setItem(KEY, text); return true; }
      memory[KEY] = text;
      return true;
    } catch (e) {
      memory[KEY] = text;
      return false;
    }
  }

  /** Loads persisted state once at boot. Returns a plain object. */
  async function load() {
    detect();
    const raw = await readRaw();
    if (!raw) { cache = {}; return cache; }
    try {
      const parsed = JSON.parse(raw);
      cache = parsed && typeof parsed === "object" ? parsed : {};
    } catch (e) {
      cache = {};
    }
    return cache;
  }

  /** Debounced write-through: reads stay synchronous from memory. */
  function save(state) {
    cache = state;
    if (writeTimer) clearTimeout(writeTimer);
    writeTimer = setTimeout(() => {
      writeTimer = null;
      let text;
      try { text = JSON.stringify(cache); }
      catch (e) { return; }
      writeRaw(text);
    }, 220);
  }

  async function flush() {
    if (writeTimer) { clearTimeout(writeTimer); writeTimer = null; }
    try { await writeRaw(JSON.stringify(cache || {})); } catch (e) { /* ignore */ }
  }

  async function clear() {
    cache = {};
    try {
      if (driver === "host") await window.storage.delete(KEY);
      else if (driver === "local") window.localStorage.removeItem(KEY);
      else delete memory[KEY];
    } catch (e) { /* ignore */ }
  }

  return {
    load, save, flush, clear,
    get driver() { return driver; }
  };
})();
