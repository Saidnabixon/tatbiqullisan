/* ============================================================
   PAGES — Library, dictionary, blog, free resources, pricing,
   checkout, about, contact, teachers, legal, 404
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  /* ================= Library ================= */
  const RES_ICONS = { reading: "◈", audio: "◉", video: "▶", grammar: "◆", vocabulary: "❖", exam: "★" };

  function openResource(res) {
    const locked = !res.free && !TLA.state.isAuthed();
    if (locked) {
      TLA.ui.modal("<h3>" + t("misc.locked") + "</h3>" +
        '<p class="muted" style="margin:var(--sp-3) 0 var(--sp-5)">' + t("library.needAuth") + "</p>" +
        '<div class="stack-sm"><button class="btn btn-primary btn-block" data-action="auth-register">' + t("result.gateCta") + "</button>" +
        '<button class="btn btn-ghost btn-block" data-action="auth-login">' + t("action.login") + "</button></div>",
        { label: res.titleUz });
      return;
    }

    const o = res.opens || {};
    let body = "";
    if (o.kind === "text") {
      const text = TLA.data.texts[o.id];
      body = '<h3 class="ar" style="text-align:center">' + text.titleAr + "</h3>" +
        '<p class="muted text-center" style="font-size:var(--fs-2xs);margin-top:4px">' + U.esc(text.titleUz) + "</p>" +
        '<div class="ptext" style="margin-top:var(--sp-5)">' + text.body + "</div>" +
        '<div style="margin-top:var(--sp-5);padding-top:var(--sp-4);border-top:1px dashed var(--border-strong);color:var(--ink-2);line-height:1.8">' +
        U.esc(text.uz) + "</div>" +
        '<button class="btn btn-quiet btn-sm" style="margin-top:var(--sp-4)" data-action="speak" data-text="' +
        U.attr(text.body) + '">◉ ' + t("lesson.listen") + "</button>";
    } else if (o.kind === "script") {
      const script = TLA.data.scripts[o.id];
      body = "<h3>" + U.esc(script.titleUz) + "</h3>" +
        '<p class="ar" style="text-align:center;font-size:1.3rem;margin-top:var(--sp-2)">' + script.titleAr + "</p>" +
        '<div style="margin-top:var(--sp-5)">' + TLA.widgets.audioPlayerMarkup("libAudio", { allowTranscript: true }) + "</div>" +
        '<div class="ar" style="margin-top:var(--sp-5)">' + script.body + "</div>" +
        '<p class="muted" style="margin-top:var(--sp-4);font-size:var(--fs-sm);line-height:1.7">' + U.esc(script.uz) + "</p>";
    } else if (o.kind === "grammar") {
      const g = TLA.data.grammar[o.id];
      body = "<h3>" + U.esc(g.titleUz) + "</h3>" +
        '<p class="ar ar-lg" style="margin-top:var(--sp-2)">' + g.titleAr + "</p>" +
        '<p style="margin-top:var(--sp-4);line-height:1.8;color:var(--ink-2)">' + U.esc(g.bodyUz) + "</p>" +
        '<div class="stack" style="margin-top:var(--sp-5)">' +
        g.examples.map(e => '<div class="ar-block" style="padding:var(--sp-4)"><p class="ar">' + e.ar +
          '</p><div class="translation">' + U.esc(e.uz) + "</div></div>").join("") + "</div>";
    } else if (o.kind === "dictionary") {
      body = "<h3>" + U.esc(res.titleUz) + "</h3>" +
        '<p class="muted" style="margin-top:var(--sp-3)">' + U.esc(res.descUz) + "</p>" +
        '<a class="btn btn-primary btn-block" style="margin-top:var(--sp-5)" href="#/dictionary" data-action="modal-close">' +
        t("nav.dictionary") + "</a>";
    } else {
      body = "<h3>" + U.esc(res.titleUz) + "</h3>" +
        '<p class="muted" style="margin-top:var(--sp-3);line-height:1.7">' + U.esc(res.descUz) + "</p>" +
        '<div class="alert alert-info" style="margin-top:var(--sp-5)"><span class="ico">◔</span><span>' +
        "Ushbu material fayl sifatida admin panel orqali biriktiriladi (PDF/video obyekt xotirasiga yuklanadi). " +
        "Demo rejimda biz o‘ylab topilgan havola yoki fayl ko‘rsatmaymiz.</span></div>";
    }

    TLA.ui.modal(body, { label: res.titleUz, wide: o.kind === "text" });
    if (o.kind === "script") TLA.widgets.mountAudioPlayer("libAudio", TLA.data.scripts[o.id], { allowTranscript: true });
  }

  TLA.pages.library = {
    render: function (params) {
      const q = params.query.q || "";
      const type = params.query.type || "";
      const level = params.query.level || "";
      const access = params.query.access || "";

      const list = TLA.data.library.filter(function (r) {
        if (type && r.type !== type) return false;
        if (level && r.level !== level) return false;
        if (access === "free" && !r.free) return false;
        if (access === "premium" && r.free) return false;
        if (q && !U.includesLoose(r.titleUz + " " + r.titleAr + " " + r.descUz, q)) return false;
        return true;
      });

      const chip = (label, key, value) => {
        const active = params.query[key] === value;
        const nq = Object.assign({}, params.query);
        if (active) delete nq[key]; else nq[key] = value;
        const qs = Object.keys(nq).filter(k => nq[k]).map(k => k + "=" + encodeURIComponent(nq[k])).join("&");
        return '<a class="chip' + (active ? " is-active" : "") + '" href="#/library' + (qs ? "?" + qs : "") + '">' + U.esc(label) + "</a>";
      };

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.library") }],
        eyebrow: t("nav.library"),
        title: t("library.title"),
        lead: t("library.sub")
      }) +
        '<section class="section"><div class="container">' +
        '<div class="toolbar">' +
        '<div class="search-box"><span class="search-ico">⌕</span>' +
        '<input class="input" id="libSearch" placeholder="' + U.attr(t("library.search")) + '" value="' + U.attr(q) + '"></div>' +
        '<a class="btn btn-ghost btn-sm" href="#/library">' + t("action.reset") + "</a></div>" +

        '<div class="filter-row" style="margin-bottom:var(--sp-4)">' +
        [["reading", t("library.books")], ["audio", t("library.audio")], ["video", t("library.video")],
        ["grammar", t("library.grammar")], ["vocabulary", t("library.vocab")], ["exam", t("library.exam")]]
          .map(x => chip(x[1], "type", x[0])).join("") +
        "</div>" +
        '<div class="filter-row" style="margin-bottom:var(--sp-6)">' +
        TLA.data.levels.map(l => chip(l.code, "level", l.id)).join("") +
        chip(t("misc.free"), "access", "free") + chip(t("misc.premium"), "access", "premium") +
        "</div>" +

        (list.length
          ? '<div class="grid grid-2">' + list.map(function (r) {
            return '<button class="res-card" data-open-res="' + r.id + '" data-reveal>' +
              '<span class="res-ico ' + (r.format === "pdf" ? "pdf" : r.type === "audio" ? "audio" : r.type === "video" ? "video" : "") + '">' +
              (RES_ICONS[r.type] || "◈") + "</span>" +
              '<span style="flex:1"><span class="rt">' + U.esc(r.titleUz) + "</span>" +
              '<span class="rs">' + U.esc(r.descUz) + "</span>" +
              '<span class="rm">' + TLA.ui.levelPill(r.level) +
              '<span class="badge badge-outline">' + t("misc.skill." + r.skill) + "</span>" +
              (r.free ? '<span class="badge badge-free">' + t("misc.free") + "</span>"
                : '<span class="badge badge-gold">' + t("misc.premium") + "</span>") +
              "</span></span></button>";
          }).join("") + "</div>"
          : TLA.ui.emptyState("؟", t("empty.search"), t("empty.searchD"),
            '<a class="btn btn-ghost" href="#/library">' + t("action.reset") + "</a>")) +
        "</div></section>";
    },
    mounted: function (params) {
      const search = U.$("#libSearch");
      if (search) {
        search.addEventListener("keydown", function (e) {
          if (e.key === "Enter") {
            const nq = Object.assign({}, params.query, { q: search.value });
            const qs = Object.keys(nq).filter(k => nq[k]).map(k => k + "=" + encodeURIComponent(nq[k])).join("&");
            location.hash = "#/library" + (qs ? "?" + qs : "");
          }
        });
      }
      U.$$("[data-open-res]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const res = TLA.data.library.filter(r => r.id === btn.dataset.openRes)[0];
          if (res) openResource(res);
        });
      });
      if (params.query.open) {
        const res = TLA.data.library.filter(r => r.id === params.query.open)[0];
        if (res) openResource(res);
      }
    },
    meta: { title: "Arab tili kutubxonasi — Tatbiqul Lisan Academy", desc: "Matnlar, audio darslar, grammatika qo‘llanmalari va imtihon materiallari." }
  };

  /* ================= Dictionary ================= */
  TLA.pages.dictionary = {
    render: function (params) {
      const q = params.query.q || "";
      const dueMode = params.query.due === "1";
      const due = TLA.state.dueWords();
      const saved = Object.keys(TLA.state.profile().vocab);

      let list = TLA.data.dictionary;
      if (dueMode) list = list.filter(d => due.indexOf(d.ar) !== -1);
      if (q) list = list.filter(d => U.includesLoose(d.ar + " " + d.uz + " " + d.tr + " " + d.ex, q));

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.library"), href: "#/library" }, { label: t("nav.dictionary") }],
        eyebrow: t("nav.dictionary"),
        title: t("dict.title"),
        lead: t("dict.sub"),
        extra: '<div class="row row-wrap" style="margin-top:var(--sp-4);gap:var(--sp-3)">' +
          '<span class="badge">' + t("dict.saved") + ": " + saved.length + "</span>" +
          (due.length ? '<a class="badge badge-gold" href="#/dictionary?due=1">' + t("dict.reviewDue") + ": " + due.length + "</a>" : "") +
          "</div>"
      }) +
        '<section class="section"><div class="container">' +
        '<div class="toolbar">' +
        '<div class="search-box"><span class="search-ico">⌕</span>' +
        '<input class="input" id="dictSearch" placeholder="' + U.attr(t("dict.search")) + '" value="' + U.attr(q) + '"></div>' +
        (dueMode ? '<a class="btn btn-ghost btn-sm" href="#/dictionary">' + t("action.reset") + "</a>" : "") +
        (due.length && !dueMode ? '<a class="btn btn-primary btn-sm" href="#/dictionary?due=1">' + t("dict.review") + " (" + due.length + ")</a>" : "") +
        "</div>" +

        (dueMode && list.length
          ? '<div class="alert alert-info" style="margin-bottom:var(--sp-5)"><span class="ico">✦</span><span>' +
            "Har bir so‘zni eslab qoldingizmi? «Eslayman» tugmasi intervalni uzaytiradi, «Takrorlash» esa so‘zni ertaga qaytaradi.</span></div>"
          : "") +

        (list.length
          ? '<div class="grid grid-2" id="dictList">' + list.map(function (d) {
            const savedWord = TLA.state.hasWord(d.ar);
            return '<article class="dict-entry" data-reveal data-word="' + U.attr(d.ar) + '">' +
              '<div class="head"><span class="w">' + d.ar + "</span>" +
              '<span class="row" style="gap:var(--sp-2)">' + TLA.ui.levelPill(d.level) +
              '<button class="btn btn-quiet btn-sm" data-action="speak" data-text="' + U.attr(d.ar) + '">◉</button>' +
              '<button class="chip' + (savedWord ? " is-active" : "") + '" data-action="save-word" data-word="' + U.attr(d.ar) +
              '" aria-pressed="' + savedWord + '">✦</button></span></div>' +
              '<div><strong>' + U.esc(d.uz) + '</strong> <span class="muted mono" style="font-size:var(--fs-2xs)">' + U.esc(d.tr) + "</span></div>" +
              '<div class="root">' + t("dict.root") + ": " + U.esc(d.root) + "</div>" +
              '<p class="ar" style="font-size:1.15rem">' + d.ex + "</p>" +
              '<p class="muted" style="font-size:var(--fs-2xs)">' + U.esc(d.exUz) + "</p>" +
              '<div class="row row-wrap" style="gap:6px">' + t("dict.related") + ": " +
              d.rel.map(r => '<span class="badge ar-ui">' + r + "</span>").join("") + "</div>" +
              (dueMode
                ? '<div class="row" style="gap:var(--sp-2);margin-top:var(--sp-2)">' +
                  '<button class="btn btn-success btn-sm" data-review="ok" data-word="' + U.attr(d.ar) + '">✓ Eslayman</button>' +
                  '<button class="btn btn-ghost btn-sm" data-review="again" data-word="' + U.attr(d.ar) + '">↺ Takrorlash</button></div>'
                : "") +
              "</article>";
          }).join("") + "</div>"
          : TLA.ui.emptyState("؟", dueMode ? "Takrorlash uchun so‘z yo‘q" : t("empty.search"),
            dueMode ? "Barcha so‘zlar takrorlangan. Yangi so‘zlarni saqlang." : t("empty.searchD"),
            '<a class="btn btn-ghost" href="#/dictionary">' + t("action.reset") + "</a>")) +
        "</div></section>";
    },
    mounted: function () {
      const search = U.$("#dictSearch");
      if (search) {
        search.addEventListener("input", U.debounce(function () {
          location.hash = "#/dictionary" + (search.value ? "?q=" + encodeURIComponent(search.value) : "");
        }, 500));
      }
      U.$$("[data-review]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          TLA.state.reviewWord(btn.dataset.word, btn.dataset.review === "ok");
          const card = btn.closest(".dict-entry");
          card.style.opacity = "0.35";
          U.$$("[data-review]", card).forEach(b => { b.disabled = true; });
          TLA.ui.toast(btn.dataset.review === "ok" ? "Interval uzaytirildi." : "Ertaga qaytariladi.", "success");
        });
      });
    },
    meta: { title: "Arabcha lug‘at — Tatbiqul Lisan Academy", desc: "So‘z, tarjima, o‘zak, misol jumla va intervalli takrorlash." }
  };

  /* ================= Blog ================= */
  TLA.pages.blog = {
    render: function (params) {
      const cat = params.query.cat || "";
      const cats = U.unique(TLA.data.blog.map(b => b.cat));
      const list = cat ? TLA.data.blog.filter(b => b.cat === cat) : TLA.data.blog;

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.blog") }],
        eyebrow: t("nav.blog"),
        title: t("blog.title"),
        lead: t("blog.sub")
      }) +
        '<section class="section"><div class="container">' +
        '<div class="filter-row" style="margin-bottom:var(--sp-6)">' +
        '<a class="chip' + (cat ? "" : " is-active") + '" href="#/blog">' + t("library.all") + "</a>" +
        cats.map(c => '<a class="chip' + (cat === c ? " is-active" : "") + '" href="#/blog?cat=' + encodeURIComponent(c) + '">' +
          U.esc(c) + "</a>").join("") +
        "</div>" +
        '<div class="grid grid-3">' +
        list.map((p, i) => '<a class="post-card" href="#/blog/' + p.slug + '" data-reveal style="--reveal-delay:' + (i * 60) + 'ms">' +
          '<div class="post-cover"><span class="glyph">' + p.glyph + "</span></div>" +
          '<div class="post-body"><span class="badge">' + U.esc(p.cat) + "</span>" +
          "<h3>" + U.esc(p.titleUz) + '</h3><p class="excerpt">' + U.esc(p.excerptUz) + "</p>" +
          '<div class="pmeta"><span>' + U.fmtDate(p.date, TLA.i18n.get()) + "</span><span>" + p.minutes + " " + t("blog.min") + "</span></div>" +
          "</div></a>").join("") +
        "</div></div></section>";
    },
    meta: { title: "Arab tili blogi — Tatbiqul Lisan Academy", desc: "O‘qish usullari, grammatika tahlillari va imtihon strategiyalari." }
  };

  TLA.pages.blogPost = {
    render: function (params) {
      const post = TLA.data.blogBySlug(params.slug);
      if (!post) return TLA.pages.notFound.render();
      const related = TLA.data.blog.filter(b => b.slug !== post.slug && b.cat === post.cat).slice(0, 2);

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.blog"), href: "#/blog" }, { label: post.cat, href: "#/blog?cat=" + encodeURIComponent(post.cat) }, { label: post.titleUz }],
        eyebrow: post.cat,
        title: post.titleUz,
        lead: post.excerptUz,
        extra: '<div class="row row-wrap" style="margin-top:var(--sp-4);gap:var(--sp-3)">' +
          '<span class="badge badge-outline">' + U.fmtDate(post.date, TLA.i18n.get()) + "</span>" +
          '<span class="badge badge-outline">' + post.minutes + " " + t("blog.min") + "</span>" +
          '<span class="badge">Tatbiqul Lisan Academy jamoasi</span></div>'
      }) +
        '<section class="section"><div class="container">' +
        '<article class="article" data-reveal>' +
        post.bodyUz.map(function (block) {
          if (block.h) return "<h2>" + U.esc(block.h) + "</h2>";
          if (block.p) return "<p>" + U.esc(block.p) + "</p>";
          if (block.ar) return '<p class="ar ar-lg">' + block.ar + "</p>";
          return "";
        }).join("") +
        '<div class="card card-dark" style="margin-top:var(--sp-8)">' +
        '<h3 style="color:var(--ivory)">Maqolani amalda sinab ko‘ring</h3>' +
        '<p class="muted" style="margin-top:var(--sp-2)">Bepul diagnostik test darajangizni aniqlaydi va shu maqoladagi maslahatlarni qaysi ko‘nikmaga qo‘llash kerakligini ko‘rsatadi.</p>' +
        '<a class="btn btn-gold" style="margin-top:var(--sp-4)" href="#/test/diagnostic">' + t("action.startFree") + "</a></div>" +
        "</article>" +
        (related.length
          ? '<div style="margin-top:var(--sp-9)"><h3 style="margin-bottom:var(--sp-4)">' + t("blog.related") + "</h3>" +
            '<div class="grid grid-2">' + related.map(r => '<a class="post-card" href="#/blog/' + r.slug + '">' +
              '<div class="post-cover"><span class="glyph">' + r.glyph + "</span></div>" +
              '<div class="post-body"><h3>' + U.esc(r.titleUz) + '</h3><p class="excerpt">' + U.esc(r.excerptUz) + "</p></div></a>").join("") +
            "</div></div>"
          : "") +
        "</div></section>";
    },
    meta: function (params) {
      const p = TLA.data.blogBySlug(params.slug);
      return p ? { title: p.titleUz + " — Tatbiqul Lisan Academy", desc: p.excerptUz } : null;
    }
  };

  /* ================= Free resources ================= */
  TLA.pages.free = {
    render: function () {
      const freeTests = TLA.data.tests.filter(x => x.free).slice(0, 6);
      const freeLib = TLA.data.library.filter(r => r.free);

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.free") }],
        eyebrow: t("misc.free"),
        title: "Bepul materiallar",
        lead: "Ro‘yxatdan o‘tmasdan ham foydalanish mumkin bo‘lgan testlar va materiallar. Yuklab olinadigan fayllar uchun hisob talab qilinadi."
      }) +
        '<section class="section"><div class="container">' +
        '<h3 style="margin-bottom:var(--sp-4)">Bepul testlar</h3>' +
        '<div class="grid grid-3">' + freeTests.map(x => TLA.pages.testCard(x, { hideAr: true })).join("") + "</div>" +
        '<h3 style="margin:var(--sp-9) 0 var(--sp-4)">Bepul materiallar</h3>' +
        '<div class="grid grid-2">' + freeLib.map(r => '<a class="res-card" href="#/library?open=' + r.id + '" data-reveal>' +
          '<span class="res-ico">◈</span><span style="flex:1"><span class="rt">' + U.esc(r.titleUz) + "</span>" +
          '<span class="rs">' + U.esc(r.descUz) + "</span></span></a>").join("") + "</div>" +
        '<div class="card card-dark" style="margin-top:var(--sp-8)" data-reveal>' +
        '<div class="row-between row-wrap" style="gap:var(--sp-4)">' +
        '<div style="max-width:52ch"><h3 style="color:var(--ivory)">500 ta asosiy arabcha so‘z</h3>' +
        '<p class="muted" style="margin-top:var(--sp-2)">Lug‘at bo‘limida so‘zlarni saqlang — intervalli takrorlash rejasi avtomatik tuziladi.</p></div>' +
        '<a class="btn btn-gold" href="#/dictionary">' + t("nav.dictionary") + "</a></div></div>" +
        "</div></section>";
    },
    meta: { title: "Bepul materiallar — Tatbiqul Lisan Academy", desc: "Bepul testlar, matnlar va audio materiallar." }
  };

  /* ================= Pricing & checkout ================= */
  TLA.pages.pricing = {
    render: function () {
      const plans = TLA.state.plans();
      const currency = TLA.state.config().currency;
      const current = TLA.state.currentPlan();

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.pricing") }],
        eyebrow: t("nav.pricing"),
        title: t("pricing.title"),
        lead: t("pricing.sub")
      }) +
        '<section class="section"><div class="container">' +
        '<div class="grid grid-4">' +
        plans.map(function (p) {
          return '<div class="plan ' + (p.featured ? "featured" : "") + '" data-reveal>' +
            (p.featured ? '<span class="ribbon">Tavsiya etiladi</span>' : "") +
            '<div><span class="pname">' + U.esc(p.uz) + '</span><br><span class="ar" style="color:var(--accent-ink)">' + p.ar + "</span></div>" +
            '<div class="price"><span class="amt">' + (p.price ? U.fmtNumber(p.price) : "0") + '</span><span class="per">' +
            currency + " / " + t("pricing.month") + "</span></div>" +
            "<ul>" + p.features.map(f => '<li class="' + (f.on ? "" : "off") + '"><span class="tick">' + (f.on ? "✓" : "✕") +
              "</span><span>" + U.esc(f.uz) + "</span></li>").join("") + "</ul>" +
            '<div class="plan-cta">' +
            (current === p.id
              ? '<button class="btn btn-ghost btn-block" disabled>' + t("pricing.current") + "</button>"
              : '<button class="btn ' + (p.featured ? "btn-gold" : "btn-primary") + ' btn-block" data-plan="' + p.id + '">' +
                (p.price ? t("pricing.choose") : t("action.start")) + "</button>") +
            "</div></div>";
        }).join("") +
        "</div>" +

        '<div class="grid grid-2" style="margin-top:var(--sp-8)">' +
        '<div class="card" data-reveal><h3>' + t("pricing.methods") + "</h3>" +
        '<div class="grid grid-2" style="gap:var(--sp-3);margin-top:var(--sp-4)">' +
        TLA.data.paymentMethods.map(m => '<div class="pay-method" style="cursor:default">' +
          '<span class="pm-logo" style="background:' + m.color + '">' + U.esc(m.name.slice(0, 4)) + "</span>" +
          "<span>" + U.esc(m.name) + "</span></div>").join("") +
        "</div>" +
        TLA.ui.complianceNote("To‘lov kalitlari va API tokenlari hech qachon frontendda saqlanmaydi. To‘lov backend orqali amalga oshiriladi; bu yerdagi jarayon demo rejimida ishlaydi.") +
        "</div>" +
        '<div class="card" data-reveal><h3>' + t("courses.faq") + "</h3>" +
        '<div style="margin-top:var(--sp-4)">' +
        [
          { q: "Obunani istalgan vaqtda bekor qila olamanmi?", a: "Ha. Bekor qilingach, joriy davr oxirigacha kirish saqlanadi." },
          { q: "To‘lovni qaytarish mumkinmi?", a: "7 kun ichida va kurs materiallarining 20% dan kamrog‘i ochilgan bo‘lsa — ha. Batafsil: To‘lovni qaytarish siyosati." },
          { q: "Narxlar qanday belgilanadi?", a: "Narxlar admin panel orqali boshqariladi va bu sahifada avtomatik yangilanadi." }
        ].map(f => '<details class="acc"><summary>' + U.esc(f.q) + '</summary><div class="acc-body">' + U.esc(f.a) + "</div></details>").join("") +
        "</div></div></div>" +

        '<p class="muted text-center" style="margin-top:var(--sp-6);font-size:var(--fs-2xs)">' + t("pricing.note") + "</p>" +
        "</div></section>";
    },
    mounted: function () {
      U.$$("[data-plan]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          if (!TLA.state.isAuthed()) { TLA.ui.openAuth("register"); return; }
          const plan = TLA.state.plans().filter(p => p.id === btn.dataset.plan)[0];
          if (!plan) return;
          if (!plan.price) {
            TLA.state.profile().plan = plan.id;
            TLA.ui.toast(plan.uz + " tarifi faollashtirildi.", "success");
            TLA.router.rerender();
            return;
          }
          openCheckout(plan);
        });
      });
    },
    meta: { title: "Narxlar va obunalar — Tatbiqul Lisan Academy", desc: "Bepul, Standart, Premium va All Access tariflari." }
  };

  function openCheckout(plan) {
    const currency = TLA.state.config().currency;
    TLA.ui.modal(
      "<h3>" + t("pricing.demoPay") + "</h3>" +
      '<p class="muted" style="margin-top:var(--sp-2);font-size:var(--fs-sm)">' + U.esc(plan.uz) + " — " +
      U.fmtMoney(plan.price, currency) + " / " + t("pricing.month") + "</p>" +
      '<div class="stack-sm" style="margin-top:var(--sp-5)">' +
      TLA.data.paymentMethods.map((m, i) => '<button class="pay-method' + (i === 0 ? " is-selected" : "") + '" data-method="' + m.id + '">' +
        '<span class="pm-logo" style="background:' + m.color + '">' + U.esc(m.name.slice(0, 4)) + "</span>" +
        '<span style="flex:1">' + U.esc(m.name) + "</span>" +
        '<span class="muted" style="font-size:var(--fs-2xs)">Demo</span></button>').join("") +
      "</div>" +
      '<div class="alert alert-warn" style="margin-top:var(--sp-5)"><span class="ico">⚠</span><span>' +
      "Bu demo to‘lov: haqiqiy pul yechilmaydi va karta ma’lumotlari so‘ralmaydi. Ishlab chiqarishda to‘lov provayderining xavfsiz sahifasiga yo‘naltiriladi.</span></div>" +
      '<button class="btn btn-primary btn-block btn-lg" id="payNow" style="margin-top:var(--sp-5)">' +
      U.fmtMoney(plan.price, currency) + " — " + t("action.submit") + "</button>",
      { label: t("pricing.demoPay") }
    );

    let method = TLA.data.paymentMethods[0].id;
    U.$$("[data-method]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        U.$$("[data-method]").forEach(b => b.classList.remove("is-selected"));
        btn.classList.add("is-selected");
        method = btn.dataset.method;
      });
    });

    U.$("#payNow").addEventListener("click", function () {
      const btn = U.$("#payNow");
      btn.disabled = true;
      btn.textContent = t("misc.loading");
      setTimeout(function () {
        TLA.state.recordPayment(plan.id, method);
        TLA.ui.closeModal();
        TLA.ui.toast(t("pricing.paySuccess"), "success");
        TLA.router.rerender();
      }, 900);
    });
  }

  /* ================= About ================= */
  TLA.pages.about = {
    render: function () {
      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.about") }],
        eyebrow: t("nav.about"),
        title: "Tatbiqul Lisan Academy haqida",
        lead: "Arab tilini o‘zbek tilli talabalar uchun tushunarli, tizimli va o‘lchanadigan qilib o‘rgatish."
      }) +
        '<section class="section"><div class="container">' +
        '<div class="grid grid-2" style="gap:var(--sp-8)">' +
        '<div class="stack-lg" data-reveal>' +
        '<div><h3>Missiya</h3><p class="muted" style="margin-top:var(--sp-3);line-height:1.8">' +
        "Arab tilini o‘rganishni tasodifiy mashqlar to‘plamidan tizimli jarayonga aylantirish: har bir talaba o‘z darajasini bilishi, " +
        "kuchsiz tomonini aniq ko‘rishi va keyingi qadamini shubhasiz tanlashi kerak.</p></div>" +
        '<div><h3>Yondashuv</h3><p class="muted" style="margin-top:var(--sp-3);line-height:1.8">' +
        "Ta’lim materiali CEFR (A1–C2) tuzilmasiga tayanadi, mashqlar esa imtihon formatlariga moslashtirilgan. " +
        "Har bir test natijasi ko‘nikmalar bo‘yicha ajratiladi va shu asosda keyingi darslar tavsiya qilinadi.</p></div>" +
        '<div><h3>Halollik tamoyili</h3><p class="muted" style="margin-top:var(--sp-3);line-height:1.8">' +
        "Biz soxta statistika, soxta muvaffaqiyat hikoyalari yoki o‘ylab topilgan o‘qituvchi malakalarini ko‘rsatmaymiz. " +
        "Platforma hech bir imtihon tashkilotining rasmiy vakili emas va rasmiy imtihon savollarini tarqatmaydi.</p></div>" +
        "</div>" +
        '<div class="stack-lg">' +
        '<div class="card card-dark" data-reveal><h3 style="color:var(--ivory)">Platforma nimalardan iborat</h3>' +
        '<div class="stack-sm" style="margin-top:var(--sp-4)">' +
        [
          "6 ta daraja (A1–C2) va " + TLA.data.courses.reduce((n, c) => n + c.lessons, 0) + " ta dars",
          TLA.data.tests.length + " ta test to‘plami, jumladan mock imtihonlar",
          "Savollar bazasi: " + TLA.data.questions.length + " ta savol (izohlar bilan)",
          "Kutubxona, lug‘at va intervalli takrorlash",
          "Ko‘nikmalar bo‘yicha tahlil va shaxsiy tavsiyalar"
        ].map(x => '<div class="row row-top" style="gap:var(--sp-3)"><span style="color:var(--gold-300)">◦</span><span class="muted">' +
          U.esc(x) + "</span></div>").join("") +
        "</div></div>" +
        '<div class="card" data-reveal><h3>' + t("nav.teachers") + "</h3>" +
        '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm);line-height:1.7">' + t("empty.teachersD") + "</p>" +
        '<a class="btn btn-ghost btn-sm" style="margin-top:var(--sp-4)" href="#/teachers">' + t("action.open") + "</a></div>" +
        "</div></div></div></section>";
    },
    meta: { title: "Akademiya haqida — Tatbiqul Lisan Academy", desc: "Missiya, yondashuv va platforma imkoniyatlari." }
  };

  /* ================= Teachers ================= */
  TLA.pages.teachers = {
    render: function () {
      const list = TLA.state.teachers();
      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.about"), href: "#/about" }, { label: t("nav.teachers") }],
        eyebrow: t("nav.teachers"),
        title: "O‘qituvchilar",
        lead: "Profillar faqat administrator kiritgan haqiqiy ma’lumotlar asosida ko‘rsatiladi."
      }) +
        '<section class="section"><div class="container">' +
        (list.length
          ? '<div class="grid grid-3">' + list.map(x => '<article class="card card-hover" data-reveal>' +
            '<div class="row" style="gap:var(--sp-4)"><span class="avatar avatar-lg">' + U.esc(U.initials(x.name)) + "</span>" +
            "<div><h3 style='font-size:var(--fs-lg)'>" + U.esc(x.name) + "</h3>" +
            '<p class="muted" style="font-size:var(--fs-2xs)">' + U.esc(x.title || "") + "</p></div></div>" +
            '<p class="muted" style="margin-top:var(--sp-4);font-size:var(--fs-sm);line-height:1.6">' + U.esc(x.bio || "") + "</p>" +
            (x.languages ? '<div class="row row-wrap" style="gap:6px;margin-top:var(--sp-3)">' +
              x.languages.split(",").map(l => '<span class="badge">' + U.esc(l.trim()) + "</span>").join("") + "</div>" : "") +
            "</article>").join("") + "</div>"
          : TLA.ui.emptyState("◐", t("empty.teachers"), t("empty.teachersD"),
            TLA.state.isAdmin() ? '<a class="btn btn-primary" href="#/admin?tab=teachers">' + t("nav.admin") + "</a>" : "")) +
        "</div></section>";
    },
    meta: { title: "O‘qituvchilar — Tatbiqul Lisan Academy", desc: "O‘qituvchilar profillari." }
  };

  /* ================= Contact ================= */
  TLA.pages.contact = {
    render: function () {
      const cfg = TLA.state.config();
      const row = (label, value, href) =>
        '<div class="row-between" style="padding:var(--sp-3) 0;border-bottom:1px solid var(--border)">' +
        '<span class="muted" style="font-size:var(--fs-2xs);text-transform:uppercase;letter-spacing:.06em">' + U.esc(label) + "</span>" +
        (value
          ? (href ? '<a href="' + U.attr(href) + '" class="strong">' + U.esc(value) + "</a>" : "<span class='strong'>" + U.esc(value) + "</span>")
          : '<span class="badge badge-outline">Admin panelda kiritiladi</span>') + "</div>";

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.contact") }],
        eyebrow: t("nav.contact"),
        title: "Biz bilan bog‘lanish",
        lead: "Savolingiz bo‘lsa yozing — murojaatlar admin panelidagi xabarlar bo‘limiga tushadi."
      }) +
        '<section class="section"><div class="container"><div class="grid grid-2" style="gap:var(--sp-8)">' +
        '<div class="card" data-reveal><h3>Xabar yuborish</h3>' +
        '<form id="contactForm" style="margin-top:var(--sp-4)">' +
        '<label class="field"><span class="label">' + t("auth.name") + '</span><input class="input" name="name" required></label>' +
        '<label class="field"><span class="label">' + t("auth.email") + '</span><input class="input" name="email" type="email" required></label>' +
        '<label class="field"><span class="label">Mavzu</span><select class="select" name="topic">' +
        ["Umumiy savol", "Kurslar", "To‘lov", "Texnik muammo", "Hamkorlik"].map(x => "<option>" + x + "</option>").join("") +
        "</select></label>" +
        '<label class="field"><span class="label">Xabar</span><textarea class="textarea" name="message" required></textarea></label>' +
        '<button class="btn btn-primary btn-block" type="submit" style="margin-top:var(--sp-4)">' + t("action.send") + "</button>" +
        '<p class="field-hint">Demo rejim: xabar shu qurilmada saqlanadi va serverga yuborilmaydi.</p>' +
        "</form></div>" +
        '<div class="stack-lg">' +
        '<div class="card" data-reveal><h3>Kontaktlar</h3>' +
        '<div style="margin-top:var(--sp-4)">' +
        row("Telefon", cfg.contact.phone, cfg.contact.phone ? "tel:" + cfg.contact.phone : "") +
        row("Email", cfg.contact.email, cfg.contact.email ? "mailto:" + cfg.contact.email : "") +
        row("Telegram", cfg.contact.telegram, cfg.contact.telegram) +
        row("Manzil", cfg.contact.address) +
        row("Ish vaqti", cfg.contact.workHours) +
        "</div>" +
        TLA.ui.complianceNote("Kontakt ma’lumotlari o‘ylab topilmaydi. Ular admin panel → Sozlamalar bo‘limidan kiritiladi va shu yerda avtomatik ko‘rinadi.") +
        "</div>" +
        '<div class="card" data-reveal><h3>Tez-tez so‘raladigan</h3>' +
        '<div style="margin-top:var(--sp-3)">' +
        [
          { q: "Javob qancha vaqtda keladi?", a: "Ish kunlari ichida 24 soatgacha." },
          { q: "Kursni sinab ko‘rish mumkinmi?", a: "Ha, A1 kursi va diagnostik test bepul." }
        ].map(f => '<details class="acc"><summary>' + U.esc(f.q) + '</summary><div class="acc-body">' + U.esc(f.a) + "</div></details>").join("") +
        "</div></div></div></div></div></section>";
    },
    mounted: function () {
      const form = U.$("#contactForm");
      if (!form) return;
      form.addEventListener("submit", function (ev) {
        ev.preventDefault();
        const fd = new FormData(form);
        const name = (fd.get("name") || "").toString().trim();
        const email = (fd.get("email") || "").toString().trim();
        const message = (fd.get("message") || "").toString().trim();
        if (name.length < 2) return TLA.ui.toast(t("auth.errName"), "error");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return TLA.ui.toast(t("auth.errEmail"), "error");
        if (message.length < 10) return TLA.ui.toast("Xabar juda qisqa.", "error");
        TLA.state.notify("contact", "Yangi murojaat: " + fd.get("topic"), name + " (" + email + "): " + message.slice(0, 120));
        form.reset();
        TLA.ui.toast("Xabar saqlandi. Backend ulangach, u avtomatik yuboriladi.", "success");
      });
    },
    meta: { title: "Aloqa — Tatbiqul Lisan Academy", desc: "Murojaat shakli va kontakt ma’lumotlari." }
  };

  /* ================= Legal ================= */
  TLA.pages.legal = {
    render: function (params) {
      const doc = TLA.data.legal[params.doc];
      if (!doc) return TLA.pages.notFound.render();
      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("footer.legal") }, { label: doc.titleUz }],
        eyebrow: t("footer.legal"),
        title: doc.titleUz,
        lead: "Oxirgi yangilanish: " + U.fmtDate(doc.updated, TLA.i18n.get())
      }) +
        '<section class="section"><div class="container container-narrow">' +
        '<article class="article" data-reveal>' +
        doc.sections.map(s => "<h2>" + U.esc(s.h) + "</h2><p>" + U.esc(s.p) + "</p>").join("") +
        "</article>" +
        TLA.ui.complianceNote("Ushbu hujjat namuna sifatida tayyorlangan. Ishga tushirishdan oldin yurist tomonidan ko‘rib chiqilishi va tashkilot rekvizitlari bilan to‘ldirilishi kerak.") +
        "</div></section>";
    },
    meta: function (params) {
      const d = TLA.data.legal[params.doc];
      return d ? { title: d.titleUz + " — Tatbiqul Lisan Academy", desc: d.titleUz } : null;
    }
  };

  /* ================= 404 ================= */
  TLA.pages.notFound = {
    render: function () {
      return '<section class="section"><div class="container container-narrow" style="padding-block:var(--sp-10)">' +
        '<div class="text-center">' +
        '<div class="ar" style="font-size:4rem;color:var(--accent);opacity:.5">٤٠٤</div>' +
        '<h1 style="margin:var(--sp-4) 0">' + t("error.notFound") + "</h1>" +
        '<p class="lead" style="margin-inline:auto">' + t("error.notFoundD") + "</p>" +
        '<div class="row" style="justify-content:center;gap:var(--sp-3);margin-top:var(--sp-6)">' +
        '<a class="btn btn-primary" href="#/">' + t("error.goHome") + "</a>" +
        '<button class="btn btn-ghost" data-action="search-open">' + t("nav.search") + "</button>" +
        "</div></div></div></section>";
    },
    meta: { title: "Sahifa topilmadi — Tatbiqul Lisan Academy", desc: "" }
  };
})();
