/* ============================================================
   PAGE — Home
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  /* ---------------- Girih pattern (ambient canvas) ---------------- */
  function drawGirih(canvas) {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(240, rect.width), h = Math.max(200, rect.height);
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const dark = document.documentElement.getAttribute("data-theme") === "dark";
    const stroke = dark ? "rgba(231,205,147,0.20)" : "rgba(26,66,114,0.16)";
    const accent = dark ? "rgba(231,205,147,0.32)" : "rgba(168,132,44,0.28)";
    const cell = 84;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches ||
      document.documentElement.getAttribute("data-motion") === "off";

    function star(cx, cy, r, rotation) {
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const a = rotation + (Math.PI / 4) * i;
        const rr = i % 2 === 0 ? r : r * 0.56;
        const x = cx + rr * Math.cos(a);
        const y = cy + rr * Math.sin(a);
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.stroke();
    }

    function frame(offset) {
      ctx.clearRect(0, 0, w, h);
      ctx.lineWidth = 1;
      for (let y = -cell; y < h + cell; y += cell) {
        for (let x = -cell; x < w + cell; x += cell) {
          const cx = x + (offset % cell), cy = y + (offset * 0.4 % cell);
          ctx.strokeStyle = stroke;
          star(cx, cy, cell * 0.42, 0);
          ctx.strokeStyle = accent;
          ctx.beginPath();
          ctx.arc(cx, cy, cell * 0.17, 0, Math.PI * 2);
          ctx.stroke();
          ctx.strokeStyle = stroke;
          ctx.beginPath();
          ctx.moveTo(cx + cell / 2, cy);
          ctx.lineTo(cx, cy + cell / 2);
          ctx.moveTo(cx - cell / 2, cy);
          ctx.lineTo(cx, cy - cell / 2);
          ctx.stroke();
        }
      }
    }

    if (reduced) { frame(0); return; }
    let start = null;
    let raf = null;
    function loop(ts) {
      if (!start) start = ts;
      const offset = ((ts - start) / 240) % cell;
      frame(offset);
      raf = requestAnimationFrame(loop);
    }
    raf = requestAnimationFrame(loop);
    canvas._stop = function () { if (raf) cancelAnimationFrame(raf); };
  }

  /* ---------------- Hero scene (CSS 3D) ---------------- */
  function heroScene() {
    const p = TLA.state.profile();
    const level = (p.level || "b1").toUpperCase();
    const listening = p.skills.listening != null ? p.skills.listening : 74;
    const xp = TLA.state.xpToday() || 40;
    const streak = p.streak || 7;

    return '<div class="hero-scene" aria-hidden="true">' +
      '<canvas class="girih" id="girihCanvas"></canvas>' +
      '<div class="book-shadow"></div>' +
      '<div class="book3d">' +
      '<div class="book-half left"><div class="book-headpiece"></div>' +
      '<div class="book-lines"><i></i><i></i><i></i><i></i><i></i><i></i></div></div>' +
      '<div class="book-half right"><div class="book-headpiece"></div>' +
      '<div class="book-lines"><i></i><i></i><i></i><i></i><i></i><i></i></div>' +
      '<div class="book-ar">اِقْرَأْ</div></div>' +
      '<div class="book-spine"></div>' +
      "</div>" +
      '<span class="letter-tile lt1">ا</span>' +
      '<span class="letter-tile lt2">ب</span>' +
      '<span class="letter-tile lt3">ت</span>' +
      '<div class="float-card fc1"><div class="fk">' + t("hero.card.level") + '</div><div class="fv">' + level + "</div></div>" +
      '<div class="float-card fc2"><div class="fk">' + t("hero.card.listening") + '</div><div class="fv">' + listening + "%</div>" +
      '<div class="progress sm" style="margin-top:6px"><span style="width:' + listening + '%"></span></div></div>' +
      '<div class="float-card fc3"><div class="fk">' + t("hero.card.xp") + '</div><div class="fv">+' + xp + " XP</div>" +
      '<div class="fk" style="margin-top:4px">🔥 ' + streak + " " + t("hero.card.streak") + "</div></div>" +
      "</div>";
  }

  /* ---------------- Sections ---------------- */
  function sectionTrust() {
    const cards = [
      { i: "❖", k: "trust.courses", d: "trust.coursesD" },
      { i: "◈", k: "trust.exams", d: "trust.examsD" },
      { i: "◉", k: "trust.mock", d: "trust.mockD" },
      { i: "◑", k: "trust.progress", d: "trust.progressD" }
    ];
    return '<section class="section-tight"><div class="container">' +
      '<div class="section-head center" data-reveal><span class="eyebrow">Tatbiqul Lisan Academy</span>' +
      "<h2>" + t("trust.title") + '</h2><p class="lead" style="margin-inline:auto">' + t("trust.sub") + "</p></div>" +
      '<div class="trust-strip" data-reveal>' +
      cards.map(c => '<div><div class="ti">' + c.i + "</div><h4>" + t(c.k) + "</h4><p>" + t(c.d) + "</p></div>").join("") +
      "</div>" +
      '<div class="row row-wrap" style="justify-content:center;gap:var(--sp-4);margin-top:var(--sp-6)" data-reveal>' +
      ["hero.stat1", "hero.stat2", "hero.stat3"].map(k => '<span class="badge badge-gold">' + t(k) + "</span>").join("") +
      "</div></div></section>";
  }

  function sectionGoals() {
    const goals = [
      { icon: "❖", k: "goal.learn", d: "goal.learnD", href: "#/learn" },
      { icon: "◈", k: "goal.multilevel", d: "goal.multilevelD", href: "#/exams/multilevel" },
      { icon: "◆", k: "goal.tanal", d: "goal.tanalD", href: "#/exams/tanal" },
      { icon: "◉", k: "goal.level", d: "goal.levelD", href: "#/test/diagnostic" }
    ];
    return '<section class="section"><div class="container">' +
      '<div class="section-head" data-reveal><span class="eyebrow">' + t("goal.title") + "</span>" +
      "<h2>" + t("goal.title") + '</h2><p class="lead">' + t("goal.sub") + "</p></div>" +
      '<div class="grid grid-4">' +
      goals.map((g, i) => '<a class="goal-card" href="' + g.href + '" data-reveal style="--reveal-delay:' + (i * 70) + 'ms">' +
        '<span class="gicon">' + g.icon + "</span><h3>" + t(g.k) + "</h3><p>" + t(g.d) + "</p>" +
        '<span class="go">' + t("action.start") + ' <span class="arw">→</span></span></a>').join("") +
      "</div></div></section>";
  }

  function sectionDiagnostic() {
    const demo = [
      { label: t("misc.skill.reading"), value: 78 },
      { label: t("misc.skill.listening"), value: 62 },
      { label: t("misc.skill.grammar"), value: 84 },
      { label: t("misc.skill.vocabulary"), value: 70 }
    ];
    return '<section class="section"><div class="container">' +
      '<div class="diag-band" data-reveal><div class="diag-inner">' +
      "<div>" +
      '<span class="eyebrow" style="color:var(--gold-300)">' + t("diag.eyebrow") + "</span>" +
      '<h2 style="margin:var(--sp-4) 0">' + t("diag.title") + "</h2>" +
      "<p>" + t("diag.sub") + "</p>" +
      '<div class="diag-steps" style="margin:var(--sp-6) 0">' +
      [1, 2, 3].map(n => '<div class="diag-step"><span class="num">0' + n + '</span><span>' +
        '<span class="st">' + t("diag.step" + n) + '</span><br><span class="sd">' + t("diag.step" + n + "d") + "</span></span></div>").join("") +
      "</div>" +
      '<div class="row row-wrap">' +
      '<a class="btn btn-gold btn-lg btn-arrow" href="#/test/diagnostic">' + t("action.startFree") + ' <span class="arw">→</span></a>' +
      '<a class="btn btn-ghost btn-lg" href="#/learn" style="--btn-ink:var(--ivory);--btn-border:rgba(231,205,147,.35)">' + t("action.explore") + "</a>" +
      "</div>" +
      '<p style="font-size:var(--fs-2xs);opacity:.7;margin-top:var(--sp-5)">' + t("diag.note") + "</p>" +
      "</div>" +
      '<div><div class="card card-glass" style="background:rgba(255,255,255,.06);border-color:rgba(231,205,147,.2)">' +
      '<div class="row-between" style="margin-bottom:var(--sp-3)">' +
      '<span class="eyebrow" style="color:var(--gold-300)">Namuna natija</span>' +
      '<span class="badge badge-demo">' + t("misc.demoData") + "</span></div>" +
      TLA.charts.shamsa(demo, { onDark: true, aria: "Namunaviy ko‘nikma diagrammasi" }) +
      '<div class="text-center" style="color:var(--ivory);margin-top:var(--sp-3)">' +
      '<div style="font-family:var(--font-display);font-size:var(--fs-2xl)">B1</div>' +
      '<div style="font-size:var(--fs-2xs);opacity:.7">' + t("result.estimated") + "</div></div>" +
      "</div></div>" +
      "</div></div></div></section>";
  }

  function sectionCourses() {
    return '<section class="section pattern-band"><div class="container">' +
      '<div class="section-head" data-reveal><span class="eyebrow">A1 → C2</span>' +
      "<h2>" + t("courses.title") + '</h2><p class="lead">' + t("courses.sub") + "</p></div>" +
      '<div class="ladder" data-reveal>' +
      TLA.data.courses.map(function (c) {
        const prog = TLA.state.courseProgress(c.id);
        return '<a class="ladder-item" href="#/learn/' + c.id + '">' +
          '<span class="code">' + c.code + "</span>" +
          '<span><span class="nm">' + U.esc(c.titleUz) + '</span><br><span class="ds">' + U.esc(c.descUz) + "</span>" +
          (prog.pct > 0 ? '<span class="progress sm" style="margin-top:8px;max-width:240px"><span style="width:' + prog.pct + '%"></span></span>' : "") +
          "</span>" +
          '<span class="row" style="gap:var(--sp-3)">' +
          (c.free ? '<span class="badge badge-free">' + t("misc.free") + "</span>" : '<span class="badge badge-gold">' + t("misc.premium") + "</span>") +
          '<span class="muted nowrap" style="font-size:var(--fs-2xs)">' + c.lessons + " " + t("courses.lessons") + "</span>" +
          '<span class="arw" aria-hidden="true">→</span></span></a>';
      }).join("") +
      "</div></div></section>";
  }

  function sectionExams() {
    return '<section class="section"><div class="container">' +
      '<div class="section-head" data-reveal><span class="eyebrow">' + t("nav.exams") + "</span>" +
      "<h2>Imtihon yo‘nalishlari</h2>" +
      '<p class="lead">Har bir yo‘nalish bo‘limlarga ajratilgan: mashq testlari, vaqt cheklovli rejim va to‘liq mock imtihon.</p></div>' +
      '<div class="grid grid-3">' +
      TLA.data.examTracks.map(function (e, i) {
        const list = TLA.data.testsByTrack(e.id);
        return '<a class="card card-hover card-illum" href="#/exams/' + e.id + '" data-reveal style="--reveal-delay:' + (i * 80) + 'ms">' +
          '<div class="row-between" style="margin-bottom:var(--sp-3)">' +
          '<span class="gicon" style="font-size:1.3rem;color:var(--accent)">' + e.icon + "</span>" +
          '<span class="badge">' + list.length + " test</span></div>" +
          "<h3>" + U.esc(e.uz) + '</h3><p class="ar" style="font-size:1.1rem;color:var(--accent-ink);margin-top:4px">' + e.ar + "</p>" +
          '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-3);line-height:1.55">' + U.esc(e.descUz) + "</p>" +
          '<span class="go" style="display:inline-flex;gap:6px;margin-top:var(--sp-4);font-size:var(--fs-xs);font-weight:700;color:var(--accent-ink)">' +
          t("action.more") + " →</span></a>";
      }).join("") +
      "</div>" +
      '<div style="margin-top:var(--sp-6)" data-reveal>' + TLA.ui.complianceNote(t("exam.disclaimer")) + "</div>" +
      "</div></section>";
  }

  function sectionProgress() {
    const demoTrend = [
      { label: "1-hafta", value: 54 }, { label: "2", value: 61 }, { label: "3", value: 66 },
      { label: "4", value: 72 }, { label: "5", value: 78 }, { label: "6", value: 82 }
    ];
    return '<section class="section"><div class="container">' +
      '<div class="hero-2col">' +
      "<div data-reveal>" +
      '<span class="eyebrow">' + t("nav.progress") + "</span>" +
      '<h2 style="margin:var(--sp-4) 0">Har bir mashq — o‘lchanadigan natija</h2>' +
      '<p class="lead">Platforma umumiy foizni emas, har bir ko‘nikma bo‘yicha alohida ko‘rsatkichni yuritadi. Shuning uchun keyingi qadam har doim aniq bo‘ladi.</p>' +
      '<div class="stack" style="margin-top:var(--sp-6)">' +
      [
        { i: "◉", h: "Kunlik seriya va XP", p: "Kichik, lekin muntazam mashq odat hosil qiladi. Seriya uzilsa, tizim yumshoq qayta tiklash yo‘lini taklif qiladi." },
        { i: "❖", h: "Intervalli takrorlash", p: "Saqlangan so‘zlar 1, 3, 7, 15 va 30-kunlarda takrorlashga chiqadi." },
        { i: "◆", h: "Zaif ko‘nikma bo‘yicha tavsiya", p: "Natijaga qarab keyingi dars va test avtomatik tanlanadi." }
      ].map(v => '<div class="value-item"><span class="vi">' + v.i + "</span><div><h4>" + v.h + "</h4><p>" + v.p + "</p></div></div>").join("") +
      "</div>" +
      '<a class="btn btn-primary btn-arrow" href="#/dashboard" style="margin-top:var(--sp-6)">' +
      t("dash.continueLearning") + ' <span class="arw">→</span></a>' +
      "</div>" +
      '<div class="card" data-reveal>' +
      '<div class="row-between" style="margin-bottom:var(--sp-4)"><strong>O‘rtacha ball dinamikasi</strong>' +
      '<span class="badge badge-demo">' + t("misc.demoData") + "</span></div>" +
      TLA.charts.line(demoTrend, { height: 200 }) +
      '<div class="grid grid-3" style="margin-top:var(--sp-5);gap:var(--sp-3)">' +
      '<div class="stat-tile"><div class="k">' + t("dash.streak") + '</div><div class="v">7</div><div class="d">' + t("dash.days") + "</div></div>" +
      '<div class="stat-tile"><div class="k">' + t("dash.xp") + '</div><div class="v">1 420</div><div class="d">jami</div></div>' +
      '<div class="stat-tile"><div class="k">' + t("dash.avgScore") + '</div><div class="v">81%</div><div class="d">so‘nggi 6 test</div></div>' +
      "</div></div>" +
      "</div></div></section>";
  }

  function sectionResources() {
    const posts = TLA.data.blog.slice(0, 3);
    return '<section class="section pattern-band"><div class="container">' +
      '<div class="row-between" style="align-items:flex-end;margin-bottom:var(--sp-6)" data-reveal>' +
      '<div class="section-head" style="margin:0"><span class="eyebrow">' + t("nav.blog") + "</span>" +
      "<h2>" + t("blog.title") + "</h2></div>" +
      '<a class="btn btn-ghost btn-sm" href="#/blog">' + t("action.viewAll") + "</a></div>" +
      '<div class="grid grid-3">' +
      posts.map((p, i) => '<a class="post-card" href="#/blog/' + p.slug + '" data-reveal style="--reveal-delay:' + (i * 70) + 'ms">' +
        '<div class="post-cover"><span class="glyph">' + p.glyph + "</span></div>" +
        '<div class="post-body"><span class="badge">' + U.esc(p.cat) + "</span><h3>" + U.esc(p.titleUz) + "</h3>" +
        '<p class="excerpt">' + U.esc(p.excerptUz) + "</p>" +
        '<div class="pmeta"><span>' + U.fmtDate(p.date, TLA.i18n.get()) + "</span><span>" + p.minutes + " " + t("blog.min") + "</span></div>" +
        "</div></a>").join("") +
      "</div></div></section>";
  }

  function sectionFaq() {
    return '<section class="section"><div class="container container-narrow">' +
      '<div class="section-head center" data-reveal><span class="eyebrow">FAQ</span><h2>' + t("courses.faq") + "</h2></div>" +
      '<div data-reveal>' + TLA.data.courseFaq.map(f =>
        '<details class="acc"><summary>' + U.esc(f.q) + '</summary><div class="acc-body">' + U.esc(f.a) + "</div></details>").join("") +
      "</div></div></section>";
  }

  function sectionCta() {
    return '<section class="section"><div class="container">' +
      '<div class="diag-band text-center" data-reveal style="padding-block:clamp(2.5rem,5vw,4rem)">' +
      '<h2 style="color:var(--ivory)">Darajangizni bilishdan boshlang</h2>' +
      '<p style="max-width:52ch;margin:var(--sp-4) auto var(--sp-6)">20 daqiqalik bepul diagnostik test kuchli va kuchsiz tomonlaringizni ko‘rsatadi va shaxsiy o‘quv rejasini shakllantiradi.</p>' +
      '<div class="row" style="justify-content:center;flex-wrap:wrap">' +
      '<a class="btn btn-gold btn-lg" href="#/test/diagnostic">' + t("action.checkLevel") + "</a>" +
      '<a class="btn btn-ghost btn-lg" href="#/pricing" style="--btn-ink:var(--ivory);--btn-border:rgba(231,205,147,.35)">' + t("nav.pricing") + "</a>" +
      "</div></div></div></section>";
  }

  /* ---------------- Page ---------------- */
  TLA.pages.home = {
    render: function () {
      return '<section class="hero"><div class="container"><div class="hero-grid">' +
        '<div class="hero-copy" data-reveal>' +
        '<span class="eyebrow">' + t("hero.eyebrow") + "</span>" +
        "<h1>" + t("hero.title1") + ' <span class="accent">' + t("hero.title2") + "</span> " + t("hero.title3") + "</h1>" +
        '<p class="lead">' + t("hero.sub") + "</p>" +
        '<div class="hero-cta">' +
        '<a class="btn btn-primary btn-lg btn-arrow" href="#/test/diagnostic">' + t("action.checkLevel") + ' <span class="arw">→</span></a>' +
        '<a class="btn btn-ghost btn-lg" href="#/learn">' + t("action.explore") + "</a>" +
        "</div>" +
        '<div class="hero-meta">' +
        '<div><span class="n">A1–C2</span><span class="l">' + t("hero.stat1") + "</span></div>" +
        '<div><span class="n">' + TLA.data.tests.length + '</span><span class="l">test to‘plami</span></div>' +
        '<div><span class="n">6</span><span class="l">ko‘nikma bo‘yicha tahlil</span></div>' +
        "</div></div>" +
        heroScene() +
        "</div></div></section>" +
        sectionTrust() + sectionGoals() + sectionDiagnostic() + sectionCourses() +
        sectionExams() + sectionProgress() + sectionResources() + sectionFaq() + sectionCta();
    },
    mounted: function () {
      drawGirih(U.$("#girihCanvas"));
      const redraw = U.debounce(function () { drawGirih(U.$("#girihCanvas")); }, 250);
      window.addEventListener("resize", redraw, { once: true });
    },
    meta: {
      title: "Tatbiqul Lisan Academy — Arab tili va imtihonga tayyorgarlik",
      desc: "Arab tili kurslari (A1–C2), Multilevel, TANAL Arobiy va Darajaviy testlarga tayyorgarlik, bepul diagnostika va mock imtihonlar."
    }
  };
})();
