/* ============================================================
   PAGES — Dashboard, progress, certificates, verify, profile,
   leaderboard
   ============================================================ */
window.TLA = window.TLA || {};
TLA.pages = TLA.pages || {};

(function () {
  "use strict";
  const U = TLA.utils;
  const t = (k, v) => TLA.i18n.t(k, v);

  function requireAuth(title) {
    return TLA.ui.pageHead({ title: title }) +
      '<section class="section"><div class="container container-narrow">' +
      TLA.ui.emptyState("◍", t("auth.needAuth"), t("result.gateBody"),
        '<div class="row" style="justify-content:center;gap:var(--sp-3)">' +
        '<button class="btn btn-primary" data-action="auth-register">' + t("result.gateCta") + "</button>" +
        '<button class="btn btn-ghost" data-action="auth-login">' + t("action.login") + "</button></div>") +
      "</div></section>";
  }

  /* ================= Dashboard ================= */
  TLA.pages.dashboard = {
    render: function () {
      if (!TLA.state.isAuthed()) return requireAuth(t("nav.dashboard"));

      const user = TLA.state.currentUser();
      const p = TLA.state.profile();
      const s = TLA.state.stats();
      const tasks = TLA.state.taskState();
      const recs = TLA.engine.recommend({});
      const attempts = TLA.state.attempts().slice(0, 5);
      const due = TLA.state.dueWords();

      // continue learning: first unfinished lesson at the current level
      const levelId = p.level || "a1";
      const course = TLA.data.courseById(levelId) || TLA.data.courses[0];
      const nextLesson = course.modules.reduce((acc, m) => acc.concat(m.lessons), [])
        .filter(l => !TLA.state.lessonDone(l.id))[0];
      const prog = TLA.state.courseProgress(course.id);

      const week = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = U.todayKey(d);
        week.push({
          key: key,
          label: ["Ya", "Du", "Se", "Ch", "Pa", "Ju", "Sh"][d.getDay()],
          on: p.activeDays.indexOf(key) !== -1,
          today: i === 0
        });
      }

      const examCountdown = p.examDate
        ? (function () {
          const days = U.daysBetween(U.todayKey(), p.examDate);
          if (days < 0) return "";
          return '<div class="card card-dark" data-reveal><div class="row-between">' +
            '<div><span class="eyebrow" style="color:var(--gold-300)">' + t("dash.examDate") + "</span>" +
            '<h3 style="color:var(--ivory);margin-top:var(--sp-2)">' + days + " " + t("dash.daysLeft") + "</h3>" +
            '<p class="muted" style="font-size:var(--fs-2xs);margin-top:4px">' + U.fmtDate(p.examDate, TLA.i18n.get()) + "</p></div>" +
            '<a class="btn btn-gold btn-sm" href="#/exams/multilevel">' + t("exam.mock") + "</a></div></div>";
        })()
        : "";

      const taskList = [
        { id: "vocab", label: "5 ta yangi so‘z", href: "#/dictionary" },
        { id: "lesson", label: "1 ta dars", href: nextLesson ? "#/lesson/" + nextLesson.id : "#/learn" },
        { id: "listening", label: "Tinglash mashqi", href: "#/tests?skill=listening" },
        { id: "test", label: "Qisqa test", href: "#/test/daily-challenge" }
      ];

      return TLA.ui.pageHead({
        eyebrow: t("dash.welcomeBack"),
        title: user.name.split(" ")[0] + ", " + (s.streak > 1 ? "seriyangiz davom etmoqda 🔥" : "bugun ham davom etamiz"),
        lead: "Kabinetda joriy darajangiz, bugungi vazifalar va zaif ko‘nikmalar bo‘yicha tavsiyalar jamlangan."
      }) +
        '<section class="section"><div class="container">' +
        '<div class="grid grid-4" style="gap:var(--sp-3);margin-bottom:var(--sp-6)" data-reveal>' +
        '<div class="stat-tile"><div class="k">' + t("dash.level") + '</div><div class="v">' + (s.level ? s.level.toUpperCase() : "—") +
        '</div><div class="d">' + (p.targetLevel ? t("dash.targetLevel") + ": " + p.targetLevel.toUpperCase() : "") + "</div></div>" +
        '<div class="stat-tile"><div class="k">' + t("dash.streak") + '</div><div class="v">🔥 ' + s.streak + '</div><div class="d">' + t("dash.days") + "</div></div>" +
        '<div class="stat-tile"><div class="k">' + t("dash.xp") + '</div><div class="v">' + U.fmtNumber(s.xp) + '</div><div class="d">+' + TLA.state.xpToday() + " bugun</div></div>" +
        '<div class="stat-tile"><div class="k">' + t("dash.avgScore") + '</div><div class="v">' + s.avg + '%</div><div class="d">' + s.tests + " " + t("dash.testsDone").toLowerCase() + "</div></div>" +
        "</div>" +

        '<div class="dash-grid">' +
        '<div class="stack-lg">' +

        '<div class="dash-hero" data-reveal>' +
        '<div class="row-between row-wrap" style="gap:var(--sp-4)">' +
        "<div style='min-width:0'>" +
        '<span class="eyebrow" style="color:var(--gold-300)">' + t("dash.continueLearning") + "</span>" +
        '<h2 style="color:var(--ivory);margin:var(--sp-3) 0;font-size:var(--fs-2xl)">' +
        (nextLesson ? U.esc(nextLesson.titleUz) : U.esc(course.titleUz) + " — yakunlangan") + "</h2>" +
        '<p class="muted">' + U.esc(course.titleUz) + " · " + prog.done + "/" + prog.total + " " + t("courses.lessons") + "</p>" +
        '<div class="progress jade" style="margin-top:var(--sp-4);max-width:320px"><span style="width:' + prog.pct + '%"></span></div>' +
        "</div>" +
        '<a class="btn btn-gold" href="' + (nextLesson ? "#/lesson/" + nextLesson.id : "#/learn/" + course.id) + '">' +
        (nextLesson ? t("action.continue") : t("action.open")) + "</a>" +
        "</div></div>" +

        '<div class="card" data-reveal>' +
        '<div class="row-between" style="margin-bottom:var(--sp-4)"><h3>' + t("dash.challenge") + "</h3>" +
        '<span class="badge badge-gold">' + t("misc.xpEarned", { n: 20 }) + "</span></div>" +
        '<p class="muted" style="font-size:var(--fs-sm)">' + t("dash.challengeD") + "</p>" +
        '<a class="btn btn-primary btn-arrow" style="margin-top:var(--sp-4)" href="#/test/daily-challenge">' +
        t("dash.challengeCta") + ' <span class="arw">→</span></a></div>' +

        '<div class="card" data-reveal><h3>' + t("dash.todayTasks") + "</h3>" +
        '<div style="margin-top:var(--sp-4)">' +
        taskList.map(x => '<div class="task-item ' + (tasks[x.id] ? "done" : "") + '">' +
          '<button class="tbox" data-task="' + x.id + '" aria-label="' + U.attr(x.label) + '">✓</button>' +
          '<a class="tlabel" href="' + x.href + '" style="flex:1">' + U.esc(x.label) + "</a>" +
          '<span class="muted" style="font-size:var(--fs-2xs)">+5 XP</span></div>').join("") +
        "</div></div>" +

        '<div class="card" data-reveal>' +
        '<div class="row-between" style="margin-bottom:var(--sp-4)"><h3>' + t("dash.recommended") + "</h3>" +
        '<a class="btn btn-quiet btn-sm" href="#/progress">' + t("nav.progress") + " →</a></div>" +
        '<div class="rec-list">' +
        recs.map(r => '<a class="rec-item" href="' + r.href + '"><span style="flex:1"><strong style="font-size:var(--fs-sm)">' +
          U.esc(r.titleUz) + '</strong><br><span class="muted" style="font-size:var(--fs-2xs)">' + U.esc(r.metaUz) +
          '</span></span><span class="arw">→</span></a>').join("") +
        "</div></div>" +

        '<div class="card" data-reveal>' +
        '<div class="row-between" style="margin-bottom:var(--sp-4)"><h3>' + t("dash.recent") + "</h3>" +
        '<a class="btn btn-quiet btn-sm" href="#/progress">' + t("action.viewAll") + "</a></div>" +
        (attempts.length
          ? '<div class="stack-sm">' + attempts.map(a => '<a class="attempt-row" href="#/result/' + a.id + '">' +
            '<span class="badge ' + (a.score >= 75 ? "badge-jade" : a.score >= 50 ? "badge-warn" : "badge-red") + '">' + a.score + "%</span>" +
            '<span style="min-width:0;overflow:hidden;text-overflow:ellipsis">' + U.esc(a.titleUz) + "</span>" +
            '<span class="muted" style="font-size:var(--fs-2xs)">' + U.fmtDate(a.at, TLA.i18n.get()) + "</span>" +
            '<span class="arw">→</span></a>').join("") + "</div>"
          : TLA.ui.emptyState("◉", t("empty.tests"), t("dash.noAttempts"),
            '<a class="btn btn-primary" href="#/test/diagnostic">' + t("empty.testsCta") + "</a>")) +
        "</div>" +

        "</div>" +

        '<aside class="stack-lg">' +
        examCountdown +
        '<div class="card" data-reveal><h4>' + t("dash.streak") + "</h4>" +
        '<div class="streak-strip" style="margin-top:var(--sp-4)">' +
        week.map(d => '<div class="streak-day ' + (d.on ? "on" : "") + (d.today ? " today" : "") + '">' + d.label + "</div>").join("") +
        "</div>" +
        '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-3)">Eng uzun seriya: <b>' + (p.bestStreak || 0) + "</b> " + t("dash.days") + "</p></div>" +

        (due.length
          ? '<div class="card" data-reveal><h4>' + t("dict.reviewDue") + "</h4>" +
            '<p class="muted" style="font-size:var(--fs-sm);margin-top:var(--sp-2)">' + due.length + " ta so‘z takrorlash vaqti keldi.</p>" +
            '<a class="btn btn-soft btn-block btn-sm" style="margin-top:var(--sp-3)" href="#/dictionary?due=1">' + t("dict.review") + "</a></div>"
          : "") +

        '<div class="card" data-reveal><div class="row-between" style="margin-bottom:var(--sp-4)"><h4>' + t("dash.achievements") + "</h4>" +
        '<span class="badge">' + p.achievements.length + "/" + TLA.data.achievements.length + "</span></div>" +
        '<div class="grid" style="grid-template-columns:repeat(3,1fr);gap:var(--sp-2)">' +
        TLA.data.achievements.map(a => '<div class="badge-tile ' + (TLA.state.hasAchievement(a.id) ? "" : "locked") + '" title="' +
          U.attr(a.uz) + '"><span class="bg-ico">' + a.icon + '</span><span class="bg-nm">' + U.esc(a.uz) + "</span></div>").join("") +
        "</div></div>" +

        '<div class="card" data-reveal><h4>' + t("dash.studyTime") + "</h4>" +
        '<div class="v" style="font-family:var(--font-display);font-size:var(--fs-3xl);margin-top:var(--sp-2)">' + s.hours +
        '<span style="font-size:var(--fs-md)"> ' + t("dash.hours") + "</span></div>" +
        '<p class="muted" style="font-size:var(--fs-2xs)">Kundalik maqsad: ' + (p.dailyMinutes || 30) + " daqiqa</p>" +
        '<a class="btn btn-ghost btn-block btn-sm" style="margin-top:var(--sp-4)" href="#/certificates">' + t("nav.certificates") + "</a></div>" +
        "</aside></div></div></section>";
    },

    mounted: function () {
      U.$$("[data-task]").forEach(function (btn) {
        btn.addEventListener("click", function () {
          const added = TLA.state.completeTask(btn.dataset.task);
          if (added) {
            btn.closest(".task-item").classList.add("done");
            TLA.ui.toast(t("misc.xpEarned", { n: 5 }), "xp");
            TLA.ui.renderHeader();
          }
        });
      });
    },
    meta: { title: "Kabinet — Tatbiqul Lisan Academy", desc: "Shaxsiy o‘quv kabineti: progress, vazifalar va tavsiyalar." }
  };

  /* ================= Progress ================= */
  TLA.pages.progress = {
    render: function () {
      if (!TLA.state.isAuthed()) return requireAuth(t("nav.progress"));
      const p = TLA.state.profile();
      const s = TLA.state.stats();
      const attempts = TLA.state.attempts();
      const trend = attempts.slice(0, 10).reverse().map((a, i) => ({ label: String(i + 1), value: a.score }));
      const skillSeries = Object.keys(p.skills).map(k => ({ label: t("misc.skill." + k), value: p.skills[k] }));

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.dashboard"), href: "#/dashboard" }, { label: t("nav.progress") }],
        eyebrow: t("nav.progress"),
        title: "Natijalar tahlili",
        lead: "Har bir ko‘nikma alohida kuzatiladi — shuning uchun keyingi qadam har doim aniq."
      }) +
        '<section class="section"><div class="container">' +
        '<div class="grid grid-4" style="gap:var(--sp-3);margin-bottom:var(--sp-6)" data-reveal>' +
        '<div class="stat-tile"><div class="k">' + t("dash.testsDone") + '</div><div class="v">' + s.tests + "</div></div>" +
        '<div class="stat-tile"><div class="k">' + t("dash.avgScore") + '</div><div class="v">' + s.avg + "%</div></div>" +
        '<div class="stat-tile"><div class="k">' + t("courses.lessons") + '</div><div class="v">' + s.lessons + "</div></div>" +
        '<div class="stat-tile"><div class="k">' + t("dash.studyTime") + '</div><div class="v">' + s.hours + "</div><div class='d'>" + t("dash.hours") + "</div></div>" +
        "</div>" +

        '<div class="grid grid-2">' +
        '<div class="card" data-reveal><h3>Ball dinamikasi</h3>' +
        '<div style="margin-top:var(--sp-4)">' +
        TLA.charts.line(trend, { emptyText: "Grafik uchun kamida ikkita test natijasi kerak." }) + "</div></div>" +
        '<div class="card" data-reveal><h3>' + t("result.breakdown") + "</h3>" +
        (skillSeries.length
          ? '<div style="margin-top:var(--sp-4)">' + TLA.charts.shamsa(skillSeries, {}) + "</div>"
          : '<p class="muted" style="margin-top:var(--sp-4)">Birinchi testdan so‘ng ko‘nikmalar diagrammasi shakllanadi.</p>') +
        "</div></div>" +

        '<div class="card" style="margin-top:var(--sp-6)" data-reveal><h3>Kurslar bo‘yicha progress</h3>' +
        '<div class="stack" style="margin-top:var(--sp-4)">' +
        TLA.data.courses.map(function (c) {
          const pr = TLA.state.courseProgress(c.id);
          return '<div class="meter-row"><span class="lbl">' + U.esc(c.titleUz) + '</span><span class="val">' +
            pr.done + "/" + pr.total + '</span><span class="progress jade"><span style="width:' + pr.pct + '%"></span></span></div>';
        }).join("") + "</div></div>" +

        '<div class="card" style="margin-top:var(--sp-6)" data-reveal>' +
        '<div class="row-between" style="margin-bottom:var(--sp-4)"><h3>' + t("profile.history") + "</h3>" +
        '<span class="badge">' + attempts.length + "</span></div>" +
        (attempts.length
          ? '<div class="table-wrap"><table class="tbl"><thead><tr><th>' + t("misc.date") + "</th><th>Test</th><th>" +
            t("misc.score") + "</th><th>" + t("misc.level") + '</th><th style="text-align:end">' + t("misc.actions") + "</th></tr></thead><tbody>" +
            attempts.map(a => "<tr><td>" + U.fmtDate(a.at, TLA.i18n.get()) + "</td><td>" + U.esc(a.titleUz) + "</td>" +
              '<td><span class="badge ' + (a.score >= 75 ? "badge-jade" : "badge-warn") + '">' + a.score + "%</span></td>" +
              "<td>" + (a.level ? a.level.toUpperCase() : "—") + "</td>" +
              '<td style="text-align:end"><a class="btn btn-quiet btn-sm" href="#/result/' + a.id + '">' + t("action.open") + "</a></td></tr>").join("") +
            "</tbody></table></div>"
          : TLA.ui.emptyState("◔", t("empty.tests"), t("dash.noAttempts"),
            '<a class="btn btn-primary" href="#/test/diagnostic">' + t("empty.testsCta") + "</a>")) +
        "</div></div></section>";
    },
    meta: { title: "Natijalar tahlili — Tatbiqul Lisan Academy", desc: "Ko‘nikmalar bo‘yicha progress va test tarixi." }
  };

  /* ================= Certificates ================= */
  /** Eight-fold girih rosette used as the certificate colophon. */
  function rosetteSvg() {
    const cx = 60, cy = 60;
    function ring(r, rotation, cls) {
      let d = "";
      for (let i = 0; i < 8; i++) {
        const a = rotation + (Math.PI / 4) * i;
        const x = cx + r * Math.cos(a);
        const y = cy + r * Math.sin(a);
        d += (i === 0 ? "M" : "L") + x.toFixed(1) + " " + y.toFixed(1);
      }
      return '<path class="' + cls + '" d="' + d + ' Z"/>';
    }
    return '<svg class="c-rosette" viewBox="0 0 120 120" aria-hidden="true">' +
      ring(56, 0, "p1") + ring(56, Math.PI / 8, "p1") +
      ring(34, Math.PI / 8, "p2") + ring(34, 0, "p2") +
      '<circle cx="60" cy="60" r="13" class="p2"/></svg>';
  }

  function certificateMarkup(cert) {
    const cfg = TLA.state.config();
    const url = (cfg.verifyBaseUrl || "https://example.org/verify/") + cert.id;
    return '<div class="cert-frame" id="cert-' + cert.id + '"><div class="cert-inner">' +
      '<div class="c-acad">TATBIQUL LISAN ACADEMY</div>' +
      '<div class="c-ar">أكاديمية تطبيق اللسان</div>' +
      '<div class="c-kicker">Sertifikat · شهادة</div>' +
      '<div class="c-name">' + U.esc(cert.name) + "</div>" +
      '<div class="c-desc">' + U.esc(cert.titleUz) + (cert.level ? " · " + String(cert.level).toUpperCase() : "") +
      (cert.score ? " · " + cert.score + "%" : "") + "</div>" +
      '<div class="c-desc" style="margin-top:1%">' +
      (cert.kind === "mock" ? "Mock imtihonda yuqori natija uchun" : "Kursni muvaffaqiyatli yakunlagani uchun") + "</div>" +
      '<div class="c-body">' + rosetteSvg() +
      '<div class="c-blessing">وَفَّقَكَ اللهُ فِي طَلَبِ الْعِلْمِ</div></div>' +
      '<div class="c-foot">' +
      '<div class="c-meta">ID: ' + U.esc(cert.id) + "<br>" +
      U.fmtDate(cert.issued, "uz") + "<br>" + U.esc(url) + "</div>" +
      '<div class="cert-seal">ت</div>' +
      '<div class="qr-box">' + TLA.qr.svg(url) + "</div>" +
      "</div></div></div>";
  }

  TLA.pages.certificates = {
    render: function () {
      if (!TLA.state.isAuthed()) return requireAuth(t("nav.certificates"));
      const certs = TLA.state.profile().certificates;

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.dashboard"), href: "#/dashboard" }, { label: t("nav.certificates") }],
        eyebrow: t("nav.certificates"),
        title: t("cert.title"),
        lead: t("cert.sub"),
        extra: '<div class="row" style="margin-top:var(--sp-4)"><a class="btn btn-ghost btn-sm" href="#/verify">' + t("cert.verify") + "</a></div>"
      }) +
        '<section class="section"><div class="container">' +
        (certs.length
          ? certs.map(c => '<div class="card" style="margin-bottom:var(--sp-6)" data-reveal>' +
            '<div class="row-between row-wrap" style="margin-bottom:var(--sp-4);gap:var(--sp-3)">' +
            "<div><h3>" + U.esc(c.titleUz) + '</h3><p class="muted mono" style="font-size:var(--fs-2xs);margin-top:4px">' +
            t("cert.id") + ": " + U.esc(c.id) + " · " + U.fmtDate(c.issued, TLA.i18n.get()) + "</p></div>" +
            '<div class="row" style="gap:var(--sp-2)">' +
            '<button class="btn btn-ghost btn-sm no-print" data-action="copy" data-text="' + U.attr(c.id) + '">' + t("action.copy") + " ID</button>" +
            '<button class="btn btn-primary btn-sm no-print" data-action="print">' + t("action.print") + "</button></div></div>" +
            certificateMarkup(c) + "</div>").join("")
          : TLA.ui.emptyState("✦", t("cert.none"), t("cert.earn"),
            '<a class="btn btn-primary" href="#/learn">' + t("action.explore") + "</a>")) +
        TLA.ui.complianceNote(t("cert.disclaimer")) +
        "</div></section>";
    },
    meta: { title: "Sertifikatlar — Tatbiqul Lisan Academy", desc: "Kurs va mock imtihon sertifikatlari, tekshirish kodi bilan." }
  };

  TLA.pages.verify = {
    render: function (params) {
      const q = params.query.id || "";
      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("cert.verify") }],
        eyebrow: t("nav.certificates"),
        title: t("cert.verify"),
        lead: "Sertifikat ID sini kiriting — tizim uning haqiqiyligini tekshiradi."
      }) +
        '<section class="section"><div class="container container-narrow">' +
        '<div class="card" data-reveal>' +
        '<div class="row row-wrap" style="gap:var(--sp-3)">' +
        '<input class="input" id="verifyInput" style="flex:1;min-width:240px" placeholder="' + U.attr(t("cert.verifyPlaceholder")) + '" value="' + U.attr(q) + '">' +
        '<button class="btn btn-primary" id="verifyBtn">' + t("action.verify") + "</button></div>" +
        '<div id="verifyResult" style="margin-top:var(--sp-5)"></div>' +
        "</div>" +
        TLA.ui.complianceNote(t("cert.disclaimer")) +
        "</div></section>";
    },
    mounted: function (params) {
      const input = U.$("#verifyInput");
      const out = U.$("#verifyResult");
      function run() {
        const id = (input.value || "").trim();
        if (!id) { out.innerHTML = ""; return; }
        const cert = TLA.state.findCertificate(id);
        if (!cert) {
          out.innerHTML = '<div class="alert alert-danger"><span class="ico">✕</span><span>' + t("cert.invalid") + "</span></div>";
          return;
        }
        out.innerHTML = '<div class="alert alert-success"><span class="ico">✓</span><span>' + t("cert.valid") + "</span></div>" +
          '<div class="table-wrap" style="margin-top:var(--sp-4)"><table class="tbl"><tbody>' +
          "<tr><th>" + t("cert.holder") + "</th><td>" + U.esc(cert.name) + "</td></tr>" +
          "<tr><th>" + t("cert.course") + "</th><td>" + U.esc(cert.titleUz) + "</td></tr>" +
          "<tr><th>" + t("misc.level") + "</th><td>" + U.esc(String(cert.level || "—").toUpperCase()) + "</td></tr>" +
          "<tr><th>" + t("cert.issued") + "</th><td>" + U.fmtDate(cert.issued, TLA.i18n.get()) + "</td></tr>" +
          "<tr><th>" + t("cert.id") + '</th><td class="mono">' + U.esc(cert.id) + "</td></tr>" +
          "</tbody></table></div>";
      }
      U.$("#verifyBtn").addEventListener("click", run);
      input.addEventListener("keydown", e => { if (e.key === "Enter") run(); });
      if (params.query.id) run();
    },
    meta: { title: "Sertifikatni tekshirish — Tatbiqul Lisan Academy", desc: "Sertifikat ID orqali haqiqiylikni tekshirish." }
  };

  /* ================= Profile ================= */
  TLA.pages.profile = {
    render: function () {
      if (!TLA.state.isAuthed()) return requireAuth(t("nav.profile"));
      const user = TLA.state.currentUser();
      const p = TLA.state.profile();
      const st = TLA.state.settings();
      const vocab = Object.keys(p.vocab);

      const toggle = (id, label, desc, checked) =>
        '<label class="row-between" style="gap:var(--sp-4);padding:var(--sp-3) 0">' +
        '<span style="flex:1"><strong style="font-size:var(--fs-sm)">' + U.esc(label) + "</strong>" +
        (desc ? '<br><span class="muted" style="font-size:var(--fs-2xs)">' + U.esc(desc) + "</span>" : "") + "</span>" +
        '<span class="switch"><input type="checkbox" data-toggle="' + id + '"' + (checked ? " checked" : "") +
        '><span class="track"></span></span></label>';

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.dashboard"), href: "#/dashboard" }, { label: t("nav.profile") }],
        eyebrow: t("nav.profile"),
        title: user.name,
        lead: user.email + " · " + (user.role === "student" ? "Talaba" : user.role)
      }) +
        '<section class="section"><div class="container">' +
        '<div class="dash-grid">' +
        '<div class="stack-lg">' +

        '<div class="card" data-reveal><h3>' + t("profile.title") + "</h3>" +
        '<div class="grid grid-2" style="margin-top:var(--sp-4);gap:var(--sp-4)">' +
        '<label class="field"><span class="label">' + t("profile.name") + '</span><input class="input" id="pfName" value="' + U.attr(user.name) + '"></label>' +
        '<label class="field"><span class="label">' + t("profile.email") + '</span><input class="input" id="pfEmail" value="' + U.attr(user.email) + '" type="email"></label>' +
        '<label class="field"><span class="label">' + t("dash.targetLevel") + '</span><select class="select" id="pfTarget">' +
        TLA.data.levels.map(l => '<option value="' + l.id + '"' + (p.targetLevel === l.id ? " selected" : "") + ">" + l.code + "</option>").join("") +
        "</select></label>" +
        '<label class="field"><span class="label">' + t("dash.examDate") + '</span><input class="input" type="date" id="pfExam" value="' + U.attr(p.examDate || "") + '"></label>' +
        "</div>" +
        '<button class="btn btn-primary" style="margin-top:var(--sp-4)" id="pfSave">' + t("action.save") + "</button></div>" +

        '<div class="card" data-reveal><h3>' + t("profile.savedVocab") + " (" + vocab.length + ")</h3>" +
        (vocab.length
          ? '<div class="row row-wrap" style="gap:var(--sp-2);margin-top:var(--sp-4)">' +
            vocab.map(w => '<span class="chip ar-ui">' + w + '<button data-action="save-word" data-word="' + U.attr(w) +
              '" aria-label="' + t("action.delete") + '" style="margin-inline-start:6px">✕</button></span>').join("") + "</div>"
          : '<p class="muted" style="margin-top:var(--sp-3);font-size:var(--fs-sm)">' + t("empty.vocabD") + "</p>") +
        '<a class="btn btn-ghost btn-sm" style="margin-top:var(--sp-4)" href="#/dictionary">' + t("nav.dictionary") + "</a></div>" +

        '<div class="card" data-reveal><h3>' + t("profile.notifications") + "</h3>" +
        '<div style="margin-top:var(--sp-3)">' +
        toggle("notif.lessons", "Yangi darslar", "Kurs yangilanganda xabar berish", st.notif.lessons) +
        toggle("notif.tests", "Test eslatmalari", "Rejalashtirilgan mashq vaqti kelganda", st.notif.tests) +
        toggle("notif.streak", "Seriya eslatmasi", "Kunlik mashqni o‘tkazib yubormaslik uchun", st.notif.streak) +
        toggle("notif.marketing", "Yangiliklar va aksiyalar", "Yangi kurslar va chegirmalar haqida", st.notif.marketing) +
        "</div>" +
        TLA.ui.complianceNote("Telegram orqali bildirishnomalar backend ulangandan so‘ng ishlaydi; token va kalitlar hech qachon frontendda saqlanmaydi.") +
        "</div>" +

        '<div class="card" data-reveal><h3>' + t("profile.privacy") + "</h3>" +
        '<div style="margin-top:var(--sp-3)">' +
        toggle("publicRank", t("profile.publicRank"), t("profile.publicRankD"), st.publicRank) +
        toggle("analytics", "Foydalanish statistikasi", "Faqat anonim hodisalar (sahifa, test, dars) — shaxsiy ma’lumotsiz", st.analytics) +
        "</div>" +
        '<div class="row row-wrap" style="gap:var(--sp-3);margin-top:var(--sp-4)">' +
        '<button class="btn btn-ghost btn-sm" id="pfExport">' + t("profile.dataExport") + "</button>" +
        '<button class="btn btn-danger btn-sm" id="pfDelete">' + t("profile.dataDelete") + "</button></div>" +
        '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-3)">Ma’lumotlar shu qurilmada saqlanadi (' +
        TLA.store.driver + "). Backend ulangach, o‘chirish so‘rovi serverga yuboriladi.</p></div>" +

        "</div>" +

        '<aside class="stack-lg">' +
        '<div class="card text-center" data-reveal>' +
        '<span class="avatar avatar-lg" style="margin:0 auto var(--sp-4)">' + U.esc(U.initials(user.name)) + "</span>" +
        "<h4>" + U.esc(user.name) + '</h4><p class="muted" style="font-size:var(--fs-2xs)">' + U.esc(user.email) + "</p>" +
        '<div class="row" style="justify-content:center;gap:var(--sp-2);margin-top:var(--sp-4)">' +
        '<span class="badge badge-gold">✦ ' + U.fmtNumber(p.xp) + " XP</span>" +
        '<span class="badge">🔥 ' + p.streak + "</span></div></div>" +

        '<div class="card" data-reveal><h4>' + t("profile.theme") + "</h4>" +
        '<div class="segmented" style="margin-top:var(--sp-3)">' +
        '<button data-theme-set="light" aria-pressed="' + (st.theme === "light") + '">Light</button>' +
        '<button data-theme-set="dark" aria-pressed="' + (st.theme === "dark") + '">Dark</button></div>' +
        "<h4 style='margin-top:var(--sp-5)'>" + t("profile.language") + "</h4>" +
        '<div class="segmented" style="margin-top:var(--sp-3)">' +
        TLA.i18n.available().map(l => '<button data-action="set-lang" data-lang="' + l + '" aria-pressed="' +
          (TLA.i18n.get() === l) + '">' + l.toUpperCase() + "</button>").join("") + "</div>" +
        "<h4 style='margin-top:var(--sp-5)'>" + t("profile.fontSize") + "</h4>" +
        '<div class="segmented" style="margin-top:var(--sp-3)">' +
        [["0.95", "A−"], ["1", "A"], ["1.1", "A+"]].map(f => '<button data-font-set="' + f[0] + '" aria-pressed="' +
          (String(st.fontScale) === f[0]) + '">' + f[1] + "</button>").join("") + "</div>" +
        "<h4 style='margin-top:var(--sp-5)'>" + t("profile.motion") + "</h4>" +
        '<div class="segmented" style="margin-top:var(--sp-3)">' +
        '<button data-motion-set="on" aria-pressed="' + (st.motion !== "off") + '">' + t("misc.yes") + "</button>" +
        '<button data-motion-set="off" aria-pressed="' + (st.motion === "off") + '">' + t("misc.no") + "</button></div></div>" +

        '<div class="card" data-reveal><h4>' + t("nav.leaderboard") + "</h4>" +
        '<p class="muted" style="font-size:var(--fs-2xs);margin-top:var(--sp-2)">Reytingda faqat rozilik bergan foydalanuvchilar ko‘rinadi.</p>' +
        '<a class="btn btn-ghost btn-block btn-sm" style="margin-top:var(--sp-3)" href="#/leaderboard">' + t("action.open") + "</a></div>" +
        "</aside></div></div></section>";
    },

    mounted: function () {
      const user = TLA.state.currentUser();
      const p = TLA.state.profile();

      U.$("#pfSave").addEventListener("click", function () {
        const name = U.$("#pfName").value.trim();
        const email = U.$("#pfEmail").value.trim();
        if (name.length < 2) return TLA.ui.toast(t("auth.errName"), "error");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return TLA.ui.toast(t("auth.errEmail"), "error");
        TLA.state.updateUser({ name: name, email: email.toLowerCase() });
        p.targetLevel = U.$("#pfTarget").value;
        p.examDate = U.$("#pfExam").value;
        TLA.ui.toast(t("action.save"), "success");
        TLA.ui.renderShell();
      });

      U.$$("[data-toggle]").forEach(function (input) {
        input.addEventListener("change", function () {
          const key = input.dataset.toggle;
          if (key.indexOf("notif.") === 0) TLA.state.setNotifPref(key.split(".")[1], input.checked);
          else TLA.state.setSetting(key, input.checked);
          TLA.ui.toast(t("action.save"), "success");
        });
      });

      U.$$("[data-theme-set]").forEach(b => b.addEventListener("click", function () {
        TLA.state.setSetting("theme", b.dataset.themeSet);
        TLA.ui.applySettings();
        TLA.router.rerender();
      }));
      U.$$("[data-font-set]").forEach(b => b.addEventListener("click", function () {
        TLA.state.setSetting("fontScale", Number(b.dataset.fontSet));
        TLA.ui.applySettings();
        TLA.router.rerender();
      }));
      U.$$("[data-motion-set]").forEach(b => b.addEventListener("click", function () {
        TLA.state.setSetting("motion", b.dataset.motionSet);
        TLA.ui.applySettings();
        TLA.router.rerender();
      }));

      U.$("#pfExport").addEventListener("click", function () {
        const blob = new Blob([TLA.state.exportData()], { type: "application/json" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "tatbiqul-lisan-data.json";
        a.click();
        URL.revokeObjectURL(a.href);
        TLA.ui.toast(t("profile.dataExport"), "success");
      });

      U.$("#pfDelete").addEventListener("click", function () {
        TLA.ui.confirmDialog(t("profile.dataDelete"), t("profile.deleteConfirm"), t("action.delete"), function () {
          TLA.state.deleteAccount();
          TLA.ui.renderShell();
          TLA.router.go("#/");
          TLA.ui.toast("Hisob o‘chirildi.", "info");
        }, true);
      });
    },
    meta: { title: "Profil — Tatbiqul Lisan Academy", desc: "Profil sozlamalari, maxfiylik va bildirishnomalar." }
  };

  /* ================= Leaderboard ================= */
  TLA.pages.leaderboard = {
    render: function () {
      const me = TLA.state.currentUser();
      const st = TLA.state.settings();
      const rows = TLA.state.allUsers()
        .map(function (u) {
          const prof = TLA.state.profileOf(u.id);
          return { id: u.id, name: u.name, xp: prof.xp || 0, tests: (prof.attempts || []).length };
        })
        .filter(r => r.xp > 0)
        .sort((a, b) => b.xp - a.xp)
        .slice(0, 20);

      return TLA.ui.pageHead({
        crumbs: [{ label: t("nav.home"), href: "#/" }, { label: t("nav.leaderboard") }],
        eyebrow: t("nav.leaderboard"),
        title: "Haftalik reyting",
        lead: "Reyting faqat ro‘yxatdan o‘tgan va ochiq ko‘rinishga rozilik bergan foydalanuvchilardan tuziladi. Soxta ishtirokchilar ko‘rsatilmaydi."
      }) +
        '<section class="section"><div class="container container-narrow">' +
        (me && !st.publicRank
          ? '<div class="alert alert-warn" style="margin-bottom:var(--sp-5)"><span class="ico">◔</span><span>' +
            "Siz reytingda ko‘rinmayapsiz. Profil → Maxfiylik bo‘limidan yoqishingiz mumkin.</span></div>"
          : "") +
        (rows.length
          ? rows.map(function (r, i) {
            const isMe = me && r.id === me.id;
            const hidden = isMe && !st.publicRank;
            return '<div class="leaderboard-row ' + (i < 3 ? "top " : "") + (isMe ? "me" : "") + '">' +
              '<span class="rank">' + (i + 1) + "</span>" +
              '<span class="row" style="gap:var(--sp-3);min-width:0"><span class="avatar avatar-sm">' +
              U.esc(U.initials(hidden ? "—" : r.name)) + "</span>" +
              "<span>" + U.esc(hidden ? "Yashirilgan" : r.name) + (isMe ? " (siz)" : "") + "</span></span>" +
              '<span class="badge badge-gold">✦ ' + U.fmtNumber(r.xp) + "</span>" +
              '<span class="muted" style="font-size:var(--fs-2xs)">' + r.tests + " test</span></div>";
          }).join("")
          : TLA.ui.emptyState("♛", "Reyting hali bo‘sh", "Birinchi testni topshiring va XP to‘plang — ismingiz shu yerda paydo bo‘ladi.",
            '<a class="btn btn-primary" href="#/test/diagnostic">' + t("empty.testsCta") + "</a>")) +
        TLA.ui.complianceNote("Reytingda faqat ism va XP ko‘rsatiladi. Email, natijalar tafsiloti va boshqa shaxsiy ma’lumotlar hech qachon ochilmaydi.") +
        "</div></section>";
    },
    meta: { title: "Reyting — Tatbiqul Lisan Academy", desc: "Haftalik XP reytingi (ixtiyoriy ishtirok)." }
  };
})();
