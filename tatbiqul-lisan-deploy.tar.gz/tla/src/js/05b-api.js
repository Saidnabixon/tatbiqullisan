/* ============================================================
   API — thin client for the optional backend (backend/server.py).

   Design goal: the rest of the app (06-state.js) should be able to
   "try the backend, fall back to local-only" without caring about
   fetch/token plumbing. This module draws one important distinction:

     - a NETWORK failure (backend not running, DNS/CORS error, timeout)
       REJECTS the returned promise — callers catch this and fall back
       to the local-only demo behaviour, so the static site keeps
       working standalone exactly as it did before a backend existed.

     - an API-level failure (wrong password, duplicate email — the
       backend IS reachable and answered) RESOLVES normally with
       {ok:false, error, message} — callers must NOT fall back to
       local logic for this case, since that would silently create a
       confusing local ghost account instead of reporting the real
       validation error.
   ============================================================ */
window.TLA = window.TLA || {};

TLA.api = (function () {
  "use strict";

  const TOKEN_KEY = "tla_auth_token";
  const TIMEOUT_MS = 8000;
  let memoryToken = null; // fallback if localStorage is unavailable (e.g. private mode)

  function base() {
    const cfg = window.TLA_SITE_CONFIG || {};
    return (cfg.apiBase || "").replace(/\/$/, ""); // "" = same origin, relative paths
  }

  function getToken() {
    try {
      return localStorage.getItem(TOKEN_KEY) || memoryToken;
    } catch (e) {
      return memoryToken;
    }
  }

  function setToken(token) {
    memoryToken = token;
    try {
      if (token) localStorage.setItem(TOKEN_KEY, token);
      else localStorage.removeItem(TOKEN_KEY);
    } catch (e) { /* private browsing or storage disabled — memory still holds it for this tab */ }
  }

  function clearToken() { setToken(null); }

  /**
   * Low-level request helper.
   * Throws (rejects) only on network-level failure — callers rely on
   * this to decide whether the backend is reachable at all.
   */
  async function request(method, path, body, useAuth, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs || TIMEOUT_MS);
    const headers = { "Content-Type": "application/json" };
    if (useAuth) {
      const token = getToken();
      if (token) headers.Authorization = "Bearer " + token;
    }

    let res;
    try {
      res = await fetch(base() + path, {
        method: method,
        headers: headers,
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal
      });
    } finally {
      clearTimeout(timer);
    }

    let data = {};
    try { data = await res.json(); } catch (e) { /* empty/non-JSON body */ }

    if (!res.ok) {
      return { ok: false, status: res.status, error: data.error || "unknown", message: data.message || "" };
    }
    return Object.assign({ ok: true, status: res.status }, data);
  }

  /** True once we've confirmed the backend answered at least once. Lets the
   *  UI avoid repeating the "running in local-only mode" notice every call. */
  let backendConfirmedUnreachable = false;

  async function health() {
    try {
      const r = await request("GET", "/api/health", null, false);
      backendConfirmedUnreachable = !r.ok;
      return r.ok;
    } catch (e) {
      backendConfirmedUnreachable = true;
      return false;
    }
  }

  async function register(name, email, password) {
    return request("POST", "/api/auth/register", { name: name, email: email, password: password }, false);
  }

  async function login(email, password) {
    return request("POST", "/api/auth/login", { email: email, password: password }, false);
  }

  async function logout() {
    try {
      return await request("POST", "/api/auth/logout", null, true);
    } catch (e) {
      return { ok: false }; // best-effort — local session is cleared regardless by the caller
    }
  }

  /** Shorter timeout than register/login: this runs unattended at boot
   *  (session restore), so a slow/hung backend should fail fast rather
   *  than delaying first paint for a returning visitor. */
  async function me() {
    return request("GET", "/api/auth/me", null, true, 3500);
  }

  return {
    getToken, setToken, clearToken, health, register, login, logout, me,
    get wasUnreachable() { return backendConfirmedUnreachable; }
  };
})();
