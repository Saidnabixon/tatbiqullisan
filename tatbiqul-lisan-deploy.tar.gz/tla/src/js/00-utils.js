/* ============================================================
   UTILS — DOM, formatting, events, small helpers
   ============================================================ */
window.TLA = window.TLA || {};

TLA.utils = (function () {
  "use strict";

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  /** Escape untrusted text before it enters innerHTML. */
  function esc(value) {
    if (value === null || value === undefined) return "";
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /** Attribute-safe escape (same rules, kept separate for readability). */
  const attr = esc;

  function clamp(n, min, max) {
    return Math.min(max, Math.max(min, n));
  }

  function pct(part, total) {
    if (!total) return 0;
    return Math.round((part / total) * 100);
  }

  function uid(prefix) {
    return (prefix || "id") + "-" + Math.random().toString(36).slice(2, 9);
  }

  /** Deterministic PRNG so generated tests are reproducible per seed. */
  function seededRandom(seed) {
    let s = 0;
    const str = String(seed);
    for (let i = 0; i < str.length; i++) s = (s * 31 + str.charCodeAt(i)) >>> 0;
    if (s === 0) s = 42;
    return function () {
      s ^= s << 13; s >>>= 0;
      s ^= s >> 17;
      s ^= s << 5; s >>>= 0;
      return s / 4294967296;
    };
  }

  function shuffle(list, rnd) {
    const arr = list.slice();
    const r = rnd || Math.random;
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(r() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  function debounce(fn, wait) {
    let t;
    return function () {
      const args = arguments, ctx = this;
      clearTimeout(t);
      t = setTimeout(() => fn.apply(ctx, args), wait || 200);
    };
  }

  function throttle(fn, wait) {
    let last = 0, timer = null;
    return function () {
      const now = Date.now(), args = arguments, ctx = this;
      if (now - last >= wait) { last = now; fn.apply(ctx, args); }
      else if (!timer) {
        timer = setTimeout(() => { last = Date.now(); timer = null; fn.apply(ctx, args); }, wait - (now - last));
      }
    };
  }

  /** Event delegation bound once on a root node. */
  function delegate(root, type, selector, handler) {
    root.addEventListener(type, function (ev) {
      const target = ev.target.closest(selector);
      if (target && root.contains(target)) handler(ev, target);
    });
  }

  function fmtTime(totalSeconds) {
    const s = Math.max(0, Math.floor(totalSeconds));
    const m = Math.floor(s / 60);
    const r = s % 60;
    return String(m).padStart(2, "0") + ":" + String(r).padStart(2, "0");
  }

  function fmtDuration(minutes, locale) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    const unit = { uz: ["soat", "daqiqa"], en: ["h", "min"], ar: ["ساعة", "دقيقة"] }[locale] || ["soat", "daqiqa"];
    if (h && m) return h + " " + unit[0] + " " + m + " " + unit[1];
    if (h) return h + " " + unit[0];
    return m + " " + unit[1];
  }

  function fmtNumber(n) {
    return new Intl.NumberFormat("ru-RU").format(Math.round(n || 0)).replace(/\u00A0/g, " ");
  }

  function fmtMoney(amount, currency) {
    return fmtNumber(amount) + " " + (currency || "so'm");
  }

  function fmtDate(iso, locale) {
    if (!iso) return "";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    const map = { uz: "ru-RU", en: "en-GB", ar: "ar-EG" };
    try {
      return new Intl.DateTimeFormat(map[locale] || "ru-RU", {
        day: "2-digit", month: "short", year: "numeric"
      }).format(d);
    } catch (e) {
      return d.toISOString().slice(0, 10);
    }
  }

  function todayKey(date) {
    const d = date ? new Date(date) : new Date();
    return d.toISOString().slice(0, 10);
  }

  function daysBetween(aKey, bKey) {
    const a = new Date(aKey + "T00:00:00Z").getTime();
    const b = new Date(bKey + "T00:00:00Z").getTime();
    return Math.round((b - a) / 86400000);
  }

  /** Turns "Salom Dunyo" into "salom-dunyo" for ids and slugs. */
  function slugify(text) {
    return String(text).toLowerCase().trim()
      .replace(/['’]/g, "")
      .replace(/[^a-z0-9\u0600-\u06FF]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  function initials(name) {
    return String(name || "?").trim().split(/\s+/).slice(0, 2).map(w => w[0] || "").join("").toUpperCase();
  }

  /** Naive latin transliteration of Arabic for search matching. */
  function normalizeArabic(text) {
    return String(text)
      .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
      .replace(/[إأآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه");
  }

  function includesLoose(haystack, needle) {
    if (!needle) return true;
    const h = normalizeArabic(String(haystack)).toLowerCase();
    const n = normalizeArabic(String(needle)).toLowerCase();
    return h.indexOf(n) !== -1;
  }

  function animateNumber(node, to, duration) {
    const from = Number(node.dataset.val || 0);
    const start = performance.now();
    const dur = duration || 700;
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) {
      node.textContent = fmtNumber(to); node.dataset.val = to; return;
    }
    function step(now) {
      const p = clamp((now - start) / dur, 0, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      node.textContent = fmtNumber(from + (to - from) * eased);
      if (p < 1) requestAnimationFrame(step);
      else node.dataset.val = to;
    }
    requestAnimationFrame(step);
  }

  function scrollToTop(smooth) {
    window.scrollTo({ top: 0, behavior: smooth === false ? "auto" : "smooth" });
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise((resolve, reject) => {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
        resolve();
      } catch (e) { reject(e); }
    });
  }

  function groupBy(list, keyFn) {
    return list.reduce((acc, item) => {
      const k = keyFn(item);
      (acc[k] = acc[k] || []).push(item);
      return acc;
    }, {});
  }

  function unique(list) { return Array.from(new Set(list)); }

  function average(nums) {
    if (!nums.length) return 0;
    return nums.reduce((a, b) => a + b, 0) / nums.length;
  }

  return {
    $, $$, esc, attr, clamp, pct, uid, seededRandom, shuffle, debounce, throttle,
    delegate, fmtTime, fmtDuration, fmtNumber, fmtMoney, fmtDate, todayKey, daysBetween,
    slugify, initials, normalizeArabic, includesLoose, animateNumber, scrollToTop,
    copyText, groupBy, unique, average
  };
})();
