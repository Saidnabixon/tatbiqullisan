#!/usr/bin/env python3
"""Bundle the modular sources into one self-contained public/index.html.

No network, no npm: every stylesheet and script is inlined in order, so the
result runs from the file system or any static host.

Usage:
    python build.py
"""
import json
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
PUBLIC = os.path.join(ROOT, "public")
CONFIG_FILE = os.path.join(ROOT, "site.config.json")


def read_ordered(folder, extension):
    path = os.path.join(SRC, folder)
    files = sorted(f for f in os.listdir(path) if f.endswith(extension))
    chunks = []
    for name in files:
        with open(os.path.join(path, name), "r", encoding="utf-8") as handle:
            chunks.append("/* ===== %s ===== */\n%s" % (name, handle.read()))
    return files, "\n\n".join(chunks)


def load_site_config():
    if not os.path.exists(CONFIG_FILE):
        print("! site.config.json topilmadi — standart qiymatlar ishlatiladi")
        return {}
    with open(CONFIG_FILE, "r", encoding="utf-8") as handle:
        config = json.load(handle)
    return {k: v for k, v in config.items() if not k.startswith("_")}


def main():
    css_files, css = read_ordered("styles", ".css")
    js_files, js = read_ordered("js", ".js")
    config = load_site_config()

    with open(os.path.join(SRC, "index.template.html"), "r", encoding="utf-8") as handle:
        template = handle.read()

    for token in ("/*<!--CSS-->*/", "/*<!--JS-->*/"):
        if token not in template:
            sys.exit("Template placeholder missing: %s" % token)

    # A literal </script> inside a JS string would close the inline block early.
    if re.search(r"</script", js, flags=re.IGNORECASE):
        sys.exit("Found a literal </script> in JS sources — escape it before bundling")

    config_js = "window.TLA_SITE_CONFIG = %s;\n\n" % json.dumps(config, ensure_ascii=False)

    html = template.replace("/*<!--CSS-->*/", css).replace("/*<!--JS-->*/", config_js + js)

    # Absolute URLs for social preview cards (crawlers cannot resolve relative paths)
    site_url = (config.get("siteUrl") or "").rstrip("/")
    if site_url:
        html = html.replace("__SITE_URL__", site_url)
    else:
        html = re.sub(r'\s*<meta property="og:(image|url)"[^>]*>', "", html)

    os.makedirs(PUBLIC, exist_ok=True)
    out_file = os.path.join(PUBLIC, "index.html")
    with open(out_file, "w", encoding="utf-8") as handle:
        handle.write(html)

    size = os.path.getsize(out_file)
    print("CSS fayllar : %d" % len(css_files))
    print("JS fayllar  : %d" % len(js_files))
    print("Sozlama     : v%s, siteUrl=%s" % (config.get("version", "—"), site_url or "belgilanmagan"))
    print("Natija      : %s (%.1f KB)" % (out_file, size / 1024))
    print()
    print("Deploy qilish uchun 'public/' papkasini hostingga yuklang.")


if __name__ == "__main__":
    main()
