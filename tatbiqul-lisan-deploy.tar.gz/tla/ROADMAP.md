# Tatbiqul Lisan Academy — Production yo'l xaritasi

Prototipdan haqiqiy, serverda ishlaydigan, kengaytiriladigan platformaga
o'tish rejasi.

---

## 0. Avval — halol baholash

Bu hujjatni o'qishdan oldin bir necha haqiqatni tan olish kerak. Bu sizni
to'xtatish uchun emas — noto'g'ri kutish bilan boshlangan loyihalar
yarmida to'xtaydi.

**Hajm.** Siz sanab o'tgan narsalar (server, CMS, video, to'lov, AI,
ijtimoiy tarmoq, huquqiy) — bu bitta vazifa emas, balki **7–8 ta alohida
kichik loyiha**. Real muddat:

| Jamoa | MVP (to'lov + kurslar + testlar) | To'liq ro'yxat |
|---|---|---|
| 1 dasturchi (to'liq kunlik) | 3–4 oy | 8–12 oy |
| 2–3 kishilik jamoa | 6–10 hafta | 4–6 oy |
| Yakka, ish/o'qishdan ortgan vaqtda | 8–10 oy | 1.5–2 yil |

**Eng katta xato — hammasini birdan qurish.** To'g'ri yo'l: eng kichik
ishlaydigan mahsulotni chiqarib, **haqiqiy foydalanuvchi bilan sinash**,
keyin kengaytirish. Video darsliklar va AI — 3-bosqich, birinchi emas.

**Prototipni tashlab yubormang.** U shunchaki demo emas — u sizning
**texnik topshirig'ingiz**: dizayn tizimi, kontent tuzilmasi, baholash
logikasi, sahifa oqimlari allaqachon hal qilingan va sinovdan o'tgan.
Yangi loyihada bularni qaytadan o'ylab topish — eng ko'p vaqt yeydigan
qism, va u sizda tayyor.

---

## 1. Umumiy strategiya

```
Prototip (bor)  →  1-bosqich: server + baza + auth
                →  2-bosqich: admin CMS + kontent ko'chirish
                →  3-bosqich: to'lov + huquqiy + ishga tushirish
                →  4-bosqich: media (audio/video) + ijtimoiy
                →  5-bosqich: AI + analitika + optimizatsiya
```

Har bir bosqich oxirida **ishlaydigan mahsulot** bo'lishi kerak. "Hammasi
tayyor bo'lgach chiqaramiz" — eng xavfli reja.

---

## 2. Texnologiya tanlovi

### Tavsiya etilgan stack

| Qatlam | Tanlov | Nega |
|---|---|---|
| Framework | **Next.js 15 (App Router) + TypeScript** | SSR/SEO, API marshrutlari bir joyda, katta ekotizim |
| Baza | **PostgreSQL** | Relyatsion ma'lumot (kurs→modul→dars→savol), JSON qo'llab-quvvatlash, ishonchli |
| ORM | **Prisma** | Tipli sxema, migratsiyalar, seed |
| Auth | **Auth.js (NextAuth v5)** | Bepul, Google/Telegram OAuth, o'z bazangizda |
| Fayl saqlash | **Cloudflare R2** yoki AWS S3 | Audio, PDF, rasm. R2 da chiqish trafigi bepul |
| Video | **Cloudflare Stream** yoki **Mux** | ⚠️ MP4 ni o'zingiz serverda bermang — pastda tushuntirilgan |
| Kesh/navbat | **Redis** (Upstash yoki o'z serveringiz) | Sessiya, rate limit, fon vazifalari |
| Email | **Resend** yoki Postmark | Tasdiqlash, parol tiklash, chek |
| Xatolarni kuzatish | **Sentry** | Production da xato ko'rmasangiz — yo'q demak emas |
| Analitika | **PostHog** yoki Plausible | Cookie-siz variantlari bor |
| Hosting | **Vercel** (tez) yoki **VPS + Docker** (arzon, nazorat) | 12-bo'limga qarang — huquqiy cheklov bo'lishi mumkin |

### TypeScript — muzokara qilinmaydigan shart

Prototip JS da yozilgan va 11 700 qatorda men qo'lda topgan xatolar
(qo'shtirnoq, grid, breakpoint) TypeScript da **yozish paytidayoq**
ushlanardi. 120 dars, 88 savol, 52 test — bu hajmda tiplarsiz ishlash
xatolarni production ga chiqaradi.

### Nimadan qochish kerak

| Qochish | Nega |
|---|---|
| Video fayllarni o'z serveringizda MP4 sifatida berish | 1 soatlik dars ≈ 500MB. 100 talaba ko'rsa — 50GB trafik. Server yiqiladi, hisob katta chiqadi. Stream xizmatlari adaptiv sifat + CDN beradi. |
| Firebase/Supabase ga to'liq bog'lanish | Tez boshlanadi, lekin murakkab so'rovlar (savol tanlash, item analysis) va ko'chirish og'ir bo'ladi |
| Microservices | Sizning hajmingizda — ortiqcha murakkablik. Bitta yaxshi monolit yetarli |
| "O'z CMS imni noldan yozaman" (dastlab) | Avval Next.js admin sahifalari yeterli. Keyin kerak bo'lsa Payload/Strapi |

---

## 3. Repozitoriya tuzilmasi

```
tatbiqul-lisan/
├── .github/
│   ├── workflows/
│   │   ├── ci.yml                 # lint + typecheck + test + build
│   │   └── deploy.yml
│   ├── ISSUE_TEMPLATE/
│   └── pull_request_template.md
├── prisma/
│   ├── schema.prisma
│   ├── migrations/
│   └── seed/
│       ├── index.ts
│       ├── courses.ts             # prototipdan ko'chiriladi
│       └── questions.ts
├── src/
│   ├── app/
│   │   ├── (marketing)/           # bosh sahifa, narxlar, blog, about
│   │   ├── (learn)/               # kurslar, darslar
│   │   ├── (exam)/                # testlar, natijalar
│   │   ├── (account)/             # kabinet, profil, sertifikatlar
│   │   ├── admin/                 # CMS
│   │   └── api/
│   │       ├── auth/[...nextauth]/
│   │       ├── attempts/
│   │       ├── payments/
│   │       │   └── webhook/       # click, payme, uzum
│   │       ├── ai/
│   │       └── media/
│   ├── components/
│   │   ├── ui/                    # tugma, karta, modal (prototipdan)
│   │   ├── charts/                # shamsa rozetkasi (tayyor)
│   │   └── exam/                  # test interfeysi
│   ├── lib/
│   │   ├── db.ts
│   │   ├── auth.ts
│   │   ├── engine/                # baholash — prototipdan deyarli o'zgarishsiz
│   │   ├── ai/
│   │   │   ├── client.ts
│   │   │   ├── prompts/           # versiyalangan promptlar
│   │   │   └── evals/
│   │   ├── payments/
│   │   │   ├── click.ts
│   │   │   ├── payme.ts
│   │   │   └── uzum.ts
│   │   └── media/
│   ├── styles/                    # prototip CSS — o'zgarishsiz ishlaydi
│   └── i18n/
│       ├── uz.json                # prototipdan ko'chiriladi
│       ├── en.json
│       └── ar.json
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/                       # Playwright
├── docs/
│   ├── ARCHITECTURE.md
│   ├── CONTRIBUTING.md
│   └── DEPLOYMENT.md
├── .env.example
├── docker-compose.yml             # lokal postgres + redis
└── README.md
```

**Muhim tamoyil:** `lib/` ichidagi biznes-logika (baholash, daraja
hisoblash) **React ga bog'liq bo'lmasin**. Shunda uni test qilish oson va
kelajakda mobil ilovada qayta ishlatish mumkin.

---

## 4. Ma'lumotlar bazasi — eng muhim o'zgarish

Prototipda kontent **kod ichida** (`03-data-courses.js`). Production da u
**bazada** bo'lishi shart — aks holda har bir yangi savol uchun dasturchi
kerak bo'ladi.

### Asosiy sxema

```prisma
// ---------- Foydalanuvchi ----------
model User {
  id            String    @id @default(cuid())
  name          String
  email         String    @unique
  emailVerified DateTime?
  passwordHash  String?                       // argon2id
  role          Role      @default(STUDENT)
  locale        String    @default("uz")
  createdAt     DateTime  @default(now())

  profile       Profile?
  accounts      Account[]                     // OAuth (Google, Telegram)
  sessions      Session[]
  attempts      Attempt[]
  enrollments   Enrollment[]
  payments      Payment[]
  certificates  Certificate[]
  aiUsage       AiUsage[]

  @@index([email])
}

enum Role { STUDENT TEACHER EDITOR ADMIN }

model Profile {
  userId       String    @id
  user         User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  level        String?
  targetLevel  String    @default("b2")
  examDate     DateTime?
  dailyMinutes Int       @default(30)
  xp           Int       @default(0)
  streak       Int       @default(0)
  bestStreak   Int       @default(0)
  lastActiveAt DateTime?
  skills       Json      @default("{}")
  publicRank   Boolean   @default(false)
  consentMarketing Boolean @default(false)
  consentAnalytics Boolean @default(false)
}

// ---------- Kontent ----------
model Course {
  id          String   @id @default(cuid())
  slug        String   @unique
  level       String                          // a1..c2
  status      Status   @default(DRAFT)
  order       Int
  translations CourseTranslation[]
  modules     Module[]
  enrollments Enrollment[]
}

model CourseTranslation {
  id        String @id @default(cuid())
  courseId  String
  course    Course @relation(fields: [courseId], references: [id], onDelete: Cascade)
  locale    String                            // uz | en | ar
  title     String
  subtitle  String?
  description String
  forWhom   String?
  outcomes  Json

  @@unique([courseId, locale])
}

enum Status { DRAFT REVIEW PUBLISHED ARCHIVED }

model Module {
  id       String   @id @default(cuid())
  courseId String
  course   Course   @relation(fields: [courseId], references: [id], onDelete: Cascade)
  order    Int
  titleUz  String
  titleAr  String
  lessons  Lesson[]
}

model Lesson {
  id        String   @id @default(cuid())
  moduleId  String
  module    Module   @relation(fields: [moduleId], references: [id], onDelete: Cascade)
  slug      String   @unique
  order     Int
  skill     String
  minutes   Int      @default(20)
  isFree    Boolean  @default(false)
  status    Status   @default(DRAFT)

  blocks    LessonBlock[]                     // moslashuvchan kontent
  progress  LessonProgress[]
}

// Dars ichidagi bloklar — matn, video, audio, savol, grammatika izohi.
// Bu tuzilma tufayli yangi kontent turi qo'shish uchun sxema o'zgarmaydi.
model LessonBlock {
  id       String  @id @default(cuid())
  lessonId String
  lesson   Lesson  @relation(fields: [lessonId], references: [id], onDelete: Cascade)
  order    Int
  type     BlockType
  content  Json                                // turga qarab tuzilma
  mediaId  String?
  media    Media?  @relation(fields: [mediaId], references: [id])
}

enum BlockType { TEXT ARABIC_TEXT VIDEO AUDIO GRAMMAR VOCAB QUIZ FILE EMBED }

// ---------- Media ----------
model Media {
  id          String   @id @default(cuid())
  kind        MediaKind
  storageKey  String                           // R2/S3 kaliti
  providerId  String?                          // Mux/Stream asset id
  playbackId  String?
  status      MediaStatus @default(UPLOADING)
  durationSec Int?
  sizeBytes   BigInt?
  mimeType    String?
  transcript  String?                          // qidiruv + subtitr uchun
  uploadedBy  String?
  createdAt   DateTime @default(now())
  blocks      LessonBlock[]
}

enum MediaKind   { VIDEO AUDIO IMAGE PDF }
enum MediaStatus { UPLOADING PROCESSING READY FAILED }

// ---------- Savollar ----------
model Question {
  id         String   @id @default(cuid())
  level      String
  skill      String
  topic      String?
  difficulty String   @default("medium")
  type       String   @default("mcq")
  status     Status   @default(DRAFT)

  promptUz   String
  promptAr   String?
  options    Json
  answer     Int                               // ⚠️ hech qachon mijozga yuborilmaydi
  explanation String
  passageId  String?
  passage    Passage? @relation(fields: [passageId], references: [id])
  mediaId    String?

  source     QuestionSource @default(MANUAL)   // MANUAL | AI_DRAFT | IMPORTED
  reviewedBy String?
  reviewedAt DateTime?

  stats      QuestionStat?
  answers    AttemptAnswer[]

  @@index([level, skill, status])
}

enum QuestionSource { MANUAL AI_DRAFT IMPORTED }

// Item analysis — savol sifatini o'lchash
model QuestionStat {
  questionId       String   @id
  question         Question @relation(fields: [questionId], references: [id], onDelete: Cascade)
  timesShown       Int      @default(0)
  timesCorrect     Int      @default(0)
  pValue           Float?                      // qiyinlik
  discrimination   Float?                      // kuchli/kuchsiz talabani ajratadimi
  avgSeconds       Float?
  flaggedByUsers   Int      @default(0)
  updatedAt        DateTime @updatedAt
}

model Passage {
  id        String @id @default(cuid())
  level     String
  titleAr   String
  bodyAr    String
  translationUz String
  questions Question[]
}

// ---------- Imtihon ----------
model TestDefinition {
  id          String @id @default(cuid())
  slug        String @unique
  track       String                           // multilevel | tanal | darajaviy
  kind        String                           // practice | mock | diagnostic
  levels      Json
  skills      Json
  count       Int
  minutes     Int
  isFree      Boolean @default(false)
  status      Status  @default(DRAFT)
  attempts    Attempt[]
}

// Serverda boshqariladigan imtihon sessiyasi — vaqtni mijoz emas, server sanaydi
model Attempt {
  id         String   @id @default(cuid())
  userId     String
  user       User     @relation(fields: [userId], references: [id])
  testId     String
  test       TestDefinition @relation(fields: [testId], references: [id])

  startedAt  DateTime @default(now())
  expiresAt  DateTime                          // server hisoblaydi
  submittedAt DateTime?
  status     AttemptStatus @default(IN_PROGRESS)

  score       Int?
  correct     Int?
  total       Int
  skillScores Json?
  level       String?
  tabSwitches Int      @default(0)

  answers    AttemptAnswer[]

  @@index([userId, submittedAt])
}

enum AttemptStatus { IN_PROGRESS SUBMITTED EXPIRED ABANDONED }

model AttemptAnswer {
  id         String   @id @default(cuid())
  attemptId  String
  attempt    Attempt  @relation(fields: [attemptId], references: [id], onDelete: Cascade)
  questionId String
  question   Question @relation(fields: [questionId], references: [id])
  given      Int?
  isCorrect  Boolean?
  seconds    Int?
  flagged    Boolean  @default(false)

  @@unique([attemptId, questionId])
}

// ---------- Yozma/og'zaki ishlar ----------
model Submission {
  id         String   @id @default(cuid())
  userId     String
  taskId     String
  kind       String                            // writing | speaking
  textBody   String?
  mediaId    String?
  status     SubmissionStatus @default(PENDING)

  aiFeedback Json?                             // AI — maslahat, baho emas
  teacherId  String?
  teacherScore Int?
  teacherNote String?
  reviewedAt DateTime?
  createdAt  DateTime @default(now())
}

enum SubmissionStatus { PENDING AI_REVIEWED TEACHER_QUEUE COMPLETED }

// ---------- Tijorat ----------
model Plan {
  id        String @id
  order     Int
  priceUzs  Int
  isActive  Boolean @default(true)
  features  Json
  subscriptions Subscription[]
}

model Subscription {
  id        String   @id @default(cuid())
  userId    String
  planId    String
  plan      Plan     @relation(fields: [planId], references: [id])
  status    SubStatus @default(ACTIVE)
  startsAt  DateTime @default(now())
  endsAt    DateTime
  autoRenew Boolean  @default(false)
}

enum SubStatus { ACTIVE EXPIRED CANCELLED REFUNDED }

model Payment {
  id            String   @id @default(cuid())
  userId        String
  user          User     @relation(fields: [userId], references: [id])
  planId        String
  amountUzs     Int
  provider      String                         // click | payme | uzum
  providerTxnId String?
  idempotencyKey String  @unique               // ⚠️ ikki marta yozilmaslik uchun
  status        PayStatus @default(PENDING)
  rawPayload    Json?
  createdAt     DateTime @default(now())

  @@index([userId, createdAt])
  @@index([provider, providerTxnId])
}

enum PayStatus { PENDING PAID FAILED REFUNDED }

// ---------- Boshqa ----------
model Certificate {
  id        String   @id                       // TLA-2026-0001
  userId    String
  user      User     @relation(fields: [userId], references: [id])
  kind      String
  titleUz   String
  level     String?
  score     Int?
  issuedAt  DateTime @default(now())
  revokedAt DateTime?
}

model SavedWord {
  id        String   @id @default(cuid())
  userId    String
  word      String
  box       Int      @default(0)
  dueAt     DateTime
  @@unique([userId, word])
}

model AiUsage {
  id         String   @id @default(cuid())
  userId     String
  user       User     @relation(fields: [userId], references: [id])
  feature    String
  model      String
  inputTokens  Int
  outputTokens Int
  costUsd    Decimal  @db.Decimal(10, 6)
  createdAt  DateTime @default(now())
  @@index([userId, createdAt])
}

model AuditLog {
  id        String   @id @default(cuid())
  actorId   String?
  action    String
  entity    String
  entityId  String?
  before    Json?
  after     Json?
  ip        String?
  createdAt DateTime @default(now())
}
```

### Nega bu sxema shunday

- **`LessonBlock`** — dars ichidagi kontent qattiq tuzilma emas. Ertaga
  «interaktiv mashq» yoki «PDF» qo'shmoqchi bo'lsangiz, sxema o'zgarmaydi.
- **`*Translation`** jadvallar — ko'p tillilik bazada, koddagi obyektlarda
  emas. Arabcha kurs tavsifini muharrir kirita oladi.
- **`Question.answer`** — API javobida **hech qachon** yuborilmaydi.
  Bu prototipning eng jiddiy cheklovi edi.
- **`Attempt.expiresAt`** — vaqtni server hisoblaydi. Mijoz taymerni
  to'xtatsa ham imtihon tugaydi.
- **`idempotencyKey`** — to'lov webhook ikki marta kelsa (bu **doim**
  bo'ladi), pul ikki marta yozilmaydi.
- **`QuestionStat`** — savol sifatini o'lchash. `discrimination` past
  bo'lsa, savol yomon yozilgan degani.
- **`AuditLog`** — kim nima o'zgartirganini bilish. Admin panelga bir
  necha kishi kirsa, bu majburiy.

---

## 5. Kontent boshqaruvi (CMS)

Sizning asosiy talabingiz — «istalgancha o'quv manbalar, savollar,
audiolar, videodarsliklar kirita olishim». Buning uchun kerak:

### 5.1 Admin panel bo'limlari

| Bo'lim | Imkoniyat |
|---|---|
| Kurslar | CRUD, tartib o'zgartirish (drag-drop), nashr holati |
| Darslar | Blok muharriri: matn / arabcha matn / video / audio / savol |
| Savollar | CRUD, filtr, ommaviy import, sifat statistikasi |
| Media | Yuklash, holat kuzatuvi, transkript |
| Testlar | To'plam yaratish, savol tanlash qoidalari |
| Foydalanuvchilar | Rol, obuna, bloklash |
| To'lovlar | Tranzaksiyalar, qaytarish, hisobot |
| Yozma ishlar | Tekshirish navbati |
| Sozlamalar | Kontaktlar, narxlar, ijtimoiy havolalar |

### 5.2 Savollarni ommaviy kiritish

Bitta-bitta kiritish 1000 ta savol uchun ishlamaydi. Kerak:

1. **CSV/XLSX import** — namuna shablon yuklab olinadi, to'ldiriladi,
   yuklanadi. Import oldidan **validatsiya hisoboti** ko'rsatiladi
   (nechta to'g'ri, nechta xato, qayerda).
2. **AI qoralama** (11-bo'limga qarang) — model savol qoralamalarini
   yaratadi, muharrir tasdiqlaydi. Tasdiqlanmagan savol **hech qachon**
   testga tushmaydi.
3. **Nashr oqimi**: `DRAFT → REVIEW → PUBLISHED`. Bitta odam yozib,
   boshqasi tasdiqlaydi.

### 5.3 Matn muharriri

Arab tili uchun oddiy WYSIWYG yetarli emas. Kerak:

- RTL/LTR aralash matn qo'llab-quvvatlashi
- Harakat (tashkil) belgilarini yo'qotmaydigan saqlash
- Arabcha matn bloki alohida tur sifatida (shrift, yo'nalish, o'lcham)

**Tavsiya:** Tiptap (ProseMirror) — RTL bilan yaxshi ishlaydi va
JSON saqlaydi (HTML emas — bu xavfsizroq).

---

## 6. Media: audio va video

Bu qismda eng ko'p pul va vaqt yo'qotiladi. Diqqat bilan.

### 6.1 Video — o'zingiz bermang

| Yondashuv | Natija |
|---|---|
| ❌ MP4 ni serverdan berish | 100 talaba × 500MB = 50GB/oy trafik, sifat sozlanmaydi, telefon internetida uziladi |
| ✅ Cloudflare Stream / Mux | Avtomatik adaptiv sifat (240p–1080p), CDN, subtitr, analitika |

**Oqim:**

```
Admin fayl yuklaydi
   → to'g'ridan-to'g'ri Stream/Mux ga (signed upload URL, sizning serveringiz orqali emas)
   → provayder webhook yuboradi: "tayyor"
   → Media.status = READY, playbackId saqlanadi
   → talaba signed playback token bilan ko'radi (muddatli)
```

**Muhim:** yuklash fayli sizning serveringizdan **o'tmasin** — signed
URL bering. Aks holda 2GB lik video Next.js serverini bo'g'adi.

### 6.2 Audio

Tinglash mashqlari uchun:

- Format: **MP3 128kbps** (mono yetarli, hajm 2 barobar kichik)
- Saqlash: R2/S3, CDN orqali
- Kirish: premium kontent uchun **signed URL** (muddati 1 soat)
- Har bir audio uchun **transkript majburiy** — qidiruv, subtitr va
  a11y uchun

**Professional yozib olish tavsiya etiladi.** Nutq sintezi (prototipdagi
kabi) — vaqtinchalik yechim; imtihon tayyorgarligida talaffuz aniqligi
muhim. Ona tili so'zlovchisi bilan 6 ta matn yozib olish ≈ bir kunlik ish.

### 6.3 Kontentni himoyalash

To'liq himoya **mumkin emas** (ekranni yozib olish har doim mumkin).
Amaliy chora:

- Signed, muddatli URL
- Watermark (foydalanuvchi emaili video ustida)
- Bir hisobdan bir vaqtda 2 tadan ortiq sessiya bo'lmasin
- Anomaliya kuzatuvi (bir kunda 50 ta dars ochilishi — shubhali)

DRM (Widevine) — juda qimmat va murakkab; sizning bosqichingizda kerak emas.

---

## 7. Autentifikatsiya va imtihon yaxlitligi

### 7.1 Auth

- **Auth.js (NextAuth v5)** + Prisma adapter
- Parol: **argon2id** (bcrypt ham mumkin, argon2 yaxshiroq)
- Provayderlar: email+parol, Google, **Telegram Login Widget**
- Email tasdiqlash majburiy (soxta hisoblarni kamaytiradi)
- 2FA — admin va o'qituvchi rollari uchun majburiy qiling

### 7.2 Imtihon yaxlitligi — kritik

Prototipning eng katta cheklovi: **javoblar mijozda**. Production da:

```
POST /api/attempts/start
   ← server savollarni tanlaydi, DB ga yozadi, expiresAt belgilaydi
   ← mijozga savollar javobsiz yuboriladi

POST /api/attempts/:id/answer     (har bir javob)
   ← server yozadi (mijoz refresh qilsa ham yo'qolmaydi)

POST /api/attempts/:id/submit
   ← server baholaydi, natijani qaytaradi
   ← expiresAt o'tgan bo'lsa — avtomatik EXPIRED
```

Qo'shimcha:

- Rate limiting (bitta foydalanuvchi 1 daqiqada 10 ta test boshlolmasin)
- Bir vaqtda faqat bitta faol `IN_PROGRESS` attempt
- Tab-almashishlar soni serverda yoziladi
- Mock imtihonda savol tartibi va variantlar har bir foydalanuvchi uchun
  boshqacha (urug' — `attemptId`)

### 7.3 Umumiy xavfsizlik ro'yxati

- [ ] Barcha API marshrutlarida rol tekshiruvi (middleware emas, **har bir
      handler ichida** — middleware chetlab o'tilishi mumkin)
- [ ] Zod bilan input validatsiyasi
- [ ] Rate limiting (Upstash Ratelimit yoki o'z Redis)
- [ ] CSRF himoyasi (Auth.js beradi)
- [ ] Content Security Policy sarlavhalari
- [ ] Webhook imzolarini tekshirish
- [ ] Sirlar faqat `.env` da, hech qachon repoda (`.env.example` — namuna)
- [ ] SQL — faqat Prisma orqali (raw so'rov bo'lsa, parametrlashtirilgan)
- [ ] Yuklangan fayl turini **mazmuni bo'yicha** tekshirish (kengaytma emas)
- [ ] `npm audit` CI da

---

## 8. To'lov tizimlari

### 8.1 O'zbekiston provayderlari

| Provayder | Eslatma |
|---|---|
| **Click** | Merchant API, Prepare/Complete sxemasi |
| **Payme** | Merchant API (JSON-RPC), sandbox bor |
| **Uzum Bank** | Merchant API |
| **Stripe/Paddle** | Xalqaro talabalar uchun (Paddle — soliqni o'zi hal qiladi) |

Har biri uchun **shartnoma va merchant hisob** kerak — bu texnik emas,
tashkiliy jarayon va 2–4 hafta olishi mumkin. **Erta boshlang.**

### 8.2 To'g'ri arxitektura

```
1. Foydalanuvchi tarifni tanlaydi
2. Server Payment yozuvini yaratadi (status=PENDING, idempotencyKey)
3. Provayder sahifasiga yo'naltirish (karta ma'lumoti sizga TEGMAYDI)
4. Provayder webhook yuboradi → imzo tekshiriladi
5. status=PAID, Subscription yaratiladi
6. Foydalanuvchiga email + kabinetda ko'rinadi
```

**Muhim qoidalar:**

- Kirishni **hech qachon** frontend javobiga asoslanmang — faqat webhook
- Webhook **ikki marta keladi** — `idempotencyKey` bilan himoyalang
- Har bir webhook `rawPayload` bilan saqlansin (nizoda kerak bo'ladi)
- Kunlik **sverka** (reconciliation): provayder hisoboti bilan bazani
  solishtiruvchi skript
- Sandbox da to'liq sinang: muvaffaqiyat, bekor qilish, qaytarish, timeout

### 8.3 Obuna mantiqi

- Muddat tugashi: `endsAt` bo'yicha kunlik cron
- Tugashdan 3 kun oldin eslatma
- Tugagach — **kontent yopiladi, ma'lumot o'chmaydi**
- Qaytarish siyosati kodda ham aks etsin (7 kun + 20% qoidasi)

---

## 9. Kesh va cookie

### 9.1 Kesh qatlamlari

| Qatlam | Nima uchun | TTL |
|---|---|---|
| CDN (Cloudflare) | Statik fayl, rasm, audio | 1 yil (hash bilan) |
| Next.js ISR | Blog, marketing sahifalar | 1 soat, on-demand revalidate |
| Redis | Sessiya, rate limit, savol to'plami | 5–60 daqiqa |
| React Query / SWR | Mijoz tomonida | 30 soniya |
| Prisma | So'rovlarni `select` bilan cheklash | — |

**Keshlamang:** foydalanuvchi progressi, imtihon holati, to'lov holati.

### 9.2 Cookie strategiyasi

| Cookie | Turi | Sozlama |
|---|---|---|
| Sessiya | Zaruriy | `httpOnly`, `Secure`, `SameSite=Lax` |
| Til tanlovi | Zaruriy | 1 yil |
| Tema | Zaruriy | 1 yil |
| Analitika | **Rozilik talab qiladi** | Faqat "qabul qilaman" dan keyin |
| Marketing | **Rozilik talab qiladi** | Faqat rozilik bilan |

**Cookie banner** kerak — lekin to'g'ri qilingani: "Hammasini qabul
qilish" va "Faqat zaruriy" tugmalari **teng ko'rinishda** bo'lsin.
Rad etishni qiyinlashtirish — ko'p yurisdiksiyalarda qonunbuzarlik.

Prototipda allaqachon `consentAnalytics` maydoni bor — uni bannerga
bog'lash kifoya.

---

## 10. Ijtimoiy tarmoqlar va o'sish

### 10.1 Kirish (OAuth)

- Google — eng ko'p ishlatiladi
- **Telegram Login Widget** — O'zbekistonda juda kuchli kanal
- Apple — iOS ilova qilsangiz majburiy bo'ladi

### 10.2 Telegram bot

Sizning auditoriyangiz uchun bu **eng samarali kanal**:

- Kunlik eslatma («seriyangiz uzilmasin»)
- Test natijasi
- Yangi dars xabari
- Bot ichida mini-mashq (5 ta savol)

Amalga oshirish: `grammy` yoki `telegraf` kutubxonasi + webhook.
⚠️ Bot tokeni **faqat serverda**.

### 10.3 Ulashish (viral)

- **Open Graph rasmlari** — natija ulashilganda chiroyli karta
  (Next.js `ImageResponse` bilan dinamik generatsiya)
- «Darajam B2 chiqdi» kartasi — shamsa rozetkasi bilan
- Sertifikat ulashish havolasi
- **Referral tizimi**: taklif qilgan ham, kelgan ham 1 hafta premium

### 10.4 SEO

- Har bir dars/blog uchun alohida meta va JSON-LD (`Course`, `Article`)
- `sitemap.xml` avtomatik generatsiya
- Ko'p tillilik uchun `hreflang`
- Blog — organik trafikning asosiy manbai. Haftada 1 maqola.

---

## 11. Sun'iy intellekt integratsiyasi

Bu bo'limga alohida e'tibor bering — bu yerda eng ko'p **noto'g'ri**
qilinadi.

### 11.1 Asosiy tamoyil

> AI **maslahat beradi**, lekin **rasmiy baho qo'ymaydi** va
> **tekshirilmagan kontent nashr qilmaydi**.

Sabab: model arab tilidagi inshoga ishonchli CEFR bahosi bera olmaydi,
lekin foydalanuvchi bu raqamni rasmiy deb qabul qiladi. Bu — obro'ga
zarar va noto'g'ri kutish.

### 11.2 Qayerda ishlatish (foydali va xavfsiz)

| Funksiya | Tavsif | Model |
|---|---|---|
| **Yozma ishga fikr-mulohaza** | Xato turlari, tuzilma, yaxshilash takliflari — **ball emas** | Sonnet |
| **Grammatik xatolarni belgilash** | Matn ichida aniq joyni ko'rsatish + izoh | Sonnet |
| **Savol qoralamasi** | Muharrir tasdiqlashi uchun; hech qachon avtomatik nashr emas | Sonnet / Opus |
| **Distraktor generatsiyasi** | To'g'ri javobga mos noto'g'ri variantlar | Sonnet |
| **Shaxsiy o'quv rejasi** | Natijalarga qarab haftalik reja matni | Haiku / Sonnet |
| **Semantik qidiruv** | «كان haqida dars» → to'g'ri darslar | Embedding + pgvector |
| **Tutor chat** | Dars kontekstida savol-javob | Sonnet |
| **Transkript va subtitr** | Audio → matn (keyin odam tekshiradi) | Whisper yoki shunga o'xshash |
| **Tarjima yordamchisi** | Kontentni uz→en→ar ga qoralama tarjima | Haiku |

### 11.3 Qayerda ishlatmaslik

- ❌ Rasmiy CEFR bahosi qo'yish
- ❌ Sertifikat berish qarori
- ❌ Tekshirilmagan savolni testga qo'shish
- ❌ Talaffuzga «to'g'ri/noto'g'ri» hukmi (fonetik tahlil ishonchsiz)
- ❌ Foydalanuvchi ma'lumotini promptga tekshirmasdan qo'yish

### 11.4 Texnik arxitektura

```
Mijoz  →  /api/ai/[feature]  →  rate limit tekshiruvi
                              →  kirish validatsiyasi (Zod)
                              →  prompt yig'ish (versiyalangan)
                              →  Claude API (streaming)
                              →  javobni saqlash + AiUsage yozish
                              ←  streaming javob
```

**Qoidalar:**

1. **API kaliti faqat serverda.** Hech qachon `NEXT_PUBLIC_*` da emas.
2. **Streaming** — 10 soniya kutishdan ko'ra oqim yaxshi.
3. **Promptlar versiyalangan fayllarda** (`lib/ai/prompts/writing-v3.ts`),
   kod ichida sochilgan satrlarda emas.
4. **Har bir foydalanuvchi uchun limit** — kunlik/oylik. Aks holda bitta
   foydalanuvchi butun byudjetni yeydi.
5. **`AiUsage` jadvali** — har bir chaqiruv narxini yozing. Oy oxirida
   «qayerdan bu hisob?» degan savol bo'lmaydi.

### 11.5 Xarajatni nazorat qilish

Claude API narxlari (2026-avgust holatiga, 1M token uchun):

| Model | Kirish | Chiqish | Qachon |
|---|---|---|---|
| Haiku 4.5 | $1 | $5 | Oddiy tasniflash, tarjima qoralamasi |
| Sonnet 5 | $3 | $15 | Asosiy ish yuki (fikr-mulohaza, tutor) |
| Opus 5 | $5 | $25 | Murakkab kontent generatsiyasi |
| Fable 5 | $10 | $50 | Eng yuqori imkoniyat talab qilinganda |

*Narxlar o'zgarishi mumkin — https://claude.com/pricing dan tasdiqlang.*

**Uch samarali chora:**

1. **Prompt caching** — barqaror qismni (rubrika, CEFR tavsiflari,
   ko'rsatmalar) keshlang. Kesh o'qish standart kirish narxining ~10% i.
   Sizning holatda tejamkorlik katta, chunki rubrika har safar bir xil.
2. **Batch API** — real vaqt kerak bo'lmagan ishlar uchun (savol
   qoralamalari, ommaviy tahlil) 50% chegirma.
3. **Model marshrutlash** — hamma ishga eng kuchli modelni ishlatmang.
   Tarjima qoralamasi Haiku da yetarli.

**Taxminiy hisob:** 1000 faol talaba, oyiga 4 tadan yozma ish, har biri
~1500 kirish + ~800 chiqish token, Sonnet 5:
`4000 × (1500 × $3 + 800 × $15) / 1M ≈ $66/oy`. Prompt caching bilan
~$40. Bu boshqarilishi mumkin — lekin **limitsiz** qoldirsangiz, 10
barobar oshishi mumkin.

### 11.6 Sifatni o'lchash (eval)

Bu qism ko'pincha tashlab ketiladi va keyin muammo bo'ladi.

- **Oltin to'plam** yarating: 30–50 ta yozma ish + tajribali o'qituvchi
  bahosi va izohi
- Prompt o'zgartirganda shu to'plamda qayta ishga tushiring
- O'lchang: foydali xato topish darajasi, noto'g'ri da'volar soni
- **Regressiya** bo'lsa — prompt versiyasini qaytaring

Promptni «yaxshilash» ko'pincha boshqa joyda buzadi. Eval bo'lmasa,
buni bilmaysiz.

### 11.7 Foydalanuvchiga ochiqlik

- «Bu fikr-mulohaza sun'iy intellekt tomonidan tayyorlangan» — ochiq yozing
- «Rasmiy baho emas» — har bir AI natijasida
- Foydalanuvchi AI javobini **o'qituvchiga yuborish** imkoniga ega bo'lsin
- AI xato qilganini belgilash tugmasi (bu sizga eval ma'lumoti beradi)

---

## 12. Huquqiy va ma'lumot himoyasi

⚠️ **Men yurist emasman. Quyidagilar — tekshirish ro'yxati, huquqiy
maslahat emas.** Ishga tushirishdan oldin O'zbekiston qonunchiligi
bo'yicha yurist bilan maslahatlashing.

### 12.1 Tekshirilishi shart bo'lgan masalalar

| Masala | Nega muhim |
|---|---|
| **Shaxsiy ma'lumotlarni lokalizatsiya qilish** | O'zbekistonda fuqarolarning shaxsiy ma'lumotlari mamlakat hududidagi serverlarda saqlanishi talab qilinishi mumkin. Bu **hosting tanlovingizga to'g'ridan-to'g'ri ta'sir qiladi** — Vercel/AWS Yevropa mintaqasi mos kelmasligi mumkin. **Eng birinchi aniqlang.** |
| Ma'lumotlar operatori sifatida ro'yxatdan o'tish | Talab qilinishi mumkin |
| Ommaviy oferta | Onlayn to'lov uchun majburiy |
| Soliq va kassa cheki | To'lov provayderi bilan birga hal qilinadi |
| Voyaga yetmaganlar | 18 yoshgacha — ota-ona roziligi masalasi |
| Mualliflik huquqi | Barcha matn/audio o'zingizniki yoki litsenziyali bo'lsin |

### 12.2 Zarur hujjatlar

Prototipda **namunalari bor** (`#/legal/*`) — ularni yurist to'ldiradi:

- Maxfiylik siyosati
- Foydalanish shartlari
- Ommaviy oferta
- To'lovni qaytarish siyosati
- Cookie siyosati

### 12.3 Foydalanuvchi huquqlari (texnik tomoni)

Prototipda allaqachon bor, saqlab qoling:

- Ma'lumotni yuklab olish (JSON eksport)
- Hisobni o'chirish (kaskad o'chirish)
- Bildirishnomalardan voz kechish
- Analitikaga rozilikni qaytarib olish

---

## 13. GitHub va ish jarayoni

### 13.1 Repozitoriya sozlash

```bash
git init
git branch -M main
# .gitignore: node_modules, .env, .next, *.log
```

**Himoyalangan `main`:**
- To'g'ridan-to'g'ri push taqiqlangan
- PR va CI muvaffaqiyatli o'tishi shart
- Yakka ishlasangiz ham — bu sizni tasodifiy buzishdan saqlaydi

### 13.2 Branch strategiyasi

```
main          ← production (himoyalangan)
  └── develop ← integratsiya
        ├── feat/payment-click
        ├── feat/ai-writing-feedback
        └── fix/exam-timer-drift
```

Kichik jamoada `develop` siz ham mumkin: `main` + qisqa umrli feature
branchlar (trunk-based).

### 13.3 Commit uslubi

**Conventional Commits:**

```
feat(exam): add server-side timer validation
fix(payment): handle duplicate Click webhook
docs(readme): add deployment steps
refactor(engine): extract level estimation
test(e2e): cover guest result gate
```

Bu avtomatik CHANGELOG va semantik versiyalash imkonini beradi.

### 13.4 CI (`.github/workflows/ci.yml`)

```yaml
name: CI
on: [push, pull_request]
jobs:
  check:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
        env: { POSTGRES_PASSWORD: test }
        options: >-
          --health-cmd pg_isready --health-interval 10s
          --health-timeout 5s --health-retries 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npx prisma migrate deploy
      - run: npm run lint
      - run: npm run typecheck
      - run: npm run test
      - run: npx playwright install --with-deps chromium
      - run: npm run test:e2e
      - run: npm run build
```

### 13.5 Muhitlar

| Muhit | Baza | Maqsad |
|---|---|---|
| Lokal | Docker postgres | Ishlab chiqish |
| Preview | Alohida baza | Har bir PR uchun avtomatik |
| Staging | Nusxa (anonimlashtirilgan) | Yakuniy sinov |
| Production | Asosiy | Real foydalanuvchi |

⚠️ **Production bazasida hech qachon test qilmang.** Bu qoida buzilgan
kunni hamma eslab qoladi.

### 13.6 Zaxira nusxa

- Kunlik avtomatik baza zaxirasi (kamida 30 kun saqlanadi)
- **Tiklashni sinab ko'ring** — sinalmagan zaxira nusxa yo'q hisobida
- Media fayllar uchun alohida zaxira

---

## 14. Testlash

| Tur | Vosita | Nimani qamrab oladi |
|---|---|---|
| Unit | Vitest | Baholash, daraja hisoblash, SRS, QR |
| Integration | Vitest + test DB | API marshrutlari, to'lov webhook |
| E2E | Playwright | Ro'yxat → test → natija → to'lov |
| Visual | Playwright snapshot | Dizayn regressiyasi |
| A11y | axe-core | Har bir asosiy sahifa |
| Load | k6 | Imtihon boshlanish payti (eng yuqori yuk) |

**Minimal qamrov maqsadi:** biznes-logika (`lib/`) uchun 80%+,
UI uchun kamroq bo'lishi normal.

Prototipdagi sinov skriptlari (`tests/`) Playwright ga oson ko'chadi —
mantiq bir xil.

---

## 15. Monitoring

Production ga chiqqandan keyin **ko'rmasangiz — bilmaysiz**.

- **Sentry** — JS va server xatolari, source map bilan
- **Uptime monitoring** — BetterStack yoki UptimeRobot
- **Log** — tuzilgan (JSON) loglar, `pino`
- **Metrikalar** — javob vaqti, xato foizi, baza so'rov vaqti
- **Biznes dashboard** — ro'yxatdan o'tish, to'lov, faol foydalanuvchi
- **Ogohlantirish** — 5xx xatolar 1% dan oshsa, Telegram ga xabar

**Performance byudjeti:**
- LCP < 2.5s (3G da)
- Sahifa hajmi < 300KB (birinchi yuklash)
- API javobi p95 < 500ms

---

## 16. Bosqichma-bosqich reja

### 1-bosqich: Poydevor (3–4 hafta)

- [ ] Next.js + TypeScript + Prisma loyihasi
- [ ] Postgres (lokal Docker + production)
- [ ] Prisma sxema + birinchi migratsiya
- [ ] Auth.js (email + Google)
- [ ] Prototip CSS va komponentlarini ko'chirish
- [ ] i18n (uz/en/ar) ni ko'chirish
- [ ] GitHub repo + CI + preview deploy
- [ ] Sentry

**Natija:** foydalanuvchi ro'yxatdan o'tadi va bosh sahifani ko'radi.

### 2-bosqich: Kontent va imtihon (4–5 hafta)

- [ ] Kontentni koddan bazaga ko'chirish (seed)
- [ ] Admin CMS: kurslar, darslar, savollar
- [ ] CSV import + validatsiya
- [ ] Server tomonidagi imtihon sessiyasi
- [ ] Baholash logikasini serverga ko'chirish
- [ ] Natija sahifasi + tavsiyalar
- [ ] Progress va gamifikatsiya

**Natija:** talaba o'qiydi va test topshiradi, kontent admin orqali kiritiladi.

### 3-bosqich: Tijorat va ishga tushirish (3–4 hafta)

- [ ] Click/Payme integratsiyasi + webhook
- [ ] Obuna mantiqi + kontent yopish
- [ ] Huquqiy hujjatlar (yurist bilan)
- [ ] Cookie banner
- [ ] Email (tasdiqlash, chek, eslatma)
- [ ] Sertifikat + tekshirish
- [ ] **Beta ishga tushirish: 20–50 ta haqiqiy talaba**

**Natija:** pul ishlaydigan mahsulot. **Bu yerda to'xtab, fikr yig'ing.**

### 4-bosqich: Media va o'sish (4–6 hafta)

- [ ] Cloudflare Stream / Mux integratsiyasi
- [ ] Audio pipeline + professional yozib olish
- [ ] Telegram bot
- [ ] OAuth (Telegram, Apple)
- [ ] OG rasmlar + ulashish
- [ ] Referral
- [ ] SEO + blog jadvali

### 5-bosqich: AI va optimallashtirish (4–6 hafta)

- [ ] Yozma ishga AI fikr-mulohazasi (+ eval to'plami)
- [ ] Savol qoralamasi generatori (muharrir tasdiqlashi bilan)
- [ ] Semantik qidiruv (pgvector)
- [ ] Tutor chat
- [ ] Item analysis dashboard
- [ ] Performance optimizatsiyasi

---

## 17. Taxminiy oylik xarajat

| Xizmat | Boshlang'ich | 1000 faol talaba |
|---|---|---|
| Hosting | $0–20 | $40–100 |
| Postgres | $0–15 | $30–80 |
| Redis | $0–10 | $10–30 |
| Fayl saqlash (R2) | ~$5 | $15–40 |
| Video (Stream/Mux) | $5–20 | $50–200 |
| Email | $0–20 | $20–40 |
| Sentry | $0 | $26 |
| Domen | ~$1 | ~$1 |
| AI (limitli) | $0–20 | $40–120 |
| **Jami** | **~$30–100** | **~$250–650** |

Bunga qo'shimcha: to'lov provayderi komissiyasi (odatda 1–3%),
yurist (bir martalik), audio yozib olish (bir martalik).

---

## 18. Birinchi 10 kun — aniq qadamlar

Rejani o'qish oson, boshlash qiyin. Mana aniq boshlanish:

**1-kun**
- GitHub da `tatbiqul-lisan` repo yarating (private)
- `npx create-next-app@latest --typescript --app`
- Prototipni `legacy/` papkasiga qo'ying (ma'lumotnoma sifatida)

**2–3-kun**
- Docker compose bilan lokal Postgres
- Prisma o'rnating, 4-bo'limdagi sxemani kiriting
- `npx prisma migrate dev`

**4–5-kun**
- Prototipdagi `03-data-courses.js` va savollarni `prisma/seed/` ga
  ko'chiring (JSON dan TypeScript ga — mexanik ish)
- `npx prisma studio` bilan ma'lumot bazaga tushganini ko'ring

**6–7-kun**
- Auth.js o'rnating, ro'yxat/kirish ishlasin
- Prototip CSS ni `src/styles/` ga ko'chiring, bosh sahifani chizing

**8–9-kun**
- CI workflow qo'shing
- Vercel yoki VPS ga birinchi deploy

**10-kun**
- Huquqiy masalani aniqlang: **ma'lumot lokalizatsiyasi talabi bormi?**
  Bu javob hosting tanlovingizni belgilaydi — kech bilsangiz, ko'chirish
  qimmat bo'ladi

---

## 19. Yakuniy maslahatlar

1. **Kontentni erta boshlang.** Kod 3 oyda tayyor bo'ladi, lekin 1000 ta
   sifatli savol va 20 soatlik audio — bu bir necha oylik **kontent
   ishi**. Parallel olib boring.

2. **20 ta haqiqiy talaba 200 ta funksiyadan qimmatroq.** Beta guruhini
   erta yig'ing va ular bilan gaplashing.

3. **Yakka qurmang.** Hech bo'lmasa kontent bo'yicha arab tili
   mutaxassisi bilan ishlang — sizning ustunligingiz kod emas, **kontent
   sifati** bo'ladi.

4. **Prototipni o'chirmang.** U — sizning eng aniq texnik topshirig'ingiz.

5. **AI ni oxirida qo'shing.** U mahsulotni yaxshilaydi, lekin
   yaratmaydi. Avval o'quv jarayoni ishlasin.

Omad tilayman. Loyihaning poydevori yaxshi — endi asosiysi izchillik.
