#!/usr/bin/env python3
"""
Tatbiqul Lisan Academy — backend server
=========================================
Zero-dependency HTTP + auth API, built entirely on the Python standard
library (http.server, sqlite3, hashlib, secrets). No pip install, no
network access needed to set up — this matters because it must run on
any machine (including the user's Windows PC) with nothing but Python.

What it does:
  - Serves the built static site from ../public/ at "/"
  - Serves a JSON auth API under /api/*
  - Stores users + sessions in a local SQLite file (backend/data.db)
  - Seeds two demo accounts on first run (see DEMO_ACCOUNTS below)

Run:
    python3 server.py
    (Windows:  python server.py)

Then open:  http://localhost:8000

This is a deliberately small first backend increment — authentication
only. Course/lesson/test/progress data still lives in the browser
(see ARCHITECTURE.md "Backend yo'q — bu nimani anglatadi" section,
which this file starts to change). Expanding the schema to cover
progress, payments, etc. is future work — see ROADMAP.md.
"""
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote

# ---------------------------------------------------------------- config --
HERE = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.normpath(os.path.join(HERE, "..", "public"))
DB_PATH = os.environ.get("TLA_DB_PATH", os.path.join(HERE, "data.db"))
PORT = int(os.environ.get("PORT", "8000"))
HOST = os.environ.get("HOST", "0.0.0.0")
TOKEN_TTL_DAYS = int(os.environ.get("TLA_TOKEN_TTL_DAYS", "30"))
PBKDF2_ITERATIONS = 260_000  # OWASP-recommended floor for PBKDF2-SHA256 (2023+)

# Demo accounts for the current "backend v1 / auth only" milestone.
# Re-running the server never overwrites an existing account's password —
# seeding only fills in accounts that don't exist yet (see seed_demo_accounts).
DEMO_ACCOUNTS = [
    {"name": "Administrator", "email": "admin@gmail.com", "password": "12345678", "role": "admin"},
    {"name": "Foydalanuvchi", "email": "user@gmail.com", "password": "12345678", "role": "student"},
]

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


# ---------------------------------------------------------------- storage --
db_lock = threading.Lock()


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with db_lock:
        conn = get_conn()
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id            TEXT PRIMARY KEY,
                name          TEXT NOT NULL,
                email         TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                salt          TEXT NOT NULL,
                role          TEXT NOT NULL DEFAULT 'student',
                created_at    TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sessions (
                token      TEXT PRIMARY KEY,
                user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
            """
        )
        conn.commit()
        conn.close()


def seed_demo_accounts():
    with db_lock:
        conn = get_conn()
        for acc in DEMO_ACCOUNTS:
            row = conn.execute("SELECT id FROM users WHERE email = ?", (acc["email"],)).fetchone()
            if row is None:
                _create_user_locked(conn, acc["name"], acc["email"], acc["password"], acc["role"])
                print(f"[seed] yaratildi: {acc['email']} (rol: {acc['role']})")
            else:
                print(f"[seed] mavjud, o'tkazib yuborildi: {acc['email']}")
        conn.commit()
        conn.close()


# ---------------------------------------------------------- password hash --
def hash_password(password, salt=None):
    """PBKDF2-HMAC-SHA256. Stdlib-only, no external crypto dependency.
    For a larger production deployment, argon2id is preferable (see
    ROADMAP.md section 4) — this is a deliberate, documented tradeoff to
    keep the backend runnable with zero `pip install` steps."""
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), PBKDF2_ITERATIONS)
    return digest.hex(), salt


def verify_password(password, stored_hash, salt):
    candidate, _ = hash_password(password, salt)
    return hmac.compare_digest(candidate, stored_hash)


# --------------------------------------------------------------- user ops --
def _create_user_locked(conn, name, email, password, role):
    """Caller must hold db_lock."""
    password_hash, salt = hash_password(password)
    user_id = secrets.token_hex(12)
    conn.execute(
        "INSERT INTO users (id, name, email, password_hash, salt, role, created_at) VALUES (?,?,?,?,?,?,?)",
        (user_id, name, email.lower(), password_hash, salt, role, datetime.now(timezone.utc).isoformat()),
    )
    return user_id


def create_user(name, email, password, role="student"):
    with db_lock:
        conn = get_conn()
        try:
            existing = conn.execute("SELECT id FROM users WHERE email = ?", (email.lower(),)).fetchone()
            if existing:
                return None, "exists"
            user_id = _create_user_locked(conn, name, email, password, role)
            conn.commit()
            return get_user_by_id(conn, user_id), None
        finally:
            conn.close()


def get_user_by_email(conn, email):
    row = conn.execute("SELECT * FROM users WHERE email = ?", (email.lower(),)).fetchone()
    return dict(row) if row else None


def get_user_by_id(conn, user_id):
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return dict(row) if row else None


def public_user(row):
    """Never send password_hash/salt to the client."""
    return {"id": row["id"], "name": row["name"], "email": row["email"], "role": row["role"]}


# ------------------------------------------------------------ session ops --
def create_session(user_id):
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(days=TOKEN_TTL_DAYS)
    with db_lock:
        conn = get_conn()
        conn.execute(
            "INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?,?,?,?)",
            (token, user_id, now.isoformat(), expires.isoformat()),
        )
        conn.commit()
        conn.close()
    return token


def resolve_session(token):
    if not token:
        return None
    with db_lock:
        conn = get_conn()
        try:
            row = conn.execute("SELECT * FROM sessions WHERE token = ?", (token,)).fetchone()
            if not row:
                return None
            expires_at = datetime.fromisoformat(row["expires_at"])
            if expires_at < datetime.now(timezone.utc):
                conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
                conn.commit()
                return None
            user = get_user_by_id(conn, row["user_id"])
            return user
        finally:
            conn.close()


def delete_session(token):
    with db_lock:
        conn = get_conn()
        conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
        conn.commit()
        conn.close()


# -------------------------------------------------------- login rate limit
# Deliberately simple (in-memory, per-process) — enough to blunt casual
# brute-forcing of a small public demo without adding a dependency. Not a
# substitute for a real rate limiter (e.g. Redis-backed) at real scale.
_login_attempts = {}
_login_lock = threading.Lock()
MAX_ATTEMPTS = 10
WINDOW_SECONDS = 15 * 60


def rate_limited(key):
    now = time.time()
    with _login_lock:
        hits = [t for t in _login_attempts.get(key, []) if now - t < WINDOW_SECONDS]
        _login_attempts[key] = hits
        return len(hits) >= MAX_ATTEMPTS


def record_attempt(key):
    with _login_lock:
        _login_attempts.setdefault(key, []).append(time.time())


# -------------------------------------------------------------- validation
def validate_register(name, email, password):
    if not name or len(name.strip()) < 2:
        return "Ismni to'liq kiriting (kamida 2 harf)."
    if not email or not EMAIL_RE.match(email):
        return "Email manzili noto'g'ri."
    if not password or len(password) < 8:
        return "Parol kamida 8 belgidan iborat bo'lishi kerak."
    return None


# ===================================================================== #
#  HTTP layer
# ===================================================================== #
class Handler(BaseHTTPRequestHandler):
    server_version = "TLA/1.0"

    # ---- helpers ---------------------------------------------------
    def _cors(self):
        origin = self.headers.get("Origin", "*")
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Max-Age", "86400")

    def _json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status, code, message):
        self._json(status, {"error": code, "message": message})

    def _read_json(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None

    def _bearer_token(self):
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth[7:].strip()
        return None

    def _require_user(self):
        token = self._bearer_token()
        user = resolve_session(token)
        if not user:
            self._error(401, "unauthorized", "Sessiya topilmadi yoki muddati tugagan.")
            return None
        return user

    def _client_key(self):
        return self.client_address[0]

    def log_message(self, fmt, *args):
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))

    # ---- routing -----------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/health":
                return self._json(200, {"status": "ok", "time": datetime.now(timezone.utc).isoformat()})
            if path == "/api/auth/me":
                user = self._require_user()
                if user is None:
                    return
                return self._json(200, {"user": public_user(user)})
            if path.startswith("/api/"):
                return self._error(404, "not_found", "Bunday API mavjud emas.")
            return self._serve_static(path)
        except Exception as exc:  # noqa: BLE001 - never let a bug crash the server
            print("!! 500 GET", path, repr(exc))
            self._error(500, "server_error", "Kutilmagan server xatosi.")

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/auth/register":
                return self._handle_register()
            if path == "/api/auth/login":
                return self._handle_login()
            if path == "/api/auth/logout":
                return self._handle_logout()
            return self._error(404, "not_found", "Bunday API mavjud emas.")
        except Exception as exc:  # noqa: BLE001
            print("!! 500 POST", path, repr(exc))
            self._error(500, "server_error", "Kutilmagan server xatosi.")

    # ---- handlers ------------------------------------------------------
    def _handle_register(self):
        body = self._read_json()
        if body is None:
            return self._error(400, "invalid", "So'rov tanasi JSON emas.")
        name = (body.get("name") or "").strip()
        email = (body.get("email") or "").strip().lower()
        password = body.get("password") or ""

        problem = validate_register(name, email, password)
        if problem:
            return self._error(400, "invalid", problem)

        # Self-registration always creates a student account. Admin/teacher
        # roles are assigned by an existing admin, never granted here.
        user, err = create_user(name, email, password, role="student")
        if err == "exists":
            return self._error(409, "exists", "Bu email allaqachon ro'yxatdan o'tgan.")
        token = create_session(user["id"])
        self._json(201, {"token": token, "user": public_user(user)})

    def _handle_login(self):
        body = self._read_json()
        if body is None:
            return self._error(400, "invalid", "So'rov tanasi JSON emas.")
        email = (body.get("email") or "").strip().lower()
        password = body.get("password") or ""

        limiter_key = f"{self._client_key()}:{email}"
        if rate_limited(limiter_key):
            return self._error(429, "rate_limited", "Juda ko'p urinish. Birozdan so'ng qayta urinib ko'ring.")

        conn = get_conn()
        try:
            user = get_user_by_email(conn, email)
        finally:
            conn.close()

        if not user or not verify_password(password, user["password_hash"], user["salt"]):
            record_attempt(limiter_key)
            return self._error(401, "creds", "Email yoki parol noto'g'ri.")

        token = create_session(user["id"])
        self._json(200, {"token": token, "user": public_user(user)})

    def _handle_logout(self):
        token = self._bearer_token()
        if token:
            delete_session(token)
        # Idempotent: logging out an already-logged-out client is not an error.
        self._json(200, {"ok": True})

    # ---- static file serving -------------------------------------------
    def _serve_static(self, path):
        # Decode %2e, %2f, spaces, etc. BEFORE normalizing — otherwise an
        # encoded ".." would slip through the traversal check unresolved.
        path = unquote(path)
        if path == "/":
            path = "/index.html"

        # Normalize and refuse to escape PUBLIC_DIR (blocks "../" traversal,
        # including encoded and backslash variants, since unquote() above
        # already turned them into literal ".." before this check runs).
        safe_rel = os.path.normpath(path).lstrip(os.sep)
        full_path = os.path.normpath(os.path.join(PUBLIC_DIR, safe_rel))
        if not (full_path == PUBLIC_DIR or full_path.startswith(PUBLIC_DIR + os.sep)):
            return self._error(403, "forbidden", "Ruxsat yo'q.")

        if not os.path.isfile(full_path):
            # Hash-router SPA: the fragment (#/learn) never reaches the
            # server, so there is no client-side route to fall back to
            # here — a missing file is a genuine 404.
            return self._error(404, "not_found", "Fayl topilmadi. Avval 'python build.py' ishga tushirilganmi?")

        mime, _ = mimetypes.guess_type(full_path)
        with open(full_path, "rb") as handle:
            data = handle.read()
        self.send_response(200)
        self.send_header("Content-Type", mime or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        if full_path.endswith("index.html"):
            self.send_header("Cache-Control", "no-cache")
        else:
            self.send_header("Cache-Control", "public, max-age=3600")
        self.end_headers()
        self.wfile.write(data)


def main():
    if os.environ.get("TLA_RESET_DB") == "1" and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print(f"[reset] {DB_PATH} o'chirildi — demo baza noldan boshlanadi")

    if not os.path.isfile(os.path.join(PUBLIC_DIR, "index.html")):
        print("! OGOHLANTIRISH: public/index.html topilmadi.")
        print("! Avval sayt ildizida shuni ishga tushiring:  python build.py")
        print()

    init_db()
    seed_demo_accounts()

    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Tatbiqul Lisan Academy backend")
    print(f"  Sayt : http://localhost:{PORT}")
    print(f"  API  : http://localhost:{PORT}/api/health")
    print(f"  Baza : {DB_PATH}")
    print(f"  To'xtatish uchun: Ctrl+C")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nTo'xtatildi.")
        server.shutdown()


if __name__ == "__main__":
    main()
