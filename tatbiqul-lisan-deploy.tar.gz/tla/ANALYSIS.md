# MASTER PROMPT TAHLILI

**Loyiha:** Tatbiqul Lisan Academy (أكاديمية تطبيق اللسان)
**Manba:** 2505 qatorlik, 75 bo'limli master prompt
**Sana:** 2026-yil 15-avgust

---

## 1. Promptning kuchli tomonlari

Prompt quyidagi jihatlari bilan kuchli edi va ular to'liq saqlab qolindi:

- **Aniq auditoriya** — o'zbek tilli talabalar; arab tili + imtihon tayyorgarligi
- **Aniq imtihon yo'nalishlari** — Multilevel, TANAL Arobiy, Darajaviy testlar
- **Halollik talablari** (§ 70–73) — soxta statistika, soxta rasmiy da'volar, soxta o'qituvchi malakalari va soxta kontaktlarni qat'iy taqiqlash. **Bu promptdagi eng qimmatli qism** va butun loyihaning asosiy tamoyiliga aylandi.
- **CEFR tuzilmasi** — A1–C2 bo'yicha bosqichli tizim
- **Ko'nikmalar ajratilishi** — o'qish / tinglash / grammatika / leksika / yozish / gapirish

---

## 2. QO'SHILGAN NARSALAR (promptda yo'q edi)

| # | Qo'shildi | Sabab |
|---|-----------|-------|
| 1 | **Huquqiy hujjatlar** (maxfiylik, shartlar, refund, oferta) | To'lov qabul qiluvchi platforma huquqiy hujjatlarsiz ishga tushirilmaydi. Namuna matnlar berildi, har birida "yurist ko'rigidan o'tkazilsin" eslatmasi bilan. |
| 2 | **Ro'yxatdan o'tishdan keyingi onboarding** | Promptda ro'yxatdan o'tish bor edi, lekin maqsad/muddat so'ralmasdi. Maqsadsiz tavsiya tizimi ishlamaydi. |
| 3 | **Intervalli takrorlash (SRS)** — 1/3/7/15/30 kun | Promptda "so'zni saqlash" bor edi, lekin takrorlash rejasi yo'q. Saqlangan so'z takrorlanmasa, foydasiz. |
| 4 | **Javoblarni ko'rib chiqish (review) rejimi** | Promptda natija ko'rsatish bor edi, lekin "qayerda xato qildim" yo'q. Bu — test platformasining eng ko'p o'rgatuvchi qismi. |
| 5 | **Imtihon sanasi va countdown** | Imtihonga tayyorgarlik platformasida muddat — asosiy motivator. |
| 6 | **Tab-almashish ogohlantirishi (mock rejimda)** | Real imtihon shartlariga yaqinlashtirish uchun. |
| 7 | **Savol qiyinlik statistikasi (p-qiymat)** | Admin uchun: qaysi savol juda qiyin yoki noaniq yozilganini ko'rsatadi. Kontent sifatini oshirish vositasi. |
| 8 | **Ma'lumot eksport / o'chirish** | GDPR va shunga o'xshash talablar uchun majburiy. Promptda yo'q edi. |
| 9 | **Global qidiruv (⌘K)** | 120 dars + 52 test + kutubxona + lug'atda navigatsiya qidiruvsiz og'ir. |
| 10 | **Bildirishnoma sozlamalari** | Promptda bildirishnoma yuborish bor, lekin uni **o'chirish** imkoni yo'q edi. |
| 11 | **Sertifikat tekshirish sahifasi + haqiqiy QR** | QR kod promptda aytilgan, lekin tekshirish oqimi yo'q edi. QR — dekorativ rasm emas, ISO/IEC 18004 bo'yicha ishlaydigan kod. |
| 12 | **Demo/limit holatlarining ochiq belgilanishi** | Audio, to'lov, fayllar — barchasi demo ekani ochiq yoziladi. Foydalanuvchini chalg'itmaslik uchun. |

---

## 3. OLIB TASHLANGAN / CHEKLANGAN NARSALAR

| # | Olib tashlandi | Sabab |
|---|----------------|-------|
| 1 | **"FINAL REQUEST TO GEMINI" bloki** | Boshqa modelga murojaat; mahsulot talabi emas, prompt qoldig'i. |
| 2 | **Three.js asosidagi og'ir 3D** | Muhitda tarmoq yo'q → CDN yuklab bo'lmaydi. Muhimrog'i: 3D kutubxona mobil qurilmada ~600KB va batareyani yeydi. **O'rniga CSS 3D + canvas girih naqshi** — bir xil vizual ta'sir, nol bog'liqlik. |
| 3 | **AI orqali yozma va og'zaki ishlarni avtomatik baholash** | Bu **halollik masalasi**: LLM arab tilidagi inshoga ishonchli CEFR bahosi bera olmaydi, lekin foydalanuvchi bu ballni rasmiy deb qabul qiladi. **O'rniga:** aniq rubrika + o'z-o'zini baholash ro'yxati + o'qituvchi tekshiruvi navbati. |
| 4 | **Ochiq (majburiy) leaderboard** | Barcha foydalanuvchilarni reytingga qo'shish — maxfiylik muammosi. **O'rniga:** faqat rozilik berganlar (opt-in), va soxta ishtirokchilar **umuman generatsiya qilinmaydi** — ro'yxat bo'sh bo'lsa, bo'sh ko'rsatiladi. |
| 5 | **§7 va §64 navigatsiya dublikati** | Ikki bo'limda bir xil menyu ikki xil tavsiflangan edi — birlashtirildi. |
| 6 | **"10 000+ talaba", "98% muvaffaqiyat" kabi ko'rsatkichlar** | Promptning o'zi buni taqiqlaydi (§70). O'rniga **tekshirilishi mumkin** raqamlar ishlatiladi: 6 daraja, 120 dars, 52 test to'plami, 88 savol. |

---

## 4. HALOLLIK QARORLARI (eng muhim qism)

Promptning §70–73 talablari quyidagicha amalga oshirildi:

| Soha | Qaror |
|------|-------|
| **O'qituvchilar** | Sahifa **bo'sh holat** bilan ochiladi. O'ylab topilgan ism, diplom yoki tajriba **yo'q**. Ma'lumot faqat admin panel orqali kiritiladi. |
| **Kontaktlar** | Telefon/email/manzil bo'sh. Sayt "admin panelda kiritiladi" deb yozadi — soxta raqam ko'rsatmaydi. |
| **Statistika** | Faqat platformaning o'z tarkibidan hisoblangan raqamlar. Foydalanuvchi soni yoki muvaffaqiyat foizi **da'vo qilinmaydi**. |
| **Imtihon nomlari** | Har bir imtihon sahifasida: platforma hech bir imtihon tashkilotining rasmiy vakili emasligi va rasmiy savollarni tarqatmasligi yoziladi. |
| **Sertifikat** | "Ichki yutuq hujjati, rasmiy imtihon sertifikati emas" deb ochiq belgilanadi. |
| **Audio** | Qurilmada arabcha ovoz bo'lmasa — **yashirilmaydi**, "demo rejim" deb belgilanadi va matn ko'rsatiladi. |
| **To'lov** | "Demo to'lov: haqiqiy pul yechilmaydi, karta ma'lumotlari so'ralmaydi." |
| **Kutubxona fayllari** | PDF/video uchun soxta havola **yaratilmaydi** — "fayl admin panel orqali biriktiriladi" deb yoziladi. |
| **Parol** | Ochiq matnda **hech qachon** saqlanmaydi (demo digest ishlatiladi), va bu real xavfsizlik emasligi kodda izohlangan. |

---

## 5. Promptda ochiq qolgan va qaror talab qilgan joylar

| Savol | Qabul qilingan qaror |
|-------|----------------------|
| Diagnostika natijasi mehmonga to'liq ko'rsatilsinmi? | **Yo'q, qisman.** Ball va daraja ochiq (qiymat avval beriladi), batafsil tahlil ro'yxatdan o'tishdan keyin. Mehmon progressi ro'yxatdan o'tgach avtomatik ko'chiriladi. |
| Daraja qanday hisoblanadi? | ≥60% qoidasi: talaba **muvaffaqiyatli o'tgan eng yuqori daraja**. Zaxira sifatida umumiy ball diapazoni. Har bir ko'nikma alohida hisoblanadi va shu ko'nikmadagi eng qiyin savol darajasidan yuqori ball qo'yilmaydi. |
| Birinchi foydalanuvchi kim bo'ladi? | Birinchi ro'yxatdan o'tgan foydalanuvchi **admin** bo'ladi (aks holda admin panelga hech kim kira olmaydi). |
| Savollar takrorlanadimi? | Yo'q — har bir test bazadan **yangidan yig'iladi** (urug'langan tasodifiy), variantlar ham aralashtiriladi. |

---

## 6. Bajarilmagan / kelajakdagi ishlar

Quyidagilar **backend talab qiladi** va frontendda halol taqlid qilinmadi:

- Telegram bot va bildirishnomalar (token faqat serverda saqlanishi kerak)
- Haqiqiy to'lov (Click/Payme/Uzum) — provayder sahifasiga yo'naltirish
- O'qituvchi tomonidan yozma ish tekshiruvi (navbat + bildirishnoma)
- Haqiqiy audio fayllar (hozir nutq sintezi)
- Server tomonidagi rol tekshiruvi (frontend roli — hech qachon yagona himoya emas)
- Sertifikat tekshiruvining ommaviy URL manzili

Bularning har biri uchun kodda **ulanish nuqtasi** qoldirilgan — batafsil `README.md` dagi "Backend ulash" bo'limida.
