global.window = global;
require(require('path').join(__dirname, '..', 'src', 'js', '00-utils.js'));
require(require('path').join(__dirname, '..', 'src', 'js', '09-qr.js'));
const QR = global.TLA.qr;
const url = "https://example.org/verify/TLA-2026-0001";
const m = QR.matrix(url);
const SIZE = 33;
// rebuild function-pattern map to know which modules are data
function funcMap(){
  const f = []; for(let r=0;r<SIZE;r++) f.push(new Array(SIZE).fill(false));
  function mark(r0,c0){ for(let r=-1;r<=7;r++)for(let c=-1;c<=7;c++){const rr=r0+r,cc=c0+c; if(rr>=0&&rr<SIZE&&cc>=0&&cc<SIZE) f[rr][cc]=true;} }
  mark(0,0); mark(SIZE-7,0); mark(0,SIZE-7);
  // alignment at 26,26
  for(let r=-2;r<=2;r++)for(let c=-2;c<=2;c++) f[26+r][26+c]=true;
  for(let i=0;i<SIZE;i++){ f[6][i]=true; f[i][6]=true; }
  // format areas
  for(let i=0;i<9;i++){ f[i][8]=true; f[8][i]=true; }
  for(let i=0;i<8;i++){ f[SIZE-1-i][8]=true; f[8][SIZE-1-i]=true; }
  return f;
}
const fmap = funcMap();
// read format to get mask
let bits=0;
for(let i=0;i<15;i++){ let v; if(i<6) v=m[i][8]; else if(i<8) v=m[i+1][8]; else v=m[SIZE-15+i][8]; if(v) bits|=(1<<i); }
const raw = bits ^ 0x5412; const mask=(raw>>10)&7;
function maskFn(p,i,j){switch(p){case 0:return (i+j)%2===0;case 1:return i%2===0;case 2:return j%3===0;case 3:return (i+j)%3===0;case 4:return (Math.floor(i/2)+Math.floor(j/3))%2===0;case 5:return ((i*j)%2)+((i*j)%3)===0;case 6:return ((((i*j)%2)+((i*j)%3))%2)===0;default:return ((((i+j)%2)+((i*j)%3))%2)===0;}}
// read codewords
const bitsOut=[];
let inc=-1,row=SIZE-1;
for(let col=SIZE-1;col>0;col-=2){
  if(col===6) col--;
  for(;;){
    for(let c=0;c<2;c++){
      const cc=col-c;
      if(!fmap[row][cc]){
        let v = m[row][cc];
        if(maskFn(mask,row,cc)) v=!v;
        bitsOut.push(v?1:0);
      }
    }
    row+=inc;
    if(row<0||row>=SIZE){ row-=inc; inc=-inc; break; }
  }
}
const bytes=[];
for(let i=0;i+8<=bitsOut.length;i+=8){ let b=0; for(let j=0;j<8;j++) b=(b<<1)|bitsOut[i+j]; bytes.push(b); }
const mode = bytes[0]>>4;
const len = ((bytes[0]&0x0f)<<4) | (bytes[1]>>4);
let out='';
for(let i=0;i<len;i++){ const b = ((bytes[1+i]&0x0f)<<4) | (bytes[2+i]>>4); out+=String.fromCharCode(b); }
console.log("mode:", mode, "(4 = byte)");
console.log("length:", len, "expected:", url.length);
console.log("decoded:", JSON.stringify(out));
console.log("MATCH:", out===url);
