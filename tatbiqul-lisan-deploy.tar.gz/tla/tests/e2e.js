// npm install puppeteer  (tests/README.md ga qarang)
const puppeteer = require('puppeteer');
const nodePath = require('path');
const path = 'file://' + nodePath.join(__dirname, '..', 'public', 'index.html');

const ROUTES = [
  '#/', '#/learn', '#/learn/a1', '#/learn/b2', '#/lesson/a1-m1-l1',
  '#/exams', '#/exams/multilevel', '#/exams/tanal', '#/exams/darajaviy',
  '#/tests', '#/tests?skill=listening', '#/test/diagnostic', '#/test/darajaviy-a1-grammar',
  '#/test/multilevel-writing', '#/test/multilevel-speaking',
  '#/library', '#/dictionary', '#/blog', '#/blog/arab-tilini-noldan-boshlash',
  '#/free', '#/pricing', '#/dashboard', '#/progress', '#/certificates',
  '#/verify', '#/profile', '#/leaderboard', '#/teachers', '#/about', '#/contact',
  '#/legal/privacy', '#/legal/terms', '#/admin', '#/nonexistent-page'
];

(async () => {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--allow-file-access-from-files']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900 });

  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text().slice(0,200)); });

  await page.goto(path, { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 800));

  console.log('=== BOOT ===');
  console.log('errors:', errors.length ? errors : 'yoq');
  const boot = await page.evaluate(() => ({
    ready: document.documentElement.classList.contains('is-ready'),
    header: !!document.querySelector('#siteHeader .logo'),
    footer: !!document.querySelector('#siteFooter .footer-top'),
    hero: !!document.querySelector('.hero-scene'),
    girih: !!document.querySelector('#girihCanvas'),
    driver: window.TLA.store.driver,
    questions: window.TLA.data.questions.length,
    tests: window.TLA.data.tests.length,
    lessons: window.TLA.data.allLessons().length
  }));
  console.log(boot);

  console.log('\n=== ROUTES ===');
  const failures = [];
  for (const r of ROUTES) {
    errors.length = 0;
    await page.evaluate(h => { location.hash = h; }, r);
    await new Promise(res => setTimeout(res, 260));
    const info = await page.evaluate(() => {
      const host = document.getElementById('pageHost');
      return {
        len: host.innerHTML.length,
        err: !!host.querySelector('.alert-danger'),
        title: document.title.slice(0, 40),
        h1: (host.querySelector('h1') || {}).textContent || ''
      };
    });
    // 400 was tuned before gated pages existed in this form — a logged-out
    // visit to #/admin legitimately renders a short "please log in" empty
    // state (~368 chars, verified by hand), not a bug. A genuine render
    // failure still trips info.err (the router's caught-exception banner)
    // or produces something far shorter than any real page shell.
    const bad = info.err || info.len < 150 || errors.length;
    if (bad) failures.push({ route: r, ...info, errors: errors.slice(0,3) });
    console.log((bad ? 'XATO ' : 'ok   ') + r.padEnd(38) + String(info.len).padStart(7) + '  ' + info.h1.slice(0,45));
  }

  console.log('\n=== XATOLAR ===');
  console.log(failures.length ? JSON.stringify(failures, null, 1) : 'yoq');

  await browser.close();
})();
