global.window = global;
require(require('path').join(__dirname, '..', 'src', 'js', '00-utils.js'));
require(require('path').join(__dirname, '..', 'src', 'js', '09-qr.js'));
const QR = global.TLA.qr;
const url = "https://example.org/verify/TLA-2026-0001";
const m = QR.matrix(url);
console.log("size:", m.length, "x", m[0].length);
// finder check
function finderOK(m, r0, c0){
  const pat=[[1,1,1,1,1,1,1],[1,0,0,0,0,0,1],[1,0,1,1,1,0,1],[1,0,1,1,1,0,1],[1,0,1,1,1,0,1],[1,0,0,0,0,0,1],[1,1,1,1,1,1,1]];
  for(let r=0;r<7;r++)for(let c=0;c<7;c++) if(!!m[r0+r][c0+c]!==!!pat[r][c]) return false;
  return true;
}
console.log("finder TL:", finderOK(m,0,0), "TR:", finderOK(m,0,26), "BL:", finderOK(m,26,0));
// timing
let timingOK=true;
for(let i=8;i<25;i++){ if(m[6][i]!==(i%2===0)) timingOK=false; if(m[i][6]!==(i%2===0)) timingOK=false; }
console.log("timing:", timingOK);
// dark module
console.log("dark module:", m[25][8]===true);
// nulls remaining?
let nulls=0; m.forEach(r=>r.forEach(v=>{if(v===null)nulls++;}));
console.log("unfilled modules:", nulls);
// decode format info back
function readFormat(m){
  let bits=0;
  for(let i=0;i<15;i++){
    let v;
    if(i<6) v=m[i][8]; else if(i<8) v=m[i+1][8]; else v=m[33-15+i][8];
    if(v) bits |= (1<<i);
  }
  return bits;
}
const raw = readFormat(m) ^ 0x5412;
const ec = (raw>>13)&3, mask=(raw>>10)&7;
console.log("format ec bits:", ec, "(1 = L) mask:", mask);
// second copy consistency
function readFormat2(m){
  let bits=0;
  for(let i=0;i<15;i++){
    let v;
    if(i<8) v=m[8][33-i-1]; else if(i<9) v=m[8][15-i-1+1]; else v=m[8][15-i-1];
    if(v) bits |= (1<<i);
  }
  return bits;
}
console.log("format copies match:", readFormat(m)===readFormat2(m));
