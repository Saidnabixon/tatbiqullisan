// npm install puppeteer  (tests/README.md ga qarang)
const puppeteer = require('puppeteer');
const nodePath = require('path');
const SITE_PATH = 'file://' + nodePath.join(__dirname, '..', 'public', 'index.html');
(async () => {
  const browser = await puppeteer.launch({
    args:['--no-sandbox','--disable-dev-shm-usage']});
  const page = await browser.newPage();
  await page.setViewport({width:1280,height:900});
  const errs=[];
  page.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  page.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text().slice(0,120));});
  const fresh = async () => { await page.goto(SITE_PATH,{waitUntil:'networkidle0'});
    await page.evaluate(()=>localStorage.clear()); await page.reload({waitUntil:'networkidle0'});
    await new Promise(r=>setTimeout(r,600)); };
  const T=async(n,f)=>{errs.length=0;let r;try{r=await f()}catch(e){r={THROWN:e.message}}
    const bad=errs.length||JSON.stringify(r).includes('false')&&n.includes('!')||r.THROWN;
    console.log((r.THROWN||errs.length?'XATO ':'ok   ')+n.padEnd(44),JSON.stringify(r).slice(0,120));
    if(errs.length)console.log('      ',errs.slice(0,2));};

  await fresh();

  await T('Mehmon: diagnostika natijasi yopiq', async()=>{
    await page.evaluate(()=>{location.hash='#/test/diagnostic'});
    await new Promise(r=>setTimeout(r,350));
    await page.evaluate(()=>document.getElementById('startTest').click());
    await new Promise(r=>setTimeout(r,400));
    await page.evaluate(async()=>{const n=document.querySelectorAll('.q-dot').length;
      for(let i=0;i<n;i++){const o=document.querySelectorAll('[data-opt]');if(o.length)o[0].click();
        if(i<n-1){document.getElementById('nextBtn').click();await new Promise(r=>setTimeout(r,50));}}});
    await page.evaluate(()=>document.getElementById('finishBtn').click());
    await new Promise(r=>setTimeout(r,250));
    await page.evaluate(()=>document.getElementById('confirmYes').click());
    await new Promise(r=>setTimeout(r,600));
    return page.evaluate(()=>({gate:!!document.querySelector('.gate-overlay'),blur:!!document.querySelector('.gate-blur'),
      scoreVisible:!!document.querySelector('.score-ring'),reviewHidden:!document.querySelector('.gate-blur .acc')}));
  });

  await T('Ro\'yxatdan o\'tgach mehmon progressi ko\'chdi', async()=>{
    // register() is async since the backend integration — await it
    // inside the page context, not just the outer test wrapper.
    await page.evaluate(async ()=>{await TLA.state.register('Ali V','ali@example.com','parol12345');});
    await new Promise(r=>setTimeout(r,250));
    return page.evaluate(()=>({attempts:TLA.state.attempts().length, xp:TLA.state.profile().xp>0}));
  });

  await T('Klaviatura: 1-4 va F tugmalari', async()=>{
    await page.evaluate(()=>{location.hash='#/test/darajaviy-a1-vocabulary'});
    await new Promise(r=>setTimeout(r,350));
    await page.evaluate(()=>document.getElementById('startTest').click());
    await new Promise(r=>setTimeout(r,400));
    await page.keyboard.press('2'); await new Promise(r=>setTimeout(r,120));
    await page.keyboard.press('f'); await new Promise(r=>setTimeout(r,120));
    const a=await page.evaluate(()=>({sel:document.querySelectorAll('.opt.is-selected').length,
      flagged:document.querySelectorAll('.q-dot.flagged').length}));
    await page.keyboard.press('ArrowRight'); await new Promise(r=>setTimeout(r,180));
    const b=await page.evaluate(()=>document.querySelector('.q-dot.current').textContent);
    return {...a, afterArrow:b};
  });

  await T('Test paytida chiqishdan ogohlantirish', async()=>{
    await page.evaluate(()=>{location.hash='#/pricing'});
    await new Promise(r=>setTimeout(r,300));
    const modal=await page.evaluate(()=>({dialog:!document.getElementById('modalRoot').hidden, hash:location.hash}));
    await page.evaluate(()=>{const y=document.getElementById('confirmYes'); if(y) y.click();});
    await new Promise(r=>setTimeout(r,400));
    return {...modal, after:await page.evaluate(()=>location.hash)};
  });

  await fresh();
  await T('Til/tema saqlanadi (reload)', async()=>{
    await page.evaluate(()=>{TLA.ui.setLang('ar'); TLA.state.setSetting('theme','dark');});
    await new Promise(r=>setTimeout(r,300));
    await page.reload({waitUntil:'networkidle0'});
    await new Promise(r=>setTimeout(r,700));
    return page.evaluate(()=>({lang:document.documentElement.lang,dir:document.documentElement.dir,
      theme:document.documentElement.dataset.theme, navAr:!!document.querySelector('.nav-link')}));
  });

  await fresh();
  await T('Qidiruv: indeks va natija', async()=>{
    await page.evaluate(()=>document.querySelector('[data-action="search-open"]').click());
    await new Promise(r=>setTimeout(r,250));
    await page.type('#searchInput','kutub');
    await new Promise(r=>setTimeout(r,400));
    return page.evaluate(()=>({hits:document.querySelectorAll('.search-hit').length,
      groups:document.querySelectorAll('.search-group-label').length}));
  });

  await T('A11y: sarlavha, til, alt, label', async()=>{
    await page.keyboard.press('Escape');
    await page.evaluate(()=>{location.hash='#/contact'});
    await new Promise(r=>setTimeout(r,400));
    return page.evaluate(()=>{
      const inputs=[...document.querySelectorAll('#pageHost input,#pageHost select,#pageHost textarea')];
      const unlabeled=inputs.filter(i=>!i.closest('label')&&!i.getAttribute('aria-label')&&!i.id).length;
      const btns=[...document.querySelectorAll('button')].filter(b=>!b.textContent.trim()&&!b.getAttribute('aria-label')).length;
      const svgs=[...document.querySelectorAll('svg')].filter(s=>!s.getAttribute('role')&&!s.getAttribute('aria-hidden')&&!s.getAttribute('aria-label')).length;
      return {h1:document.querySelectorAll('#pageHost h1').length, unlabeledInputs:unlabeled,
        unnamedButtons:btns, svgNoRole:svgs, skipLink:!!document.querySelector('.skip-link'), lang:document.documentElement.lang};
    });
  });

  await T('Reduced motion hurmat qilinadi', async()=>{
    await page.emulateMediaFeatures([{name:'prefers-reduced-motion',value:'reduce'}]);
    await page.evaluate(()=>{location.hash='#/'});
    await new Promise(r=>setTimeout(r,500));
    return page.evaluate(()=>{const b=document.querySelector('.book3d');
      return {anim:getComputedStyle(b).animationName, dur:getComputedStyle(b).animationDuration};});
  });

  await browser.close();
})();
