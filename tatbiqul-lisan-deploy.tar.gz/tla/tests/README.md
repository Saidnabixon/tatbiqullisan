# Sinov skriptlari

## O'rnatish

```bash
npm install puppeteer
```

Bu — loyihaning yagona npm bog'liqligi (faqat sinov uchun; saytning
o'zi bog'liqliksiz — `ARCHITECTURE.md` 2-bo'limga qarang). Odatiy
holda Puppeteer o'ziga kerakli Chromium'ni avtomatik yuklab oladi —
qo'shimcha sozlash shart emas.

## Ishga tushirish

Loyiha ildizidan yoki `tests/` papkasidan:

```bash
node tests/e2e.js         # 34 marshrutni yuklab, JS xatolarini tekshiradi
node tests/journey.js     # to'liq foydalanuvchi oqimi (ro'yxat -> test -> admin)
node tests/responsive.js  # 26 sahifa x 5 ekran o'lchami, overflow tekshiruvi
node tests/final.js       # mehmon darvozasi, klaviatura, RTL, a11y, saqlash
node tests/test-qr.js     # QR matritsasi tuzilmasi (finder, timing, format)
node tests/test-qr2.js    # QR ni teskari dekodlash (payload mosligi)
```

Barcha skriptlar `../public/index.html` ni **nisbiy yo'l** orqali
ochadi (`__dirname` asosida) — loyiha qayerga ko'chirilgan yoki
klonlangan bo'lishidan qat'iy nazar ishlaydi. Sinovdan oldin saytni
yig'ib qo'ying:

```bash
python3 build.py
```

## Backend sinovi

`backend/server.py` o'zgartirilgan bo'lsa:

```bash
python3 -m py_compile backend/server.py    # sintaksis
```

To'liq API sinovi qo'lda ishga tushiriladi (server + curl **bitta**
buyruqda bo'lishi kerak — fon jarayonlari alohida buyruqlar orasida
saqlanmaydi):

```bash
cd backend && rm -f data.db && PORT=8123 python3 server.py & sleep 1.5 && \
curl -s http://localhost:8123/api/health && \
curl -s -X POST http://localhost:8123/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@gmail.com","password":"12345678"}'
```

Batafsil API ma'lumotnomasi va xavfsizlik sinovlari: `BACKEND.md`.

## Kutilgan "soxta xato" haqida eslatma

`journey.js` va `final.js` da ro'yxatdan o'tish qadami ba'zan **XATO**
deb belgilanishi mumkin, garchi natija to'g'ri bo'lsa ham (masalan
`{"attempts":1,"xp":true}`). Sabab: sayt `file://` orqali ochilganda
va backend mavjud bo'lmaganda, brauzer konsoliga tarmoq xatosi haqida
xabar yozadi (`CORS policy` yoki `net::ERR_FAILED`) — bu **kutilgan
holat** (05b-api.js backendga ulanishga urinadi, muvaffaqiyatsiz
bo'lgach avtomatik lokal rejimga o'tadi), JS xatosi emas. Skript har
qanday konsol xabarini "XATO" deb belgilaydi, shuning uchun bu aniq
holatda **qaytarilgan natijaning o'ziga** qarang, faqat yorliqqa
emas — `ARCHITECTURE.md` 12.1-bo'limida bu xatti-harakat
tasvirlangan.

## Muhitga xos sozlash (kamdan-kam kerak)

Agar tizimingizda Puppeteer o'z Chromium'ini yuklay olmasa (masalan
korporativ tarmoq cheklovi), allaqachon o'rnatilgan Chrome/Chromium'ga
ishora qiling:

```bash
export PUPPETEER_EXECUTABLE_PATH="/path/to/chrome"
```

Bu — Puppeteer'ning o'zi tan oladigan standart o'zgaruvchi; sinov
skriptlarини tahrirlash shart emas.

