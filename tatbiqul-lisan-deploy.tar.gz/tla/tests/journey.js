// npm install puppeteer  (tests/README.md ga qarang)
const puppeteer = require('puppeteer');
const path = require('path');
const SITE_PATH = 'file://' + path.join(__dirname, '..', 'public', 'index.html');

(async () => {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 950 });
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text().slice(0,150)); });

  await page.goto(SITE_PATH, { waitUntil: 'networkidle0' });
  await new Promise(r => setTimeout(r, 700));
  const step = async (name, fn) => {
    errors.length = 0;
    const res = await fn();
    console.log((errors.length ? 'XATO ' : 'ok   ') + name.padEnd(42), JSON.stringify(res).slice(0,150));
    if (errors.length) console.log('      ', errors.slice(0,2));
  };

  // 1. lesson page with correct id
  await step('Dars sahifasi (a1-l1)', async () => {
    await page.evaluate(() => { location.hash = '#/lesson/a1-l1'; });
    await new Promise(r => setTimeout(r, 300));
    return page.evaluate(() => ({
      h1: (document.querySelector('#pageHost h1')||{}).textContent,
      tabs: document.querySelectorAll('[data-tab]').length,
      panel: document.getElementById('lessonPanels').innerHTML.length
    }));
  });

  // 2. lesson tabs
  for (const tab of ['vocab','grammar','reading','listening','speaking','writing','practice']) {
    await step('  tab: ' + tab, async () => {
      await page.evaluate(t => document.querySelector(`[data-tab="${t}"]`).click(), tab);
      await new Promise(r => setTimeout(r, 250));
      return page.evaluate(() => ({ len: document.getElementById('lessonPanels').innerHTML.length }));
    });
  }

  // 3. practice answer
  await step('  mashq savoliga javob', async () => {
    await page.evaluate(() => document.querySelector('[data-tab="practice"]').click());
    await new Promise(r => setTimeout(r, 200));
    await page.evaluate(() => document.querySelector('[data-practice] .opt').click());
    await new Promise(r => setTimeout(r, 150));
    return page.evaluate(() => ({
      explained: !document.querySelector('[data-practice] .q-explain').hidden,
      marked: document.querySelectorAll('[data-practice] .opt.is-correct').length
    }));
  });

  // 4. register
  await step('Ro\'yxatdan o\'tish', async () => {
    await page.evaluate(() => { location.hash = '#/'; });
    await new Promise(r => setTimeout(r, 250));
    await page.evaluate(() => document.querySelector('[data-action="auth-register"]').click());
    await new Promise(r => setTimeout(r, 250));
    await page.type('#authForm input[name=name]', 'Aziz Karimov');
    await page.type('#authForm input[name=email]', 'aziz@example.com');
    await page.type('#authForm input[name=password]', 'parol12345');
    await page.click('#authForm input[name=agree]');
    await page.evaluate(() => document.querySelector('#authForm button[type=submit]').click());
    // 400ms was enough when register() was synchronous; with the backend
    // integration a real round-trip (PBKDF2 + SQLite) measured ~200ms —
    // 900ms leaves comfortable margin under load, matching what proved
    // reliable in the backend E2E tests during development.
    await new Promise(r => setTimeout(r, 900));
    return page.evaluate(() => ({
      authed: window.TLA.state.isAuthed(),
      role: (window.TLA.state.currentUser()||{}).role,
      onboarding: !!document.getElementById('onbForm')
    }));
  });

  // 5. onboarding
  await step('Onboarding yakunlash', async () => {
    await page.evaluate(() => document.querySelector('#onbForm button[type=submit]').click());
    await new Promise(r => setTimeout(r, 400));
    return page.evaluate(() => ({ hash: location.hash, h1: (document.querySelector('#pageHost h1')||{}).textContent }));
  });

  // 6. take diagnostic
  await step('Diagnostik testni boshlash', async () => {
    await page.evaluate(() => { location.hash = '#/test/diagnostic'; });
    await new Promise(r => setTimeout(r, 300));
    await page.evaluate(() => document.getElementById('startTest').click());
    await new Promise(r => setTimeout(r, 400));
    return page.evaluate(() => ({
      running: window.TLA.pages.test.isRunning(),
      timer: (document.getElementById('timer')||{}).textContent,
      dots: document.querySelectorAll('.q-dot').length,
      opts: document.querySelectorAll('[data-opt]').length
    }));
  });

  await step('Barcha savollarga javob berish', async () => {
    return page.evaluate(async () => {
      const total = document.querySelectorAll('.q-dot').length;
      for (let i = 0; i < total; i++) {
        const opts = document.querySelectorAll('[data-opt]');
        if (opts.length) opts[i % opts.length].click();
        const next = document.getElementById('nextBtn');
        if (i < total - 1) { next.click(); await new Promise(r => setTimeout(r, 60)); }
      }
      return { answered: document.querySelectorAll('.q-dot.answered').length, total };
    });
  });

  await step('Testni yakunlash', async () => {
    await page.evaluate(() => document.getElementById('finishBtn').click());
    await new Promise(r => setTimeout(r, 250));
    await page.evaluate(() => document.getElementById('confirmYes').click());
    await new Promise(r => setTimeout(r, 600));
    return page.evaluate(() => ({
      hash: location.hash.slice(0,20),
      score: (document.querySelector('.score-ring .val span')||{}).textContent,
      level: (document.querySelector('.level-badge .lv')||{}).textContent,
      shamsa: !!document.querySelector('.shamsa'),
      review: document.querySelectorAll('.acc').length,
      gated: !!document.querySelector('.gate-overlay')
    }));
  });

  await step('Kabinet', async () => {
    await page.evaluate(() => { location.hash = '#/dashboard'; });
    await new Promise(r => setTimeout(r, 400));
    return page.evaluate(() => ({
      len: document.getElementById('pageHost').innerHTML.length,
      xp: (document.querySelectorAll('.stat-tile .v')[2]||{}).textContent,
      recs: document.querySelectorAll('.rec-item').length,
      tasks: document.querySelectorAll('.task-item').length
    }));
  });

  await step('Progress sahifasi', async () => {
    await page.evaluate(() => { location.hash = '#/progress'; });
    await new Promise(r => setTimeout(r, 350));
    return page.evaluate(() => ({
      len: document.getElementById('pageHost').innerHTML.length,
      shamsa: !!document.querySelector('.shamsa'),
      rows: document.querySelectorAll('.tbl tbody tr').length
    }));
  });

  await step('Admin panel (admin roli)', async () => {
    await page.evaluate(() => { location.hash = '#/admin'; });
    await new Promise(r => setTimeout(r, 400));
    return page.evaluate(() => ({
      len: document.getElementById('pageHost').innerHTML.length,
      tabs: document.querySelectorAll('.tabs .tab').length,
      tiles: document.querySelectorAll('.stat-tile').length
    }));
  });

  for (const tab of ['users','questions','content','teachers','payments','analytics','settings']) {
    await step('  admin tab: ' + tab, async () => {
      await page.evaluate(t => { location.hash = '#/admin?tab=' + t; }, tab);
      await new Promise(r => setTimeout(r, 300));
      return page.evaluate(() => ({ len: document.getElementById('adminPanel').innerHTML.length }));
    });
  }

  await step('Sertifikat + QR', async () => {
    await page.evaluate(() => {
      window.TLA.state.issueCertificate({ titleUz: 'A1 Arab tili', level: 'a1', kind: 'course' });
      location.hash = '#/certificates';
    });
    await new Promise(r => setTimeout(r, 450));
    return page.evaluate(() => ({
      certs: document.querySelectorAll('.cert-frame').length,
      qr: !!document.querySelector('.qr-box svg'),
      id: (document.querySelector('.c-meta')||{}).textContent.slice(0,20)
    }));
  });

  await browser.close();
})();
