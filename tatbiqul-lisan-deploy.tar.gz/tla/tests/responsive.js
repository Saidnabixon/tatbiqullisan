// npm install puppeteer  (tests/README.md ga qarang)
const puppeteer = require('puppeteer');
const nodePath = require('path');
const SITE_PATH = 'file://' + nodePath.join(__dirname, '..', 'public', 'index.html');
const ROUTES = ['#/','#/learn','#/learn/b1','#/lesson/b1-l5','#/exams','#/exams/multilevel','#/exams/darajaviy',
  '#/tests','#/test/diagnostic','#/library','#/dictionary','#/blog','#/blog/multilevel-tinglash-strategiyasi',
  '#/free','#/pricing','#/dashboard','#/progress','#/certificates','#/verify','#/profile','#/leaderboard',
  '#/teachers','#/about','#/contact','#/legal/refund','#/admin'];
const SIZES = [[360,740],[390,844],[768,1024],[1024,768],[1440,900]];

(async () => {
  const browser = await puppeteer.launch({
    args:['--no-sandbox','--disable-dev-shm-usage']});
  const page = await browser.newPage();
  await page.goto(SITE_PATH,{waitUntil:'networkidle0'});
  // sign in so gated pages render fully
  await page.evaluate(()=>{ localStorage.clear(); });
  await page.reload({waitUntil:'networkidle0'});
  await new Promise(r=>setTimeout(r,600));
  await page.evaluate(async ()=>{
    // register() is async since the backend integration (05b-api.js) —
    // must be awaited, or recordAttempt/issueCertificate below would run
    // while the new account is still mid-creation.
    await TLA.state.register('Test Foydalanuvchi','test@example.com','parol12345');
    TLA.state.recordAttempt({testId:'diagnostic',titleUz:'Bepul diagnostik test',kind:'diagnostic',score:72,
      correct:14,total:20,skillScores:{grammar:80,vocabulary:70,reading:75,listening:60},
      skillLevels:{grammar:'b1',vocabulary:'b1',reading:'b1',listening:'a2'},levelAccuracy:{a1:100,a2:80,b1:60},
      level:'b1',seconds:640,detail:[]});
    TLA.state.issueCertificate({titleUz:'B1 Arab tili',level:'b1',kind:'course'});
  });

  let problems = [];
  for (const [w,h] of SIZES) {
    await page.setViewport({width:w,height:h});
    for (const r of ROUTES) {
      await page.evaluate(x=>{location.hash=x}, r);
      await new Promise(res=>setTimeout(res,200));
      const info = await page.evaluate(() => {
        const d=document.documentElement;
        const over = d.scrollWidth > d.clientWidth+2;
        let culprits=[];
        if(over){ culprits=[...document.querySelectorAll('body *')]
          .filter(el=>{const b=el.getBoundingClientRect(); return b.right>window.innerWidth+3 && b.width>40;})
          .slice(0,3).map(el=>el.tagName+'.'+(el.className||'').toString().split(' ')[0]); }
        // tap target check
        const small=[...document.querySelectorAll('#pageHost button, #pageHost a.btn, #bottomNav a')]
          .filter(el=>{const b=el.getBoundingClientRect(); return b.height>0 && b.height<32;}).length;
        return {over, sw:d.scrollWidth, cw:d.clientWidth, culprits, small};
      });
      if (info.over) problems.push({size:w+'x'+h, route:r, sw:info.sw, cw:info.cw, culprits:info.culprits});
    }
    process.stdout.write(w+'px tekshirildi  ');
  }
  console.log('\n\n=== OVERFLOW MUAMMOLARI ===');
  console.log(problems.length ? JSON.stringify(problems,null,1) : 'YO\'Q — barcha 26 sahifa x 5 o\'lcham toza');
  await browser.close();
})();
